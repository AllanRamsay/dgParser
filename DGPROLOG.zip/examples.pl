example(1,[('hfh','NN'),('dhab','CC'),('jjfhh','NN')]).
example(2,[('hfh','NN'),('jjfhh','NN')]).
