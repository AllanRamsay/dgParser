#!/usr/bin/python

import sys
from htk import testrec

def testHTKRec(argv):
    d = "."
    recdir = "."
    for i in range(1, len(argv), 2):
        flag = argv[i]
        value = argv[i+1]
        if "--recdir".startswith(flag):
            rec = value
        elif "--directory".startswith(flag):
            d = value
        else:
            raise Exception("Unrecognised flag: %s"%(flag))
    acc, aligned = testrec(d)
    print acc
    for a in aligned:
        print a
        
if "testHTKRec" in sys.argv[0]:
        testHTKRec(sys.argv)
