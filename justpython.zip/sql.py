import socket

host = socket.gethostname()

def usingRamapp():
    return "ramapp" in host

def usingMac():
    return "MacBook-Pro" in host or host == "armac.cs.man.ac.uk"

def newarabspeak():
    if usingMac():
        return cursor("", "", "arabspea_newarabic")
    else:
        return cursor("arabspea_hazem", "Qu123456", "arabspea_newarabic")

def tennis():
    if usingMac():
        return cursor("", "", "tennis")
    else:
        return cursor("buxtont1_allan", "Tennis2367", "buxtont1_tennis")

def potnoodle():
    if usingMac():
        return cursor("", "", "potnoodle")
    else:
        global host
        host = "potnoodle.cs.man.ac.uk"
        return cursor("ramsay", "NX3xsPDX", "other_ramsay")
    
def school():
    global host
    if usingMac():
        return cursor("", "", "school")
    else:
        host = "db441344948.db.1and1.com"
        return cursor("dbo441344948", "bdac2367", "db441344948")

def parasite():
    if usingMac():
        return cursor("", "", "parasite")
    else:
        return cursor("buxtont1_allan", "Tennis2367", "buxtont1_tennis")

def use(database):
    global host
    if usingMac():
        return cursor("", "", "%s"%(database))
    elif usingRamapp():
        return cursor("", "", "%s"%(database))
    else:
        host = "db441344948.db.1and1.com"
        return cursor("dbo441344948", "bdac2367", "db441344948", host=host)
    
def buxtonac():
    global host
    if usingMac():
        return cursor("", "", "buxtonac")
    elif 'justhost' in host:
        return cursor("buxtonac", "Ros1960&Allan1953", "buxtonac_db", host="localhost")
    else:
        host = "db441344948.db.1and1.com"
        return cursor("dbo441344948", "bdac2367", "db441344948", host=host)

import re
def select(query, cursor):
    args = re.compile("select\s*(distinct)?\s*(?P<args>.*)\s*from .*").match(query).group("args").replace(" ", "").split(",")
    tables = []
    for result in execute(query, cursor):
        table = {}
        for i in range(0, len(args)):
            table[args[i]] = result[i]
        tables.append(table)
    return tables
    
try:
    import MySQLdb

    def execute(goal, cursor):
        try:
            cursor.execute(goal)
            return getAll(cursor)
        except Exception as e:
            raise Exception("""'%s' went wrong with the query '%s': please forward this message to webmaster@buxtonac.org.uk so we can try to fix it"""%(e[1], goal))
    
    def cursor(user, password, database, host=host):
        if usingMac():
            host = ""
        db = MySQLdb.connect(host, user, password, database, charset='utf8', use_unicode=True)
        db.autocommit(True)
        return db.cursor()
    
    def getAll(cursor):
        results = []
        m = cursor.fetchone()
        while m:
            results.append(m)
            m = cursor.fetchone()
        return results
    
except:
    
    import subprocess

    def execute(sql, c):
        if "ramapp" in host:
            whichmysql = '/usr/bin/mysql'
        else:
            whichmysql = '/usr/local/mysql/bin/mysql'
        if c[0] == "":
            p = subprocess.Popen(whichmysql,
                                 stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
        else:
            query = [whichmysql, "--host='%s'"%(host), '--user=%s'%(c[0]), '--password=%s'%(c[1])]
            p = subprocess.Popen(query,
                                 stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
        x = p.communicate('use %s;\n%s;'%(c[2], sql))
        if x[1] == '':
            return results(x[0])
        else:
            raise Exception(x[1])
        
    def cursor(user, password, database, host=host):
        return (user, password, database)

    def results(table):
        return [x.split('\t') for x in table.split('\n') if not x == ''][1:]

def executeAll(l, c):
    for e in l:
        execute(e, c)
