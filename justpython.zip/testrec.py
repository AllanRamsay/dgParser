#!/usr/bin/python

import sys
from htk import justTest

def testrec(argv):
    d = "TEMP"
    grammar = "grammar.txt"
    dict = "words2phones.txt"
    prompts = "testprompts.txt"
    model = "hmm15"
    for i in range(1, len(argv)):
        flag, value = argv[i].split("=")
        if flag == "dir":
            d = value
        elif flag == "dict":
            dict = value
        elif grammar.startswith(flag):
            prompts = value
        elif grammar.startswith(flag):
            grammar = value
        elif "model".startswith(flag):
            model = value
        else:
            raise Exception("uknown flag: %s"%(flag))
    acc, alignments = justTest(d=d, dict=dict, grammar=grammar, testing=prompts, model=model)
    print "Accuracy %s"%(acc)
    print "Alignments"
    for s in alignments:
        print s
        
if "testrec" in sys.argv[0]:
    try:
        testrec(sys.argv)
    except Exception as e:
        print e
        print "testrec dir=<dir> dict=<dict> grammar=<grammar> prompts=<prompts>"
