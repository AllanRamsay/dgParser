import re

"""
What matters about a word is its form and its tag: but tags are used
as patterns for matching BNC tags: we compile these when we first see
the word rather than on the fly, and we stick them in self posPattern
(we do also compile them in the fly if necessary: I can't see how a
situation can arise when a word is created with a pattern but without
the pattern being compiled at creation time, but it does seem to
happen so we check for it and compile them later if that turns out to
be necessary.
"""
    
"""
wordnet.morphy will usually get you the root if you give it the right
part of speech tag. Here I'm going to map the tag I got from the tagger
(which was itself derived from the BNC tags, i.e. NN0, VVI, ...) to
a wordnet tag (n, v, ...) and use that.
"""

try:
    from nltk.corpus import wordnet
except:
    print "Wordnet not available on this machine"

"""
You'd think that you could just take the lowercase first letter of the
tag, but with some tagsets this won't work (e.g. JJ for adjectives)
"""
tagequiv = {"NN":"n",
            "VV":"v",
            "VH":"v",
            "VB":"v",
            "JJ":"a",
            "AJ":"a"}

def morphy(w, t):
    if t[0].lower() in {"n", "v"}:
        t = t[0].lower()
    elif t[:2] in tagequiv:
        t = tagequiv[t[:2]]
    try:
        t = wordnet.morphy(w, t)
        if t:
            return t
    except:
        pass
    return w
    
class WORD:

    def __init__(self, form=False, tag=False, position=False, label=False, hd=False):
        self.form = form
        self.tag = tag
        self.root = morphy(form, tag)
        self.position = position
        self.label = label
        self.hd = hd

    def __repr__(self):
        if self.form:
            s = "WORD(%s, %s"%(self.form, self.tag)
        else:
            s = "WORD(%s"%(self.tag)
        if type(self.label).__name__ == 'str':
            s += ", label=%s"%(self.label)
        if type(self.position).__name__ == 'int':
            s += ", position=%s"%(self.position)
        if type(self.hd).__name__ == 'int':
            s += ", hd=%s"%(self.hd)
	return s+")"

    def short(self):
        return '%s:%s:%s'%(self.position,self.form,self.tag)

    """
    Two words match if they have the same form (or the first one
    doesn't have a form, in which case it's an element of a pattern,
    so we're not specifying the form) and its tagPattern matches the
    other word's tag. 
    """
    def match(self, other):
        if self.form and not self.form == other.form:
            return False
        if self.tag:
            return self.tagPattern.match(other.tag)
        return True

def isword(x):
    return isinstance(x, WORD)

LABEL = 0
DTRS = 1

def showPSTree(tree, indent=0, initial=False):
    s = ""
    if not initial:
        s += '\n'
        for i in range(0, indent):
            s += ' '
    from useful import isstring
    if isstring(tree) or isword(tree):
        s += '%s'%(tree,)
    else:
        from mxl import gettag
        l = gettag(tree)
        s += '[%s '%(l)
        initial = True
        for d in tree[DTRS:]:
            s += showPSTree(d, indent=indent+len(l)+2, initial=initial)
            initial = False
        s += ']'
    if indent == 0:
        s += '\n'
    return s

def showDTree(tree, indent=0, initial=False):
    s = ""
    if not initial:
        s += '\n'
        for i in range(0, indent):
            s += ' '
    word = tree[0]
    if word.__class__.__name__ == "WORD":
        if word.form:
            label = "%s:%s"%(word.form, word.tag)
        else:
            label = "%s:%s"%(word.tag, word.position)
    else:
        label = word
    s += '[%s '%(label, )
    initial = True
    for d in tree[DTRS:]:
        s += showDTree(d, indent=indent+len(label)+2, initial=initial)
        initial = False
    s += ']'
    if indent == 0:
        s += '\n'
    return s

class SENTENCE:

    def __init__(self, source, file=False, localcounter=False, overallcounter=False):
        self.source = source
        self.file = file
        self.localcounter = localcounter
        self.overallcounter = overallcounter

    def showBaseTree(self):
        print showPSTree(self.basetree)

    def showFixedTree(self):
        print showPSTree(self.fixed)

    def showDTree(self):
        print showDTree(self.dtree)

    def bareDTree(self, f=lambda x: '%s:%s'%(x.tag, x.form)):
        return bareDTree(self.dtree, f)
        
    def sentence(self):
        s = ""
        for l in self.leaves:
            s += "%s "%(l.form)
        s = ' '.join(s.split())
        return s

    def toconll(self):
        return [(word.position, word.hd, word) for word in self.leaves]
    
    def parsed2conll(self):
        l = ""
        for i, word in enumerate(self.leaves):
            try:
                r = self.parsed[i]
                t = [i+1, word.form, word.form, word.tag, word.tag, "-", r.hd+1, r.rel] 
            except:
                t = [str(i+1), word.form, word.form, word.tag, word.tag, "-", -1, "root"]
            l += "%s\n"%("\t".join(map(str, t)))
        return l
        
def buildtree(relns, words, top=True, indent='', target=False):
    if isinstance(top, bool):
        if isinstance(relns, list):
            rtable = {}
            for r in relns:
                rtable[r.dtr] = r
            relns = rtable
        for i in relns:
            if relns[i].hd == -1:
                top = i
                break
        else:
            for i in relns:
                if not relns[i].hd in relns:
                    top = relns[i].hd
                    break
            else:
                print "buildtree:\n%s\n%s\n%s"%(relns, words, top)
                raise Exception("Couldn't find top")
    if type(top) == "WORD":
        top = top.position
    try:
        l = [words[top]]
    except Exception as e:
        print "TOP %s\nWORDS %s"%(top, words)
        raise e
    for x in sorted(relns.keys()):
        if relns[x].hd == top:
            if target and not (x in target and relns[x].hd == target[x].hd):
                words[relns[x].dtr].colour = "red"
                try:
                    words[relns[x].dtr].correct = target[x].hd
                except:
                    pass
            l.append(buildtree(relns, words, top=x, indent=indent+' ', target=target))
    return l

def simplify(t, f=lambda w: w.root):
    if type(t) == "WORD":
        return f(t)
    else:
        return [simplify(x, f=f) for x in t]
  
class RELATION:

    def __init__(self, hd, dtr, rel):
        if not isinstance(hd, int):
            raise Exception("hd of relation should be int: %s"%(hd))
        if not isinstance(dtr, int):
            raise Exception("dtr of relation should be int: %s"%(dtr))
        self.hd = hd
        self.dtr = dtr
        self.rel = rel

    def __repr__(self):
        return "%s >%s> %s"%(self.hd, self.rel, self.dtr)

    def __eq__(self, other):
        return (isinstance(other, self.__class__)
            and self.__dict__ == other.__dict__)

    def __ne__(self, other):
        return not self.__eq__(other)
  
