import re
import sys
import os
import shutil
import subprocess
import dtw
from random import randint

"""
We're going to run the scripts in here from one place, but we're often
going to run subprocesses in other places. If those subprocesses fail
for some reason (which they will), we're going to end up somewhere
unexpected. So it's important to remember where we started, and to be
able to get back there when things got wrong.
"""
HOME = os.getcwd()
def home():
     os.chdir(HOME)
     
home()

if sys.platform == "darwin":
    praat = "Praat"
elif sys.platform == "windows":
    praat = "praatcon.exe"
else:
    praat = "praat"
    
"""
There are a lot of steps involved in what we're trying to do. It's
helpful to include comments in the code to help with
understanding/maintenance/debugging. But it can also be helpful to
have this information printed out as the programs run,. so we can see
where it's got to, and just to give a picture of what it's doing. If
we wrap up our comments in a call of comment(...), then they're there
in the code to do the job that comments usually do. We use PRINTLEVEL
to control what gets printed out during training and testing--if it's
set to 1 (or 2) then they will also get printed as the system runs,
which will be helpful at runtime.
"""

global PRINTLEVEL
PRINTLEVEL = 1
def comment(c):
     if PRINTLEVEL > 0:
          print '*******************************'
          print c
        
"""
Sometimes useful to know what kind of thing some object is
"""
def type(x):
    return x.__class__.__name__

"""
MBROLA uses the SAMPA phonetic alphabet. SAMPA phoneme names contain
special characters. The HTK doesn't like special characters in phone
names. So we have to translate from SAMPA to something which doesn't
contain special characters.
"""

def replaceAll(s0, substitutions=[("@", "at"), ("_", "sil"), ('3:', 'aa')]):
     s1 = ""
     for target, replacement in substitutions:
        s1 = s0.replace(target, replacement)
     return s1

"""
Read f1, apply change to it, and put the result in f2. Bit like a unix filter.
"""
def filter(f1, f2, change):
    f2 = open(f2, 'w')
    f2.write(change(open(f1).read()))
    f2.close()
    
def newdir(d):
     if os.path.isdir(d):
          shutil.rmtree(d)
     os.mkdir(d)

"""
Run a command as a subprocess: change to the specified directory before you start.

command might be a string, in which case you'll have to split it

print stuff as you go if the global variable PRINTLEVEL is False

Two kinds of things may go wrong: there might be something wrong with
the way you've specified the command, in which case the call of
subprocess will throw a Python exception. Or the command may be
runnable, but it may throw an exception of its own. This won't (can't)
be trapped by Python: instead we rely on looking at the stderr channel
of the subprocess: if anything is written there then something mjust
have gone wrong inside the command, in which case we will raise that
as a Python exception. Whatever happens, we must go back to HOME
before we leave execute, because that's our last/only chance of doing
so.
"""

def execute(command, d="."):
     try:
          if command.__class__.__name__ == 'str':
               executable = command
               command = command.split(' ')
          else:
               executable = ""
               for x in command:
                    executable = executable+"%s "%(x)
          os.chdir(d)
          if PRINTLEVEL > 0:
              print "Doing %s: d=%s, os.getcwd()=%s"%(executable, d, os.getcwd())
          p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
          r = p.communicate()
          if PRINTLEVEL > 1:
               print r[0]
          if not r[1] == "":
               home()
               raise Exception(r[1])
          home()
          return r[0]
     except Exception as e:
          home()
          raise e
          
def writeToFile(file, s):
    file = open(file, 'w')
    file.write(s)
    file.close()

"""
Exception class to be raised in top-level scripts
"""
class ArgException(Exception):

    def __init__(self, msg):
        self.msg = msg
        
"""
Now for some actual stuff: the first bits are related to using MBROLA

Firstly, we need to know what machine we're on to know which version
of mbrola we are using and where the en1 database is.
"""

if os.uname()[1] in ['armac.cs.man.ac.uk', 'Allan-Ramsays-MacBook-Pro.local', 'Allan-Ramsays-MacBook-Pro-2.local']:
    mbrola = "mbrola-darwin-ppc"
    en1 = "/Users/ramsay/bin/mbrola/en1/en1"
else:
    mbrola = "mbrola"
    en1 = "/opt/info/courses/COMP34411/PROGRAMS/HTK/en1/en1"

"""
Read the dictionaries: sometimes when we do this, we want to do
something to the text that we found in the dictionary file before we
actually build the dictionary (e.g. we may want to make it HTK
friendly). So we supply a string->string function as an optional
argument, giving it an identity function as its default value.
"""
    
def readPhoneDict(dictFile, preprocess=(lambda x: x)):
     dict = {}
     space = re.compile("\s+")
     for entry in open(dictFile):
          entry = space.split(preprocess(entry.strip()))
          if len(entry) > 0 and not entry[0] == "":
               dict[entry[0]] = entry[1:]
     print "DICT %s"%(dict)
     return dict
    
def readPhoneLengthDict(dictFile, preprocess=(lambda x: x)):
     dict = {}
     space = re.compile("\s+")
     for entry in open(dictFile):
          entry = space.split(preprocess(entry.strip()), 1)
          """
          Check that the line wasn't empty
          """
          if len(entry) > 0 and not entry[0] == "":
               dict[entry[0]] = entry[1]
     print "DICT1 %s"%(dict)
     return dict

"""
For experiments where we make small random changes to the phone
length and pitch to try to encourage a bit of robustness in the
recogniser
"""
def variations(s):
     s = re.compile("\s*").split(s)
     l = int(s[0])
     l = l+randint(-int(l*0.4), int(l*0.4))
     return "%s 50 %s"%(l, randint(100, 140))

def identity(x):
     if len(x.split(" ")) == 1:
          return '%s 50 120'%(x)
     return x

"""
split the text into isolated words, look each word up in the
words:phonetic transcription dictionary, look each phone up in the
phonelengths dictionary, write it all out where specified. Uses my
usual trick of setting sys.stdout to be the default place where you
write to.

You can supply either the name of the file containing the dictionary
or the dictionary itself. I'm not going to do a lot of messing around
allowing you to set the path to where the dictionaries are--if they're
somewhere else then you'll just have to give the path to where they
are as part of the name.
"""
        
def genMbrola(d, text, words2phones, phonelengths, out=sys.stdout, vary=identity):
     os.chdir(d)
     try:
          if type(words2phones) == "str":
               words2phones = readPhoneDict(words2phones)
          if type(phonelengths) == "str":
               phonelengths = readPhoneLengthDict(phonelengths)
          if not out==sys.stdout:
               out = open(out, 'w')
          for word in text.split(" "):
               for phone in words2phones[word]:
                    out.write("%s %s\n"%(phone, vary(phonelengths[phone])))
          if not out == sys.stdout:
               out.close()
     except Exception as e:
          home()
          raise e
     home()

"""
Generate a wav file from an input string: generate the Mbrola script,
then run Mbrola on it: the script will be called "<out>.pho", the
.wav file will be called "<out>.wav".
"""
def say(text, words2phones="dict.txt", phonelengths="phonedict.txt", out="test", d="EXPT", vary=identity):
     if out == "praat":
          textnospaces = text.replace(" ", "")
     else:
          textnospaces = out
     genMbrola(d, text, words2phones, phonelengths, out="%s.pho"%(textnospaces), vary=vary)
     saymbrola(textnospaces, textnospaces, d=d, out=out)

def saymbrola(pfile, wfile, d=".", out="praat"):
     execute("%s %s %s.pho %s.wav"%(mbrola, en1, pfile, wfile), d)
     if out == "praat":
          praatScript = open("%s/%s.praat"%(d, pfile), "w")
          praatScript.write("""
Read from file... %s.wav
select Sound %s
Play
"""%(wfile, wfile))
          praatScript.close()
          execute("%s %s.praat"%(praat, wfile), d)
     home()

"""
Now for HTK stuff. A lot of this is tedious stuff to copy files from A
to B, make minor formatting changes, ... Boring, straightforward, but
you have to do it. The rest is just calling a sequence of HTK commands
to take one set of data and produce the next.
"""

"""
Large numbers of files get created when you run a round of
training. tidyUp gets rid of all the temporary files created as the
HTK goes about its business
"""

def tidyUp(d='.'):
     print "TIDYING UP %s"%(d)
     try:
          os.chdir(d)
          for f in os.listdir('.'):
               if f[-4:] in ['.mfc', '.scp', '.pho', '.wav'] or f.endswith('prompts.txt'):
                    os.remove(f)
          for f in ['words.mlf', 'wlist.txt', 'wdnet', 'phones0.mlf', 'monophones1', 'monophones0',
                    'codetrainconfig.txt', 'config.txt', 'proto.txt',
                    'htkdict.txt', 'phones1.mlf', 'hmm0', 'hmm1', 'stats', 'mkphones1.led', 'mkphones0.led',
                    'hmm2', 'sil.hed', 'hmm4', 'hmm3', 'hmm6', 'hmm5', 'hmm7', 'aligned.mlf', 'hmm9', 'hmm8',
                    'wintri.mlf', 'triphones1', 'mktri.led', 'mktri.hed', 'hmm10', 'hmm11', 'hmm12', 'fulllist',
                    'flog', 'dict-tri', 'trees', 'tree.hed', 'tiedlist', 'hmm13', 'hmm14', 'hmm15', 'recout.mlf']:
               print f
               if os.path.isdir(f):
                    shutil.rmtree(f)
               else:
                    try:
                         print "Remove %s in %s"%(f, os.getcwd())
                         os.remove(f)
                    except:
                         "No such file as %s in %s"%(f, d)
     except Exception as e:
          print e
          home()
          raise e
     home()
"""
Given a file full of sentences, add test1, test2, ... at the start of every line.
"""

def addPromptCounts(s0, train):
    s1 = ""
    i = 0
    for prompt in s0:
        prompt = prompt.strip()
        if len(prompt) > 0:
            i += 1
            s1 += "%s%s %s\n"%(train, i, prompt)
    return s1
    
def generateSamples(words2phones, phonelengths, n, dir, train="train", out="trainingprompts.txt"):
     samples = execute("HSGen -n %s wdnet %s"%(n, "htkdict.txt"), dir).strip().split("\n")
     writeToFile('%s/%s'%(dir, out), addPromptCounts(samples, train))
     i = 0
     phonedict = readPhoneDict("%s/%s"%(dir, words2phones))
     phonelengthdict = readPhoneLengthDict("%s/%s"%(dir, phonelengths))
     for sample in samples:
          i += 1
          if PRINTLEVEL > 1:
               print sample
          say(sample.strip(), phonedict, phonelengthdict, out="%s%s"%(train, i), d=dir, vary=variations)

def train(grammar, words2phones, phonelengths, n=400, d=".", doTidy=True, training="trainingprompts.txt", copied=False, iterations=3):
     try:
          os.mkdir(d)
     except Exception:
          if doTidy:
               tidyUp(d)
     comment("""
     Generate some sentences according to the grammar and produce the corresponding .wav files
     """)
     n = int(n)
     execute("HParse %s wdnet"%(grammar), d)
     filter("%s/%s"%(d, words2phones), "%s/htkdict.txt"%(d), replaceAll)
     samples = generateSamples(words2phones, phonelengths, n, d, "train", training)
     comment("""
     We now have the prompts that were used by MBROLA for generating
     the .wav files. We're now about to start using these to train the
     HTK. Some of the files we need aren't in the right format, so we
     have to do some transformations
     """)
     trainAsSeparateTask(d, training=training, copied=copied, iterations=iterations)

def trainAsSeparateTask(d, training="trainingprompts.txt", copied=False, dict="htkdict.txt", grammar="grammar.txt", iterations=3):
     dataprep4training(d, training=training, dict=dict, copied=copied)
     dotraining(d, dict, iterations=iterations)
     
def dataprep4training(d='.', training='trainingprompts.txt', copied=False, dict=False):
     makeLED(d)
     makeCTrainConfig(d)
     makeProto(d)
     makeConfig(d)
     createMonophones(d, dict)
     prompts2code(d, training, train="train")
     wordsmlf(d, training)
     phones(d, 0, dict)
     phones(d, 1, dict)
     if not copied:
          codetrain(d, "codetrain.scp")
     home()
     
def makeLED(d):
    try:
        os.chdir(d)
        writeToFile('mkphones0.led', """
EX
IS sil sil
DE sp
""")
        writeToFile('mkphones1.led', """
EX
IS sil sil
""")
    except Exception as e:
        home()
        raise e
    home()
        
def makeCTrainConfig(d, config='codetrainconfig.txt'):
    try:
        os.chdir(d)
        writeToFile(config, """
SOURCEFORMAT = WAV
TARGETKIND = MFCC_0
TARGETRATE = 100000.0
SAVECOMPRESSED = T
SAVEWITHCRC = T
WINDOWSIZE = 250000.0
USEHAMMING = T
PREEMCOEF = 0.97
NUMCHANS = 26
CEPLIFTER = 22
NUMCEPS = 12 
""")
    except Exception as e:
        home()
        raise e
    home()

def makeMandV(vectorSize=25):
     meanAndVariance = """
    <Mean> %s
      %s
    <Variance> %s
      %s
      """%(vectorSize, vectorSize*("0.0 "), vectorSize, vectorSize*("1.0 "))
     return meanAndVariance
  
def makeProto(d, proto='proto.txt', vecsize=25):
    try:
        os.chdir(d)
        text = """~o <VecSize> %s <MFCC_0_D_N_Z>
~h "proto"
<BeginHMM>
  <NumStates> 5
"""%(vecsize)
        for i in range(2, 5):
            text = text+"""
  <State> %s
%s"""%(i, makeMandV(vecsize))
        text = text+"""
 <TransP> 5
  0.0 1.0 0.0 0.0 0.0
  0.0 0.6 0.4 0.0 0.0
  0.0 0.0 0.6 0.4 0.0
  0.0 0.0 0.0 0.7 0.3
  0.0 0.0 0.0 0.0 0.0
<EndHMM>
"""
        writeToFile("%s"%(proto), text)
    except Exception as e:
        home()
        raise e
    home()

def createMonophones(d, dict):
     try:
          os.chdir(d)
          allPhones = {'sil':True}
          wfile = open('wlist.txt', 'w')
          for w in open(dict, 'r').read().split("\n"):
               wfile.write('%s\n'%(w))
               for p in re.compile("\s").split(w)[1:]:
                    allPhones[p] = True
          wfile.close()
          mp0 = open('monophones0', 'w')
          mp1 = open('monophones1', 'w')
          for phone in allPhones:
               mp0.write('%s\n'%(phone))
               mp1.write('%s\n'%(phone))
          mp1.write('sp\n')
          mp1.close()
          mp0.close()
     except Exception as e:
          home()
          raise e
     home()
     
def makeConfig(d, config='config.txt'):
    try:
        os.chdir(d)
        out = open(config, 'w')
        out.write("""
TARGETKIND = MFCC_0_D_N_Z
TARGETRATE = 100000.0
SAVECOMPRESSED = T
SAVEWITHCRC = T
WINDOWSIZE = 250000.0
USEHAMMING = T
PREEMCOEF = 0.97
NUMCHANS = 26
CEPLIFTER = 22
NUMCEPS = 12 
""")
        out.close()
    except Exception as e:
        home()
        raise e
    home()
    
promptPattern = re.compile('.*(?P<P>(test|train)\d*) .*')
def prompts2code(d, prompts, train="train"):
     print "prompts2code(%s, %s, %s)"%(d, prompts, train)
     print prompts
     try:
          os.chdir(d)
          codetrain = open("code%s.scp"%(train), "w")
          train = open("%s.scp"%(train), "w")
          for prompt in promptPattern.finditer(open(prompts, 'r').read()):
               prompt = prompt.group('P')
               codetrain.write('"%s.wav" "%s.mfc"\n'%(prompt, prompt))
               train.write('"%s.mfc"\n'%(prompt))
          codetrain.close()
          train.close()
     except Exception as e:
          home()
          raise e
     home()
          
def singlespace(s):
     return re.compile(' \s+', re.DOTALL).sub(' ', s)

def wordsmlf(d, prompts):
     sp = re.compile('\s+')
     try:
          os.chdir(d)
          prompts = open(prompts, 'r').readlines()
          wmlf = open('words.mlf', 'w')
          wmlf.write("#!MLF!#\n")
          for prompt in prompts:
               prompt = sp.split(singlespace(prompt.strip()))
               wmlf.write('"%s.lab"\n'%(prompt[0]))
               for word in prompt[1:]:
                    wmlf.write('%s\n'%(word))
               wmlf.write('.\n')
          wmlf.close()
     except Exception as e:
          home()
          raise e
     home()
    
def phones(d, n, dict='dict.txt'):
     try:
          execute('HLEd -A -D -T 1 -l * -d %s -i phones%s.mlf mkphones%s.led words.mlf'%(dict, n, n), d)
     except Exception as e:
          home()
          raise e
     home()

def codetrain(d, scp):
     try:
          execute('HCopy -A -D -T 1 -C codetrainconfig.txt -S %s'%(scp), d)
     except Exception as e:
          home()
          raise e
     home()
     
def dotraining(d, dict, iterations=3):
    comment("""
Make flat start HMMs: hmm0 will contain initial estimates of the emission probabilities,
but the transition probabilities are just the initial dummies copied from proto.txt
""")
    hmm0(d)
    createHMM0Defs(d)
    comment("""
Do three rounds of reestimation from this starting point: nothing interesting
happens, we just keep trying to improve the basic model, using the list of phones
in 'monophones0' (which is just a list of all the phones that occur in the training
data)
""")
    for i in range(iterations):
        HERest(d, i+1, 0)
    comment("""
Now add space for 'short pauses' in between words: for the next few goes, there's an
HMM for a phoneme called "sp", which gets inserted between words. Its initial transition
matrix is set up so that you probably zoom through it very quickly, because we don't
want to introduce long gaps between words in continuous speech, but they do sometimes
occur so we do have to allow for them. The HMMs in hmm5 are basically constructed from
the ones in hmm3 by doing these edits and running some 'edit scripts': there is no
reestimation at this point. hmm4 and hmm5 are edited versions of hmm3 with short pauses added.
""")
    i += 1
    hmm4(d, i)
    hmm5(d, i)
    comment("""
We've now got a model which contains short pauses but which was trained without short
pauses: better do a couple of rounds of reestimation.
""")
    i += 3
    for j in range(i, i+iterations):
        HERest(d, j, 1) 
    comment("""
The pronunciation dictionary might have contained multiple entries for some words. It would
be good to know which ones were used in this set of training examples, so we'll try to
recognise the phones that make up each utterance and output them as a new transcription. This
attempt to recognise the phones had better be accurate, because we're going to use it in
the next round of training. Fortunately we've got very strong constraints on what can happen
(i.e. the phoneme sequence corresponding to the words in the utterance, with branches where
there are altenative pronunciations). So this isn't going to introduce any errors into the
bits where there are no choices, so the worst that can happen is that we misclassify the
alternative pronunciations. If every word in the dictionary has just one pronunciation, this
step won't do anything.

After we've done it we do a couple of rounds of reestimation. Given that doing it when there
are no alternative pronunciations has no effect, this is really just further refinement of
hmm7, and shouldn't involve much change (though inspection of the versions of hmmdefs in hmm7
and hmm9 suggests that there are significant changes at this point)
""")
    aligned(d, j, dict)
    for i in range(j+1, j+iterations):
        HERest(d, i, 1)
    comment("""
We've now trained a set of HMMs which each correspond to a single phoneme. But as we've seen,
what a phoneme sounds like is affected by the surrounding sounds, so we'd like to have HMMs
which correspond to sounds in context: if /p/ sounds different when preceded by /a/ and followed
by /s/ (as in 'caps') from how it sounds when preceded by /m/ and followed by /s/ ('camps'), then
it would be nice to have one HMM for the sound "/p/ between /a/ and /s/" and another for
"/p/ between /m/ and /s/".

So we replace the phone names, which might look like 'aI', in the training data
by names like 'n-aI+h', which means "/aI/ between /n/ and /h/". We also need an HMM for
each of these new phones. The transition matrix for each of these new phones (these are more
like phones than phonemes, since they each correspond to different versions of the same
thing) is the same as the original, but they each have their own sets of emission
probabilities. In other words, it is assumed that the basic shape of the phoneme is
unchanged but the acoustic features that make it up, particularly at the beginning and
end, may vary. The HTK book refers to these as 'triphone models', which might lead you
to think that each model covers a sequence of three phones. They're more like 'phone in
context models'--they're an attempt at capturing "what does /aI/ sound like when it occurs
between /n/ and /h/?", not "what does the sequence /n/ /aI/ /h/ sound like?".

Once we've done this, we need to reestimate a couple of time again:
""")
    triphones(d)
    maketrihed(d)
    hmm10(d, i)
    i += 2
    HERestBase(d, 'wintri', i, 'triphones1')
    # Note that 'otherstuff' MUST start with a space
    HERestBase(d, 'wintri', i+1, 'triphones1', otherstuff=' -s stats')
    comment("""
We've now trained all the 'sounds in context' that occurred in the training data. The training
data may not, however, contain all the sounds in context that are allowed by our dictionary:
suppose that the dictionary contains "impossible", "inconceivable", "is" and "it", and the
training data contains "it is impossible". Then buried in this sequence of words is the
phone-in-context s-i+m (the first "i" in "impossible"). So we'll have learnt what /i/ sounds
like between /s/ and /m/. But if the training data doesn't include "it is inconceivable" then
we won't have heard s-i+n, so we can't have learnt what /i/ sounds like between /s/ and /n/.

What do we do? We can compare all our sounds with /n/ to see which it is most like it. Suppose that
turns out to be /m/. Then it is reasonable to suppose that s-i+n is very like s-i+m, since /n/ is
like /m/, so we'll use that. This is called 'tying'.

Again, a couple of rounds of reestimation follow (though I'm not all that sure why, given that the
new information relates, by definition, to stuff that we haven't heard, so I'm not sure what we
can be learning from at this point)

(if there are any phones in your dictionary which don't appear in the training data, the HTK will
fall over at this point, because it will want to use the existing HMM for these phones as
a basis for the triphone HMMs for it, but there won't be an existing HMM because it hasn't been
seen in the training data)
""")
    step10(d, dict) 
    i = hmm13(d, i+1)+1
    for j in range(i, i+iterations):
        HERestBase(d, 'wintri', j, 'tiedlist')
    comment("""
And that's it: you now have a trained model in hmm%s which can be used for recognition
"""%(j))
     
def hmm0(d):
     try:
          os.chdir(d)
          newdir('hmm0')
          home()
          execute('HCompV -A -D -T 1 -C config.txt -f 0.01 -m -S train.scp -M hmm0 proto.txt', d)
     except Exception as e:
          home()
          raise e
     home()
     
def createHMM0Defs(d, hmm0='hmm0', monophones='monophones0', hmm0defs='hmmdefs', proto='proto', hmmdefs='hmmdefs', macros='macros'):
     try:
          os.chdir(d)
          proto = open('%s/%s'%(hmm0, proto), 'r').read()
          hmms = re.compile('.*(?P<proto><BEGINHMM>.*<ENDHMM>).*', re.DOTALL).match(proto).group('proto')
          if not hmmdefs == sys.stdout:
               hmmdefs = open('%s/%s'%(hmm0, hmmdefs), 'w')
          for phone in open(monophones, 'r').readlines():
               hmmdefs.write('~h "%s"\n%s\n'%(phone.strip(), hmms))
          if not hmmdefs == sys.stdout:
               hmmdefs.close()
          if not macros == sys.stdout:
               macros = open('%s/%s'%(hmm0, macros), 'w')
          hmm0macros = re.compile('(?P<header>.*<DIAGC>).*', re.DOTALL).match(proto).group('header')
          hmm0macros = hmm0macros+'\n'+open('%s/%s'%(hmm0, 'vFloors'), 'r').read()
          macros.write(hmm0macros)
          if not macros == sys.stdout:
               macros.close()
     except Exception as e:
          home()
          raise e
     home()
         
def HERest(d, n, k):
     HERestBase(d, 'phones%s'%(k), n, 'monophones%s'%(k))

def HERestBase(d, mlf, n, monophones, otherstuff=''):
     try:
          os.chdir(d)
          newdir('hmm%s'%(n))
          execute('HERest -A -D -T 1 -C config.txt -I %s.mlf -t 250.0 150.0 1000.0 -S train.scp -H hmm%s/macros -H hmm%s/hmmdefs -M hmm%s%s %s'%(mlf, n-1, n-1, n, otherstuff, monophones)), 
          home()
     except Exception as e:
          home()
          raise e

def hmm4(d, i):
     try:
          os.chdir(d)
          newdir('hmm%s'%(i+1))
          hmmdefs3 = open('hmm%s/hmmdefs'%(i), 'r').read()
          silModel = re.compile('.*~h "sil".*?<STATE> 3(?P<SIL>.*?)<STATE>.*', re.DOTALL).match(hmmdefs3).group('SIL')
          spModel = """~h "sp"
<BEGINHMM>
<NUMSTATES> 3
<STATE> 2%s<TRANSP> 3
 0.0 1.0 0.0
 0.0 0.9 0.1
 0.0 0.0 0.0
<ENDHMM>
"""%(silModel)
          hmmdefs4 = open('hmm%s/hmmdefs'%(i+1), 'w')
          hmmdefs4.write(hmmdefs3+spModel)
          hmmdefs4.close()
          shutil.copy('hmm%s/macros'%(i), 'hmm%s/macros'%(i+1))
          silhed = writeToFile('sil.hed', """
AT 2 4 0.2 {sil.transP}
AT 4 2 0.2 {sil.transP}
AT 1 3 0.3 {sp.transP}
TI silst {sil.state[3],sp.state[2]}
""")
     except Exception as e:
          home()
          raise e
     home()
     
def hmm5(d, i):
     try:
          os.chdir(d)
          newdir('hmm%s'%(i+2))
          execute('HHEd -A -D -T 1 -H hmm%s/macros -H hmm%s/hmmdefs -M hmm%s sil.hed monophones1'%(i+1, i+1, i+2))
          home()
     except Exception as e:
          home()
          raise e

def aligned(d, i, dict='dict.txt'):
     try:
          execute('HVite -A -D -T 1 -l * -o SWT -b SENT-END -C config.txt -H hmm%s/macros -H hmm%s/hmmdefs -i aligned.mlf -m -t 250.0 150.0 1000.0 -y lab -a -I words.mlf -S train.scp %s monophones1'%(i, i, dict), d)
     except Exception as e:
          home()
          raise e
     home()     

def triphones(d):
     try:
          os.chdir(d)
          writeToFile('mktri.led', """
WB sp
WB sil
TC
""")
          execute('HLEd -A -D -T 1 -n triphones1 -l * -i wintri.mlf mktri.led aligned.mlf')
     except Exception as e:
          home()
          raise e
     home()
     
def maketrihed(d, monophones="monophones1", triphones="triphones1"):
     monophones = open("%s/%s"%(d, monophones))
     mktrihed = open("%s/mktri.hed"%(d), 'w')
     mktrihed.write("CL %s\n"%(triphones))
     for phone in monophones:
          phone = phone.strip()
          if not phone == "":
               mktrihed.write("TI T_%s {(*-%s+*,%s+*,*-%s).transP}\n"%((phone,)*4))
     mktrihed.close()
     
def hmm10(d, i):
     try:
          os.chdir(d)
          newdir('hmm%s'%(i+1))
          execute('HHEd -A -D -T 1 -H hmm%s/macros -H hmm%s/hmmdefs -M hmm%s mktri.hed monophones1'%(i, i, i+1))
     except Exception as e:
          home()
          raise e
     home()
     
def monophones2TB(t, monophones):
     mphones = open(monophones, 'r').read().strip().split("\n")
     TB = ''
     for i in range(2, 5):
          for m in mphones:
               TB = TB+'TB %s "ST_%s_%s_" {("%s","*-%s+*","%s+*","*-%s").state[%i]}\n'%(t, m, i, m, m, m, m, i)
     return TB

def step10(d, dict='dict.txt'):
     try:
          execute('HDMan -A -D -T 1 -b sp -n fulllist -g global.ded -l flog dict-tri %s'%(dict), d)
          os.chdir(d)
          allphones = {}
          for phone in open('fulllist', 'r').readlines()+open('triphones1', 'r').readlines():
               allphones[phone] = True
          fulllist = open('fulllist', 'w')
          for phone in allphones:
               fulllist.write(phone)
          fulllist.close()
          treehed = open('tree.hed', 'w')
          treehed.write("""
RO 100 stats
TR 2
""")
          TB = monophones2TB(350, 'monophones0')
          treehed.write(TB)
          treehed.write("""
TR 1
 
AU "fulllist"
CO "tiedlist" 
 
ST "trees" 
""")
          treehed.close()
     except Exception as e:
          home()
          raise e
     home()

def hmm13(d, i):
     try:
          os.chdir(d)
          newdir('hmm%s'%(i+1))
          execute('HHEd -A -D -T 1 -H hmm%s/macros -H hmm%s/hmmdefs -M hmm%s tree.hed triphones1'%(i, i, i+1))
     except Exception as e:
          home()
          raise e
     home()
     return i+1
   
def dataprep4testing(d, testing="testprompts.txt", model='hmm15'):
     prompts2code(d, testing, train="test")
     wordsmlf(d, testing)
     codetrain(d, "codetest.scp")
     home()
  
def testsynth(d, testing="testprompts.txt", dict="dict.txt", htkdict="htkdict.txt",phonelengths="phonedict.txt", model='hmm15', tied='tiedlist', n=100):
     try:
          samples = generateSamples(dict, phonelengths, n, d, train="test", out=testing)
          dataprep4testing(d, testing=testing)
          HVITE = 'HVite -A -D -T 1 -H %s/macros -H %s/hmmdefs -C config.txt -S test.scp -i recout.mlf -w wdnet -p 0.0 -s 5.0 %s %s'%(model, model, htkdict, tied)
          execute(HVITE, d)
          r = execute('HResults -I words.mlf %s recout.mlf'%(tied), d)
          r = r+open('%s/recout.mlf'%(d), 'r').read()
          home()
          return splitResults(r, d)
     except Exception as e:
          home()
          raise e
     
def testrec(d, htkdict="htkdict.txt", model='hmm15', tied='tiedlist', testing="testprompts.txt", grammar="grammar.txt"):
     execute("HParse %s wdnet"%(grammar), d)
     try:
          os.chdir(d)
          dataprep4testing(d, testing=testing)
          HVITE = 'HVite -A -D -T 1 -H %s/macros -H %s/hmmdefs -C config.txt -S test.scp -i recout.mlf -w wdnet -p 0.0 -s 5.0 %s %s'%(model, model, htkdict, tied)
          execute(HVITE, d)
          r = execute('HResults -I words.mlf %s recout.mlf'%(tied), d)
          r = r+open('%s/recout.mlf'%(d), 'r').read()
          home()
          return splitResults(r, d)
     except Exception as e:
          home()
          raise e
     
def justTest(d, dict="dict.txt", model='hmm15', tied='tiedlist', testing="testing.txt", grammar="grammar.txt"):
     execute("HParse %s wdnet"%(grammar), d)
     try:
          dataprep4testing(d, testing=testing)
          HVITE = 'HVite -A -D -T 1 -H %s/macros -H %s/hmmdefs -C config.txt -S test.scp -i recout.mlf -w wdnet -p 0.0 -s 5.0 %s %s'%(model, model, dict, tied)
          execute(HVITE, d)
          r = execute('HResults -I words.mlf %s recout.mlf'%(tied), d)
          r = r+open('%s/recout.mlf'%(d), 'r').read()
          home()
          return splitResults(r, d, prompts=testing)
     except Exception as e:
          home()
          raise e

def splitResults(r, d, prompts="testprompts.txt"):
     score, sentences = r.split("#!MLF!#")
     sentencePattern = re.compile('"(test|train)(?P<i>\d*).rec"(?P<sentence>.*?)\n\.', re.DOTALL)
     sentences = [(int(i.group("i")), i.group("sentence").strip().split("\n")) for i in sentencePattern.finditer(sentences)]
     sentences = [(sentence[0], [word.split(" ")[2] for word in sentence[1]]) for sentence in sentences]
     training = [sentence.strip().split(" ")[2:-1] for sentence in open('%s/%s'%(d, prompts))]
     alignments = [dtw.array(sentences[i][1], training[i]).showAlignment() for i in range(0, len(sentences))]
     i = 0
     d = 0
     c = 0
     x = 0
     n = 0
     for s in alignments:
          for k in s:
               a = k[0]
               b = k[1]
               if a == b:
                    c = c+1
               elif b == '*':
                    i = i+1
               elif a == '*':
                    d = d+1
               elif not a == b:
                    x = x+1
               n = n+1
     return "N=%s, CORRECT=%s, ACC=%.2f, EXCH=%s, INS=%s, DEL=%s"%(n, c, float(c)/n, x, i, d), alignments
