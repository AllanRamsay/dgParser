import re

"""
(?P<name>xya*b) will match any sequence like "xyaaaab" and call it "name"

(?(name)(abcd)|(pqrs)): if some group called "name" has already been matched, then this
will match "abcd", otherwise it will match "pqrs"
"""
patterns = {"ART": "Al|",
            "CONJ": "w|f",
            "NSTEM": ".{3,}?",
            "VSTEM": ".{2,}?",
            "PRON": "k|kmA|km|kn|h|hA|hmA|hn|hm|nA|y",
            "VPRON": "PRON|NY",
            "NY": "ny",
            "PREP": "b|k|l",
            "FUT": "s",
            "TNS1": "(?P<ON>O|n)|(?P<AY>A|y)|(?P<t>t)|(?P<past>)",
            "TENSE": "(FUT)?(TNS1)",
            "PERSON": "(?(ON)AGR-ON|(?(AY)AGR-AY|(?(t)AGR-T|(?(past)AGR-PAST))))",
            "AGR-ON": "",
            "AGR-AY": "(A|An|wA|wn|n|)",
            "AGR-T": "(yn|An|wn|n| )",
            "AGR-PAST": "(tmA|tm|tn|t|A|wA|n|)",
            "AGREE": "wn|yn|p|An|At|",
            "NOUN": "(CONJ)?(PREP)?(ART)(?P<stem>NSTEM)(AGREE)(PRON)?",
            "VERB": "(CONJ)?(TENSE)(?P<stem>VSTEM)(PERSON)?(VPRON)?"}

"""
For each pattern, replace anything that is in uppercase, possibly with digits,
and is in the set of patterns, by the expansion of its value in the set, i.e.
replace "CONJ" in "(CONJ)?(DEFART)?(STEM)(AGREE)?(PRON)?" by "w|B". Do this
recursively (e.g. VERBs contain TENSEs, but TENSEs contain FUTs and TNS1s)
"""
def expandpattern(p, patterns=patterns):
    for i in re.compile("([A-Z0-9]|-)+").finditer(p):
        i = i.group(0)
        if i in patterns:
            p = p.replace(i, "(?P<%s>%s)"%(i.replace("-", ""), expandpattern(patterns[i], patterns)))
    return p

"""
Do that for all your patterns.

Once you've done it, replace the values by compiled regexes that have ^ and $
to make sure that they match the whole string
"""
def expandpatterns(patterns=patterns):
    epatterns = {p:expandpattern(p, patterns) for p in patterns}
    for p in epatterns:
        print p, epatterns[p]
    for p in epatterns:
        try:
            epatterns[p] = re.compile("^"+epatterns[p]+"$")
        except:
            pass
    return epatterns

"""
Now just lookup the tag in the set of patterns and see if it matches your string

>>> m = lookupword("wsyktbwnh", "VERB")
>>> m = lookupword("wsyktbwnh", "NOUN")

This will give you a "match object". You can ask it what its stem is

>>> m.group("stem")
'ktb'

Or you can ask it what all its groups are: 

>> m.groups()
('w', 'sy', 's', 'y', 'ktb', 'wn', 'h')

It will go VERY fast. Million words a second or so.
"""

def lookupword(w, tag, expandedpatterns=expandpatterns()):
    return expandedpatterns[tag].match(w)



