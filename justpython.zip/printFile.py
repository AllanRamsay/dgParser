# -*- coding: utf-8 -*-
import sys
import re
import codecs

f = codecs.open('/home/P09/albogamf/dgParser/ofile', mode='a')
#for line in f:
print f.read()
print "OK"
#ofile.write('The')
#ofile.close()

