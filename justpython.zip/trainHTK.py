#!/usr/bin/python

import sys
import os
from htk import ArgException, train
import shutil
        
def trainHTK(argv):
    n = 500
    d = "."
    grammar = "grammar.txt"
    words2phones = "words2phones.txt"
    phonelengths = "phonelengths.txt"
    d = "."
    for i in range(1, len(argv), 2):
        flag = argv[i]
        value = argv[i+1]
        if flag[:2] == "--":
            flag = flag[1:]
        if "-grammar".startswith(flag):
            grammar = value
        elif "-words2phones".startswith(flag):
            words2phones = value
        elif "-phonelengths".startswith(flag):
            phonelengths = value
        elif flag =="-n":
            n = value
        elif "-directory".startswith(flag):
            d = value
        else:
            raise ArgException("Unrecognised flag: %s"%(flag))
    if not d == ".":
        try:
            print "Checking %s exists"%(d)
            os.mkdir(d)
        except Exception as e:
            pass
        shutil.copy(grammar, "%s/%s"%(d, grammar))
        shutil.copy(words2phones, "%s/%s"%(d, words2phones))
        shutil.copy(phonelengths, "%s/%s"%(d, phonelengths))
    train(grammar, words2phones, phonelengths, n, d)
        
if "trainHTK" in sys.argv[0]:
    try:
        trainHTK(sys.argv)
    except ArgException as e:
        print "%s: %s"%(e.__class__.__name__, e.msg)
        print """trainHTK.py --grammar <grammar> --words2phones <dict> --phonelengths <pldict> -n <N> --directory <dir>

directory defaults to ".", words2phones to "words2phones.txt",
phonelengths to "phonedict.txt", grammar to "grammar.txt", n to 500

Any of the flags may be abbreviated, e.g. --directory to --d
"""
