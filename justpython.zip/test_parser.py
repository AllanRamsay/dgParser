import conll
import COMP34411
from COMP34411 import *
import classes
import malt
import re
# import labeltagger as lt
# import backup as bu

sentences, pretagged = conll.readconll()
tagger = load('tagger.pck')
# parser = load('parserwithlabels.pck')
# sample = sentences

# rules = bu.getRepairrules(sentences=sentences, tagger=tagger, parser=parser, threshold=4, N=15000, K=15000)
# sample = trainingdata[0].sentence()
# s0 = parser.parse(sample, tagger=brilltagger)
# labeltagger = lt.getlabel(trainingdata)

# sentences, pretagged, brilltagger, parser, training, testing = train(metering=1, brilltagger=brilltagger, sentences=sample, pretagged=pretagged, qwindow=3, stackwindow=2, folds=5, tagsize=2, labeltagger=labeltagger)

sentences, pretagged, brilltagger, parser, training, testing = COMP34411.train(metering=1, brilltagger=tagger, sentences=sentences[0:30], pretagged=pretagged, qwindow=2, stackwindow=2, folds=5, tagsize=2)

# t = parser.classifier.show(maxlines=200)
# print t
