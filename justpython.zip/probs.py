import pylab

def dot(a, b):
    return pylab.array(a)*(pylab.array(b))
