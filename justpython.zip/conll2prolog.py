#!/usr/bin/python

"""

"""

import re, sys, os, subprocess, shutil
from useful import *
import a2bw, tidytraining, tidycorpus
import test_wholeprogram as wp

def conll2prolog(conll="ud-treebanks-v1.1/UD_ARBTWEETS/wholething.txt", out='constrained.pl', N=-1):
    """
    Convert the original stuff (from Fahad) to Prolog
    """
    tidycorpus.tidyCorpus(ifile="10kCorpus.txt", out="10ktidy.txt")
    tidycorpus.corpus2prolog(ifile="10ktidy.txt", out="10ksentences.pl", N=N)
    """
    Now ask the rule-based parser to generate the initial treebank
    """
    doInitialSegmentation("10ksentences.pl")

def makeTreeBank():l
    runChartParserAsParser()
    if not "\n" in conll:
        conll = open(conll).read()
    with safeout(out, encoding="UTF-8") as out:
        for index, sentence in enumerate([[x.split("\t") for x in s.split("\n")] for s in conll.split("\n\n")]):
            out("\n")
            source = []
            links = []
            try:
                for w in sentence:
                    source.append("('%s', '%s', '%s')"%(a2bw.convert(w[2], table=a2bw.bw2atable), w[1], w[3]))
                    dtr = int(w[0])-1
                    hd = int(w[6])-1
                    if hd >= 0:
                        links.append("linked(%s, %s, %s)"%(index, dtr, hd))
                out("constrained(%s, [%s], [%s]).\n\n"%(index, ", ".join(source), ", ".join(links)))
            except:
                pass

def doInitialSegmentation(sentences):
    process = "/usr/local/bin/sicstus -r parser.sav --goal consult('%s'),ppandhalt('segments.txt')."%(sentences)
    print process
    subprocess.Popen(process.split(" ")).wait()
    
def runChartParserAsParser():
    subprocess.Popen("/usr/local/bin/sicstus -r parser.sav --goal consult(segments),parse2conll('basetreebank.cnll'),halt.".split(" ")).wait()
    
def runChartParserAsFilter():
    subprocess.Popen("/usr/local/bin/sicstus -r parser.sav --goal consult(constrained),parseConstrained,halt.".split(" ")).wait()

def main():
    runChartParserAsFilter()
    tidytraining.tidytraining("reparsed.cnll", "reparsedtidy.cnll")
    os.remove("reparsed.cnll")
    os.rename("reparsedtidy.cnll", "reparsed.cnll")
    wp.wholething(parser=False, tagger=False, udt=".", language="", f="reparsed.cnll", maxrules=50)
    
if "conll2prolog" in sys.argv[0]:
    N=-1
    for flag in sys.argv[1:]:
        flag, value = flag.split("=")
        if flag=="N":
            N = int(value)
    conll2prolog(N=N)
    runChartParserAsParser("10ksentences.pl")
    main()
