#!/usr/bin/python

import sys
from htk import trainAsSeparateTask

def trainrec(argv):
    d = "TEMP"
    grammar = "grammar.txt"
    dict = "words2phones.txt"
    training = "trainingprompts.txt"
    iterations = 3
    for i in range(1, len(argv)):
        flag, value = argv[i].split("=")
        if flag == "dir":
            d = value
        elif flag == "dict":
            dict = value
        elif "prompts".startswith(flag):
            prompts = value
        elif "grammar".startswith(flag):
            grammar = value
        elif "iterations".startswith(flag):
            iterations = int(value)
        else:
            raise Exception("unknown flag: %s"%(flag))
    trainAsSeparateTask(d=d, dict=dict, grammar=grammar, training=training, iterations=iterations)
        
if "trainrec" in sys.argv[0]:
    try:
        trainrec(sys.argv)
    except Exception as e:
        print e
        print "trainrec dir=<dir> dict=<dict> grammar=<grammar> prompts=<prompts>"
