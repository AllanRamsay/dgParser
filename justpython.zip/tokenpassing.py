import numpy
import test1
reload(test1)
from tag import *

class HMMTAGGER(TAGGER):

    class STATE:

        def __init__(self, tag, prob):
            self.tag = tag
            self.prob = prob
        
    def __init__(self, dict, transitions):
        self.dict = dict
        self.transitions = transitions

    def tag(self, text):
        if isinstance(text, str):
            text = text.split(" ")
        text = ["AAA"]+text+["ZZZ"]
        states = self.dict["AAA"]
        return 
