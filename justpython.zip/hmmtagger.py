import numpy
import test1
reload(test1)
from tag import *

class STATE:

    def __init__(self, form, tag, baseprob, actualprob=0):
        self.tag = tag
        self.form = form
        self.baseprob = baseprob
        self.actualprob = actualprob
        self.previous = False

    def __repr__(self):
        return "state(%s, %s, %.4f, %.4f, %s)"%(self.form, self.tag, self.baseprob, self.actualprob, self.previous)

class HMMTAGGER(TAGGER):

    def __init__(self, dict, transitions, backwardtransitions=False):
        self.dict = dict
        self.transitions = transitions
        self.backwardtransitions = backwardtransitions

    def getstates(self, word):
        states = []
        print "WORD %s"%(word)
        try:
            tags = self.dict[word]
        except:
            while len(word) > 0:
                try:
                    tags = self.dict['-%s'%(word)]
                    break
                except:
                    word = word[1:]
        for tag in tags:
            states.append(STATE(word, tag, tags[tag]))
        return states

    def setbaseprob(self, state, i):
        if self.backwardtransitions and self.columns and i < len(self.columns)-1:
            t = 0
            for nextstate in self.columns[i+1]:
                try:
                    t += self.backwardtransitions[nextstate.tag][state.tag]*nextstate.baseprob
                except:
                    pass
            return t*state.baseprob
        else:
            return state.baseprob
            
    def tag(self, text):
        if isinstance(text, str):
            text = text.split(" ")
        columns = map(self.getstates, text)
        self.columns = columns
        for i, newstates in enumerate(columns):
            if i > 0:
                for state in oldstates:
                    self.setbaseprob(state, i)
                    for nextstate in newstates:
                        try:
                            tprob = self.transitions[state.tag][nextstate.tag]*state.actualprob*nextstate.baseprob**0.2
                            if tprob > nextstate.actualprob:
                                nextstate.actualprob = tprob
                                nextstate.previous = state
                                best = nextstate
                        except:
                            pass
            else:
                for state in newstates:
                    self.setbaseprob(state, i)
                    state.actualprob = state.baseprob
            normalise(newstates)
            oldstates = newstates
        best = newstates[0]
        for state in newstates[1:]:
            if state.actualprob > best.actualprob:
                best = state
        return best
            
def normalise(states):
    t = sum(state.actualprob for state in states)
    for state in states:
        state.actualprob *= 1/t
        
        
