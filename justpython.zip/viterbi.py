import numpy as np

"""
N: number of hidden states
"""
class Decoder(object):
    
    def __init__(self, initialProb, transProb, obsProb):
        self.N = initialProb.shape[0]
        self.initialProb = initialProb
        self.transProb = transProb
        self.obsProb = obsProb
        assert self.initialProb.shape == (self.N, 1)
        assert self.transProb.shape == (self.N, self.N)
        assert self.obsProb.shape[0] == self.N
        
    def Obs(self, obs):
        return self.obsProb[:, obs, None]

    def Decode(self, obs):
        """
        obs: array of observations. They've set them to 0/1
        here, which isn't that general: basically they're
        saying that they've got a set of binary features, and
        the array that is being called obs at this point 
        specifies which features are on and which are off
        
        backpt is an array the same size full of -1's: it will be used for remembering
        how you got to here
        """
        backpt = np.ones((self.N, len(obs)), 'int32') * -1

        """
        stage 0: how likely are you to be in one of the 
        initial states just by virtue of being at the start
        * how likely are you to be in that state given the
        current observation        
        """

        """
        step 0: multiply the likelihood of being in state_i
        just anyway by p(state_i|obs_0). squeeze changes
        this from a 1*N array to an N vector. Can't say
        that I understand what squeeze does in general, but
        that's what it does here.
        """
        currentstateprobs = np.squeeze(self.initialProb * self.Obs(obs[0]))
        print "len(obs) %s"%(len(obs))
        for t in xrange(1, len(obs)):
            """
            Using currentstateprobs[:, None] turns it back 
            into a 1*N array 
            """
            currentstateprobs = currentstateprobs[:, None]
            print "currentstateprobs %s"%(currentstateprobs)
            """
            Then tile turns this into an N*M array, so that
            we can then just multiply all the probs in one
            great big matrix multiplication: first argument
            of tile is how many vertical copies to make,
            second is how many horizontal copies (sort of)
            """

            """
            Part (i): fill an array with the likelihood of 
            getting to S_j from S_i for all i, j, and then 
            for each j finding the most likely previous i
            """
            backpt[:, t] = (np.tile(currentstateprobs, [1, self.N]) * self.transProb).argmax(0)
            """
            Part (ii): multiply current estimate of probability of each
            state by its likelihood given the current observations (what's going on here?
            This is a combination of how likely I was to be at S_j at time t (that's
            currentstateprobs) and how likely I am to be at S_i at time t+1 (that's
            obs[t])
            """
            currentstateprobs = currentstateprobs.dot(self.Obs(obs[t]).T)
            """
            Then multiply this by the appropriate transition probs
            """
            currentstateprobs = currentstateprobs * self.transProb
            """
            max(N) = get the max slice through
            dimension N. Here we've got a 2D array, so this
            gets us the max element of each column.
            """
            currentstateprobs = currentstateprobs.max(0)
        """
        Now just work your backwards through the trail of backpointers
        """
        tokens = [currentstateprobs.argmax()]
        for i in xrange(len(obs)-1, 0, -1):
            tokens.append(backpt[tokens[-1], i])
        return tokens[::-1]
