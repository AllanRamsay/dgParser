import COMP34411
from COMP34411 import *
import conll

sentences, pretagged = conll.readconll()

tagger = load('tagger.pck')
parser = load('parser2.pck')

import tblforparsing_new as tblp
testing = []
training = []
for i in range(len(sentences)):
    if i % 5 == 4:
        testing.append(sentences[i])
    else:
        training.append(sentences[i])

training = tblp.getTrainingData(training, parser=parser, tagger=tagger, parsed=False)
testing = tblp.getTrainingData(testing, parser=parser, tagger=tagger, parsed=False)
# print tblp.accuracy(trainingdata)
rules = tblp.getRepairrules(sentences=sentences, parser=parser, tagger=tagger, threshold=6, N=30000, K=5000, trainingdata=trainingdata,training=training,testing=testing)
# accuracy = tblp.accuracy(trainingdata)
# print accuracy