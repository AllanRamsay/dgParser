
import re, sys, codecs
from useful import *
import a2bw


p1 = re.compile("""\*+
(?P<arabic>\W+) *(?P<english>(\w| |'|,|\.)+)""", re.DOTALL)

def translate(ifile="patchedMerged.txt", outsink=sys.stdout):
    awords = {}
    ewords = {}
    with safeout(outsink) as write:
        for j, i in enumerate(p1.finditer(open(ifile).read())):
            for aword in a2bw.convert(i.group("arabic").decode("UTF-8"), a2bw.a2bwtable).split(" "):
                try:
                    awords[aword].append(j)
                except:
                    awords[aword] = [j]
            for eword in i.group("english").split(" "):
                try:
                    ewords[eword].append(j)
                except:
                    ewords[eword] = [j]
    return awords, ewords
            
