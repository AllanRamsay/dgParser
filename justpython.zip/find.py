#!/usr/bin/python

import sys
import re
import os

def find(top, pattern):
    pattern = re.compile(pattern)
    for path, dirs, files in os.walk(top):
        for f in files:
            if pattern.match(f):
                print "%s/%s"%(path, f)

if 'find.py' in sys.argv[0]:
    print sys.argv[2]
    find(sys.argv[1], sys.argv[2])
