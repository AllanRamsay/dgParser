from useful import *
import tag
import conll

reload(tag)
import re
from classes import *

if usingMac():
    BNC = '/Users/KEHOU/PycharmProjects/Parsing/BNC'
    programs = "/Users/KEHOU/PycharmProjects/Parsing"
else:
    BNC = '/opt/info/courses/COMP34411/PROGRAMS/BNC'
    programs = "/opt/info/courses/COMP34411/PROGRAMS"

METERING = 5  # METERING in here has to be an integer: 5 is a good value
tag.METERING = METERING


def getRepairrules(sentences=False, parser=False, tagger=False, threshold=4, S=0, N=20000, K=20000):
    N += K
    if sentences == False:
        sentences, pretagged = conll.readconll()
    trainingdata = getTrainingData(sentences, parser=parser, tagger=tagger)
    if METERING:
        print "Accuracy of parser on the training data (size %s): %s" % (
            len(trainingdata[S:-N]), accuracy(trainingdata[:-N])[0])
        print "Accuracy of parser on reserved data (size %s): %s" % (
            len(trainingdata[-N:]), accuracy(trainingdata[-N:])[0])
    templates = readTemplates()
    if METERING:
        print underline("Extracting TBL rules from half the reserved data (%s - %s)" % (-N, -K))
    rules = findAllInstances(templates, trainingdata[-N:-K], threshold=threshold)
    parser.rules = rules
    if METERING:
        print underline("Testing extracted TBL rules on the remainder of the reserved data (%s)" % (-K))
    parser.confusion = applyrules(trainingdata[-K:], rules, trainingsize=len(trainingdata[S:-N]))

    return rules


def getTrainingData(sentences, parser, tagger):
    outcome = []
    for i in range(len(sentences)):
        s = sentences[i].sentence()
        o = parser.parse(s, tagger=tagger)
        for j in range(len(sentences[i].leaves)):
            if j not in o.parsed:
                o.parsed[j] = RELATION(-1, j, 'root')
        outcome.append(o)
    trainingdata = []
    outsides = [False, False, False, "AA", False, False]
    for i in range(len(sentences)):
        for j in range(len(sentences[i].leaves)):
            if j == 0:
                trainingdata.append(outsides)
                trainingdata.append(outsides)
            form = sentences[i].leaves[j].form
            parent = outcome[i].parsed[j].hd - j
            gsparent = sentences[i].goldstandard[j].hd - j
            tag = sentences[i].leaves[j].tag[:2]
            if sentences[i].goldstandard[j].hd == -1:
                ptag = "AA"
                parentp = False
            else:
                ptag = sentences[i].leaves[gsparent + j].tag[0:2]
                parentp = sentences[i].goldstandard[gsparent+j].hd-gsparent-j

            # label = sentences[i].goldstandard[j].rel
            # labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'],
            #           'comp': ['ccomp', 'xcomp'],
            #           'mod': ['acl', 'amod', 'det', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod',
            #                   'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'],
            #           'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant',
            #                     'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux',
            #                     'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
            # for l in labels:
            #     if label in labels[l]:
            #         break
            # label = l
            instance = [form, parent, gsparent, tag, ptag, parentp]
            trainingdata.append(instance)
    trainingdata.append(outsides)
    trainingdata.append(outsides)
    return trainingdata


def accuracy(testdata):
    right = 0
    total = 0
    confusion = {}
    for x in testdata:
        if not x[3] == "AA":
            total += 1
            if x[1] == x[2]:
                right += 1
            incTableN([x[2], x[1]], confusion)
    return float(right) / float(total), confusion


def newaccuracy(testdata):
    right = 0
    total = 0
    for i in testdata:
        total += 1
        l = len(testdata[i])
        r = 0
        for j in testdata[i]:
            if j[1] == j[2]:
                r += 1
        if r == l:
            right += 1
    return float(right) / float(total)


def showConfusion(confusion):
    t = {}
    for x in confusion:
        t[x] = sortTable(confusion[x])
    s = [(t[x][1][1], x) if len(t[x]) > 1 else (0, x) for x in t]
    for x in reversed(sorted(s)):
        x = x[1]
        l = t[x]
        n = l[0][1]
        k = 0.0
        for p in l[1:]:
            k += p[1]
        if n + k == 0:
            print x, t[x]
        else:
            print x, t[x], "%.2f" % (float(n) / float(n + k))


templatePattern = re.compile("#(?P<name>.*?)\s*:\s(?P<d0>\w*)\s*>\s*(?P<d1>\w*)\s*if\s+(?P<conditions>.*?);", re.DOTALL)

templates = """
#t0(D0, D1, P0, P1): D0 > D1 if parent[0]=P0 and parentp[0]=P1;
#t1(D0, D1, P0, P1, P2): D0 > D1 if parent[0]=P0 and parentp[0]=P1 and parent[-1]=P2;
#t2(D0, D1, P0, P1, P2, P3): D0 > D1 if parent[0]=P0 and parentp[0]=P1 and parent[-1]=P2 and parent[1]=P3;
#t3(D0, D1, P0, T0): D0 > D1 if parent[0]=P0 and tag[0]=T0;
#t4(D0, D1, P0, T0, TP): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP;
#t5(D0, D1, P0, T0, TP, T1): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[-1]=T1;
#t6(D0, D1, P0, T0, TP, T1): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[1]=T1;
#t7(D0, D1, P0, T0, TP, T1, T2): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[1]=T1 and tag[-1]=T2;
"""
# """
# #t0(D0, D1, P0): D0 > D1 if parent[0]=P0;
# # t6(D0, D1, P0, T0, TP, T1, T2, L0): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[-1]=T1 and tag[1]=T2 and label[0]=L0;
# # t7(D0, D1, P0, T0, TP, T1, T2): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[1]=T1 and tag[2]=T2;
# # t8(D0, D1, P0, T0, TP, T1, T2): D0 > D1 if parent[0]=P0 and tag[0]=T0 and tagp[D1]=TP and tag[-1]=T1 and tag[-2]=T2;
# # """
# templates = """
# #t0(D0, D1, P0, P1): D0 > D1 if parent[0]=P0 and parentp[0]=P1;
# #t0(D0, D1, P0, P1, P2): D0 > D1 if parent[0]=P0 and parentp[0]=P1 and parent[-1]=P2;
# #t1(D0, D1, P0, P1, P2, P3): D0 > D1 if parent[0]=P0 and parentp[0]=P1 and parent[-1]=P2 and parent[1]=P3;
# """
conditionPattern = re.compile("(?P<what>\S*)\[(?P<range>(-?\d+(\s*,\s*-?\d+)*)|(\w*))\]\s*=(?P<value>\w*)\s*(and)?")


def makeRange(s):
    try:
        return [int(i) for i in re.compile("\s*,\s*").split(s)]
    except ValueError:
        return [i for i in re.compile("\s*,\s*").split(s)]


def readCondition(i):
    return [CONDITION(i.group("what").strip(), makeRange(r), i.group("value")) for r in
            i.group("range").strip().split("and")]


def readConditions(conditions):
    allconditions = []
    for i in conditionPattern.finditer(conditions):
        allconditions += readCondition(i)
    return allconditions


def inrange(i, l):
    return i >= 0 and i < len(l)


class CONDITION:
    @staticmethod
    def getword(i, words):
        return words[i][0]

    @staticmethod
    def getparent(i, words):
        return words[i][1]
    @staticmethod
    def getparentp(i, words):
        return words[i][5]
    @staticmethod
    def gettag(i, words):
        return words[i][3]

    @staticmethod
    def gettagp(word):
        return word[4]

    @staticmethod
    def getlabel(i, words):
        return words[i][5]

    @staticmethod
    def checkparent(i, r, words, target):
        for j in r:
            if inrange(i+j, words) and str(words[i+j][1]) == target:
                return True
        return False
    @staticmethod
    def checkparentp(i, r, words, target):
        for j in r:
            if str(words[i][5]) == target:
                return True
        return False
    @staticmethod
    def checktag(i, r, words, target):
        for j in r:
            if inrange(i+j, words) and words[i + j][3] == target:
                return True
        return False

    @staticmethod
    def checktagp(i, r, words, target):
        for j in r:
            if str(words[i][4]) == target:
                return True
        return False

    @staticmethod
    def checklabel(i, r, words, target):
        for j in r:
            if inrange(i+j, words) and words[i + j][5] == target:
                return True
        return False

    @staticmethod
    def checkword(i, r, words, target):
        for j in r:
            if inrange(i + j, words) and words[i + j][0] == target:
                return True
        return False

    @staticmethod
    def gstag(i, words):
        return words[i][2]

    def __init__(self, what, where, value):
        self.what = what
        self.where = where
        self.value = value
        self.func = eval('CONDITION.get%s' % what)

    def __repr__(self):
        return "%s%s=%s" % (self.what, self.where, self.value)

    def get(self, i, words):
        return self.func(i + self.where, words)

    def check(self, i, words, target):
        return self.func(i + self.where, words) == target


class TEMPLATE:
    def __init__(self, name, D0, D1, conditions):
        self.name = name
        self.D0 = D0
        self.D1 = D1
        self.conditions = readConditions(conditions)

    def __repr__(self):
        return "#%s: %s > %s if %s;" % (self.name, self.D0, self.D1, self.conditions)

    def instantiate(self, d):
        form = str(self)
        for k in d:
            form = form.replace(k, str(d[k]))
        return form

    @staticmethod
    def word(word):
        return word[0]

    @staticmethod
    def parent(word):
        return word[1]

    @staticmethod
    def gsparent(word):
        return word[2]

    @staticmethod
    def tag(word):
        return word[3]

    @staticmethod
    def label(word):
        return word[5]

    def findInstances(self, words, allinstances):
        for i in range(0, len(words)):
            if not words[i][3] == "AA":
                word = words[i]
                if not TEMPLATE.parent(word) == TEMPLATE.gsparent(word):
                    options = [[self.D0, [TEMPLATE.parent(word)]],
                               [self.D1, [TEMPLATE.gsparent(word)]]]
                    for c in self.conditions:
                        cd = []
                        for j in c.where:
                            if type(j) == 'int':
                                if inrange(i + j, words):
                                    cd.append(c.func(i + j, words))
                            else:
                                cd.append(c.func(word))
                        options.append([c.value, cd])
                    d = {}
                    enumerateall(options, d, (lambda: incTable("%s::%s" % (self.name, d), allinstances)))

    @staticmethod
    def tryReset(i, words, target):
        if str(words[i][1]) == target and str(words[i][2]) == target:
            return 0
        elif str(words[i][2]) == target:
            return 1
        else:
            return -1

    @staticmethod
    def doReset(i, words, tag):
        print words[i]
        words[i][1] = int(tag)
        print words[i]
        return True

    def makeInstance(self, dict):
        s = ""
        for c in self.conditions:
            c = """CONDITION.check%s(i, %s, words, "%s")""" % (c.what, c.where, dict[c.value])
            if s == "":
                s = "%s" % (c)
            else:
                s += " and %s" % (c)
        s = """(lambda i, words: TEMPLATE.tryReset(i, words, "%s") if %s else 0)""" % (dict[self.D1], s)
        s = s.replace('"""', """'"'""")
        f = eval(s)
        f.src = s
        return f

    def makeRule(self, dict):
        s = ""
        for c in self.conditions:
            c = """CONDITION.check%s(i, %s, words, "%s")""" % (c.what, c.where, dict[c.value])
            if s == "":
                s = "%s" % (c)
            else:
                s += " and %s" % (c)
        s = """(lambda i, words: TEMPLATE.doReset(i, words, "%s") if %s else 0)""" % (dict[self.D1], s)
        s = s.replace('"""', """'"'""")
        f = eval(s)
        f.src = s
        return f


class RULE:
    def __init__(self, template, reset, grossScore, netScore):
        self.template = template
        self.reset = reset
        self.grossScore = grossScore
        self.netScore = netScore

    def __str__(self):
        return "RULE(%s, %s, grossScore:%s, netScore: %s)" % (
            self.template, self.reset.src, self.grossScore, self.netScore)

    def __call__(self, i, text):
        """
        We may have converted reset back into a string in order to pickle it,
        so if this goes wrong we will eval it (and set that as the value of reset)
        """
        try:
            return self.reset(i, text)
        except TypeError:
            r = self.reset
            self.reset = eval(r)
            self.reset.src = r
            return self.reset(i, text)

    def removeFunctions(self):
        self.reset = self.reset.src


def enumerateall(options, instance, task):
    if options == []:
        task()
    else:
        x, l = options[0]
        for y in l:
            instance[x] = y
            enumerateall(options[1:], instance, task)
            del instance[x]


def checkvar(var, value, table):
    if var in table:
        return table[var] == value
    else:
        table[var] = value
        return True


def readTemplates(templates=templates):
    alltemplates = []
    for t in [TEMPLATE(i.group('name'), i.group('d0'), i.group('d1'), i.group('conditions')) for i in
              templatePattern.finditer(templates)]:
        alltemplates.append(t)
    return alltemplates

def findAllInstances(templates, text, threshold=3):
    text = [list(t) for t in text]
    threshold = threshold
    if METERING:
        print "Initial score %.4f\nThreshold %s, dataset %s" % (float(accuracy(text)[0]), threshold, len(text))
    templatetable = {}
    for t in templates:
        templatetable[t.name] = t
    rules = []
    while True:
        allinstances = {}
        if METERING:
            print underline("Finding initial instances")
        for t in templates:
            t.findInstances(text, allinstances)
        if METERING:
            print "Found--reorganising them"
        instances = []
        for i in allinstances:
            k, d = i.split("::")
            d = eval(d)
            f = templatetable[k].makeInstance(d)
            instances.append([allinstances[i], f, k, d])
        instances.sort()
        instances.reverse()
        if METERING:
            print underline("Top %s candidate rules" % (METERING))
            for x in instances[:METERING]:
                print "Candidate rule %s: gross score %s" % (templatetable[x[2]].instantiate(x[3]), x[0])
        bestscore = 0
        best = False
        if METERING:
            print "Sorted--scoring them"
        l = []
        for i in instances:
            f = i[1]
            if i[0] < bestscore:
                break
            score = 0
            for j in range(len(text)):
                score += f(j, text)
            i.append(score)
            if score > bestscore:
                bestscore = score
                best = i
            if METERING:
                l.append((i[-1], i))
        if bestscore < threshold:
            break
        r = makeRule(best, templatetable)
        if METERING:
            print underline("Top %s net scoring rules") % (METERING)
            l.sort()
            l.reverse()
            for i in l[:METERING]:
                t = makeRule(i[1], templatetable)
                print "rule: %s, gross score %s, net score %s" % (t.template, t.grossScore, t.netScore)
        for j in range(len(text)):
            r(j, text)
        if METERING:
            print "Score %.4f" % (float(accuracy(text)[0]))
        rules.append(r)
    return rules


def makeRule(k, templatetable):
    t = str(templatetable[k[2]])
    f = k[1]
    for x in k[3]:
        t = t.replace(x, str(k[3][x]))
    f.template = t
    t = templatetable[k[2]]
    d = k[3]
    return RULE(t.instantiate(d), t.makeRule(d), k[0], k[-1])


def applyrules(testdata, rules, trainingsize=0):
    before = accuracy(testdata,)[0]
    testdata = [list(t) for t in testdata]
    for rule in rules:
        print rule
        for i in range(len(testdata)):
            rule(i, testdata)
    after, confusion = accuracy(testdata)
    if METERING:
        print "Before repairing %s (training size = %s)" % (before, trainingsize)
        print "After repairing %s (training size = %s)" % (after, trainingsize)
        # print underline("Confusion matrix")
        # tag.showConfusion(confusion)
    else:
        print ", %s, %s" % (before, after)
    return confusion


# def plot(pretagged, p=1.5, n0=500, n1=40000):
#     while n0 < n1:
#         print n0
#         rules = trainwithmxlandbrill(pretagged=pretagged, N=n0, mxltagsize=2, tagsize=2, atagsize=2)
#         n0 = int(p*n0)

import math


def importdict(targetdict, importeddict):
    for x in importeddict:
        NN = 0
        VV = 0
        for k in importeddict[x]:
            if k[0] == 'N':
                NN += importeddict[x][k]
            elif k[0] == 'V':
                VV += importeddict[x][k]
        if (NN > 0 or VV > 0) and not x in targetdict:
            targetdict[x] = {}
        if NN > 0:
            targetdict[x]['NN'] = math.sqrt(NN)
        if VV > 0:
            targetdict[x]['VB'] = math.sqrt(VV)
        if NN > 0 or VV > 0:
            normalise(targetdict[x])
