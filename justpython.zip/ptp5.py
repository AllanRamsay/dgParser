"""
PTP.PY

Prolog-style backward chaining theorem prover, using continuations to
manage the backtracking. The key idea here is you pass "the next thing
to do" in as an argument called the "continuation". If you succeed in
the current step, then you call the continuation. In this paradigm,
returning from the current function = failure.

You have to turn the way you think about function calls upside-down:
f(c) will call c if f succeeds, and will return if it doesn't. It's
neat, because it means we can use the Python calling stack to manage
both the calling stack and the backtracking stack for the theorem
prover, but you do have to get used to it.

This program comes in seveal pieces: a parser for reading rules, a set
of class definitions which include the code for turning a rule into a
Python function (this is the key to it all, and is buried in the
"rule" method of "TERM"), and the machinery (particularly the
unification algorithm) which is used to drive the execution.
"""
#import antonyms
import re, sys, os
import cPickle
from rules import factsAndRules
from useful import *
from forceparse import *

"""
Making terms
"""

try:
    tagger, parser
    print "tagger and parser already loaded"
except:
    tagger = cPickle.load(open("tagger.pck"))
    parser = cPickle.load(open("parser.pck"))

try:
    hh, hyps
    print "hh and hyps already loaded"
except:
    hh = cPickle.load(open("hyps.pck"))
    hyps = cPickle.load(open("AllHyps.pck"))

def proving(INDENT, functor, args, rule):
    print '%s%s%s using %s'%(INDENT, functor, args, rule)
    return True

def failed(INDENT, functor, args):
    print '%s%s%s failed'%(INDENT, functor, args)
    return False

def succeeded(INDENT, functor, args, CONTN):
    print '%s%s%s succeeded'%(INDENT, functor, args)
    CONTN()
    return False

class TermException(Exception):

    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return "TermException(%s)"%(self.msg)
    
vpattern = re.compile("(?P<VNAME>[A-Z]\w*)")

def toList(x):
    try:
        return x.toList()
    except:
        return x

class TERM:

    def __init__(self, functor, args=[]):
        if functor.islower():
            self.functor = "%s%s"%(functor, len(args))
        else:
            self.functor = functor
        self.args = args
        self.consequent = self
        self.antecedent = []

    def __repr__(self):
        if self.args == []:
            return self.functor
        elif self.functor in ops:
            return "%s %s %s"%(str(self.args[0]), self.functor, str(self.args[1]))
        else:
            return "%s(%s)"%(self.functor, ", ".join([str(x) for x in self.args]))
        
    def __str__(self):
        return self.__repr__()

    def __call__(self, contn):
        print eval("%s"%(self.functor))

    """
    If one of the arguments of the head is a complex term,
    you have to replace it by a variable which is unified
    with that term. Arguments of the head that are just
    variables can be left as they are.

    If one of the arguments of a subgoal is a complex term,
    you simply call the subgoal with that item as the
    argument
    """
    
    def defn(self):
        allvars = {i.group("VNAME"):True for i in vpattern.finditer(str(self))}
        args = []
        argsv = {}
        vinitials = ""
        i = 0
        for arg in self.consequent.args:
            if type(arg) == "VARIABLE":
                args.append(arg.functor)
            else:
                v = "_V%s_"%(i)
                args.append(v)
                try:
                    argsv[v] = vpattern.sub("\g<VNAME>", str(arg.toList()))
                except:
                    argsv[v] = arg
                i += 1
        for v in allvars:
            if not v in args:
                w = "_V%s_"%(i)
                i += 1
                vinitials += "\n    %s = VARIABLE('%s')"%(v, w)
        args = ",".join(args)
        if not args == "":
            args += ","
        contn = '(lambda: succeeded(INDENT, "%s", (%s), CONTN))'%(self.consequent.functor, args)
        keys = sorted(argsv.keys())
        if keys == []:
            unifiers = self.subgoals(contn)
        elif len(keys) == 1:
            unifiers = "unify(%s, %s, %s, INDENT)"%(keys[0],argsv[keys[0]], self.continuation(contn))
        else:
            unifiers = "unify(["
            for a in keys:
                unifiers += "%s, "%(a)
            unifiers += "], ["
            for a in keys:
                unifiers += "%s, "%(argsv[a])
            unifiers += "], %s, INDENT)"%(self.continuation(contn))
        return """def %s((%s), CONTN, INDENT, RULES):%s
    proving(INDENT, "%s", (%s), "%s ==> %s")
    %s
    failed(INDENT, "%s", (%s))
"""%(self.consequent.functor, args, vinitials, self.consequent.functor, args, self.antecedent, self.consequent, unifiers, self.consequent.functor, args)
    
    def subgoals(self, contn):
        args = ", ".join([vpattern.sub("\g<VNAME>", str(toList(a))) for a in self.args])
        return "RULES['%s']((%s,), %s, INDENT+' ', RULES)"%(self.functor, args, contn)

    def continuation(self, contn):
        return contn

    def deref(self):
        args = []
        for a in self.args:
            try:
                args.append(a.deref())
            except:
                args.append(a)
        return TERM(self.functor, args)
            
    def toList(self):
        args = []
        for arg in self.args:
            try:
                args.append(arg.toList())
            except:
                args.append(arg)
        return [self.functor]+args
    
class CONJUNCTION(TERM):

    def __init__(self, functor, args):
        TERM.__init__(self, functor, args)
        self.conj1 = args[0]
        self.conj2 = args[1]
    
    def subgoals(self, contn):
        return "%s"%(self.conj1.subgoals("lambda : %s"%(self.conj2.subgoals(contn))))

class RULE(TERM):

    def __init__(self, functor, args):
        TERM.__init__(self, functor, args)
        self.antecedent = args[0]
        self.consequent = args[1]
    
    def subgoals(self, contn):
        return self.antecedent.subgoals(contn)

    def continuation(self, contn):
        return "lambda : %s"%(self.subgoals(contn))
        
class VARIABLE(TERM):

    def __init__(self, functor):
        TERM.__init__(self, functor)
        self.value = "???"
        
    def __repr__(self):
        d = self.deref()
        try:
            return d.functor
        except:
            return str(d)
        
    def subgoals(self, contn):
        raise TermException("Cannot use variable as subgoal: %s"%(self.functor))

    def toList(self):
        return self

    def deref(v):
        while type(v) == "VARIABLE" and not v.value == "???":
            v = v.value
        return v
        
class ATOM(TERM):

    def __init__(self, functor):
        TERM.__init__(self, functor)
        
    def subgoals(self, contn):
        return "%s"%(contn)

    def toList(self):
        return self.functor

def deref(t):
    while type(t) == "VARIABLE":
        if t.value == "???":
            return t
        t = t.value
    return t

class SUCCESS(Exception):

    def __init__(self, msg):
        self.msg = msg
        pass

def makeTerm(functor, args, vars={}):
    if args == []:
        try:
            return int(functor)
        except:
            pass
        if functor[0].isupper():
            try:
                return vars[functor]
            except:
                v = VARIABLE(functor)
                vars[functor] = v
                return v
        else:
            return ATOM(functor)
    else:
        return TERM(functor, args)

def parseOpSeq(opseq):
    if len(opseq) == 1:
        return opseq[0]
    best = 10000
    top = False
    for x in opseq:
        if x in ops and ops[x] < best:
            best = ops[x]
            top = x
    seq1 = []
    while True:
        x, opseq = opseq[0], opseq[1:]
        if x in ops and ops[x] == best:
            break
        seq1.append(x)
    seq2 = opseq
    if top == "==>":
        return RULE(top, [parseOpSeq(seq1), parseOpSeq(seq2)])
    elif top == "&":
        return CONJUNCTION(top, [parseOpSeq(seq1), parseOpSeq(seq2)])
    else:
        return makeTerm(top, [parseOpSeq(seq1), parseOpSeq(seq2)], vars=vars)
        
ops = {"&":5, "or":6, "==>":4}
atomPattern = re.compile("\s*(?P<atom>(\w+))\s*(?P<rest>.*)", re.DOTALL)

def readAtom(s, indent="", debug=False):
    if debug:
        print "%sreadAtom: s='%s'"%(indent, s)
    m = atomPattern.match(s)
    return m.group("atom"), m.group("rest").strip()

def readTerm(s, brackets=[], indent="", closer=".", debug=False, vars={}):
    if debug:
        print "%sreadTerm: s ='%s', vars=%s"%(indent, s, vars)
    if len(s) > 0 and (s[0] == "(" or s[0] == "["):
        terms, brackets, s = readTerms(s[1:], brackets+[s[0]], indent=indent+" ", closer=s[0], debug=debug, vars=vars)
        if debug: print "bracketed term: terms='%s', brackets='%s', s='%s'"%(terms, brackets, s)
        return terms, brackets, s
    else:
        term, s = readAtom(s, indent=indent+" ", debug=debug)
    if debug:
        print "%sf='%s', s='%s'"%(indent, term, s)
    if s[:len(closer)] == closer:
        if brackets == []:
            return makeTerm(term, [], vars=vars), brackets, s
        raise TermException("End of input: closing bracket required (brackets = %s)"%(brackets))
    if s[0] == "(" or s[0] == "[":
        terms, brackets, s = readTerms(s[1:], brackets+[s[0]], closer=closer, indent=indent+" ", debug=debug, vars=vars)
    else:
        terms = []
    term = makeTerm(term, terms, vars=vars)
    if s[0] in [")", ",", "]"]:
        return term, brackets, s
    return term, brackets, s.strip()

def readTermsAndOps(s, brackets=[], indent="", closer=".", debug=False, vars={}):
    readNextOp = True
    termsandops = []
    while readNextOp:
        if debug: print "%sreadNextOp: s='%s'"%(indent, s)
        term, brackets, s = readTerm(s, brackets=[], indent=indent+" ", closer=closer, debug=debug, vars=vars)
        termsandops.append(term)
        readNextOp = False
        for op in ops:
            if s[:len(op)] == op:
                readNextOp = True
                termsandops.append(op)
                s = s[len(op):].strip()
                break
    if len(termsandops) == 1:
        term = termsandops[0]
    else:
        term = parseOpSeq(termsandops)
    return term, brackets, s
            
def readTerms(s, brackets, closer=".", indent="", debug=False, vars={}):
    if debug:
        print "%sreadTerms s ='%s', vars=%s"%(indent, s, vars)
    terms = []
    while True:
        if debug:
            print "%sread more terms s ='%s'"%(indent, s)
        term, brackets1, s = readTermsAndOps(s, brackets, closer=closer, indent=indent+" ", debug=debug, vars=vars)
        if debug:
            print "%sTerm read: term='%s', s='%s'"%(indent, term, s)
        terms.append(term)
        if s[:len(closer)] == closer:
            raise TermException("End of input: closing bracket or comma required")
        if s[0] == ",":
            s = s[1:].strip()
            continue
        if s[0] == ")" or s[0] == "]":
            if debug:
                print "%slast arg found: terms=%s, s='%s'"%(indent, terms, s)
            return terms, brackets[:-1], s[1:].strip()
        raise TermException("Closing bracket or comma expected, %s found"%(s[0]))

def readterm(s, closer=".", debug=False):
    vars = {}
    t, brackets, s = readTermsAndOps(s, [], closer=closer, debug=debug, vars=vars)
    t.vars = vars
    if not s[:len(closer)] == closer:
        raise TermException("'%s' expected at end of term, '%s' found"%(closer, s))
    if not brackets == []:
        raise TermException("Closing bracket required: %s"%(brackets))
    return t, s
 
def tryit(c):
    try:
        c()
    except SUCCESS as e:
        raise e
    except Exception as e:
        return e

tagequivs = {"j":"a"}

def tagequiv(t):
    t = t.lower()[0]
    try:
        return tagequivs[t]
    except:
        return t
    
def wordwithpostag(x):
    if type(x) == "list" and len(x) == 2 and type(x[1]) == "str":
        t = x[1][0].lower()
        try:
            return tagequivs[t]
        except:
            return t
    else:
        return False

def unify(t1, t2, cont, INDENT, hh, confidence=False):
    if confidence == False:
        confidence = [1]
    c0 = confidence[0]
    if c0 < 0.5:
        return
    t1 = deref(t1)
    t2 = deref(t2)
    print "%sunify(%s (%s), %s (%s))"%(INDENT, t1, type(t1), t2, type(t2))
    if t1 == t2:
        tryit(cont)
    if type(t1) == 'str' and type(t2) == 'str' and t1 in hh and t2 in hh[t1]:
        print "%sTesting subsumption: %s, %s"%(INDENT, t1, t2)
        tryit(cont)
    if type(t1) == 'WORD' and type(t2) == 'WORD' and (True or (t1.tag == t2.tag or t1.tag in (tagger.basetagger.tag(t2.root, getAll=True)[0][1]))):
        tag1 = tagequiv(t1.tag)
        tag2 = tagequiv(t2.tag)
        form1 = t1.root
        form2 = t2.root
        pol1 = t1.polarity
        pol2 = t2.polarity
        print "%sTesting subsumption on words: %s (%s: %s), %s (%s: %s)"%(INDENT, t1, tag1, pol1, t2, tag2, pol2)
        if pol1 == pol2:
            if form1 == form2 or (pol1 == "+" and ((form2 in hh[tag2] and form1 in hh[tag2][form2]) or (form2 in hh[tag1] and form1 in hh[tag1][form2])))\
              or (pol1 == "-" and form1 in hh[tag1] and form2 in hh[tag1][form1]):
                tryit(cont)
        else:
            print "%sAre they antonyms: %s, %s"(INDENT, form1, form2)
            if antomys.is_antonym(form1, form2):
                print "yes"
                tryit(cont)
            else:
                print "no"
            
            """
            if pol1 is - and pol2 is + and form1 is an antonym of form2 or is subsumed by (subsumes) an antonym of form2 or something like that:
                tryit(cont)
            """
    elif type(t1) == "VARIABLE":
        t1.value = t2
        tryit(cont)
        t1.value = "???"
    elif type(t2) == "VARIABLE":
        t2.value = t1
        tryit(cont)
        t2.value = "???"
    elif type(t1) == "TERM" and type(t1) == "TERM" and t1.functor == t2.functor:
        unify(t1.args, t2.args, cont, INDENT+' ', hh, confidence=confidence)
    elif type(t1) == "list" and type(t2) == "list":
        print "%sBoth are lists: %s, %s"%(INDENT, t1, t2)
        if t1 == [] and t2 == []:
            print "%sboth empty: on we go"%(INDENT)
            tryit(cont)
            return False
        if len(t1) > 0 and len(t2) > 0:
            unify(t1[0], t2[0], lambda: unify(t1[1:], t2[1:], cont, INDENT+' ', hh, confidence=confidence), INDENT+' ', hh, confidence=confidence)
        if len(t2) > len(t1):
            if type(t2[0]) == "list" and not t2[0] == [] and type(t2[0][0]) == "WORD":
                tag2 = t2[0][0].tag
                print "%sSkipping one (tag %s): confidence %s"%(INDENT, tag2, confidence)
                costs = {"DT":0.3, "JJ":0.05}
                if tag2 in costs:
                    confidence[0] = c0-costs[tag2]
                    print "%sconfidence is now %s"%(INDENT, confidence)
                    unify(t1, t2[1:], cont, INDENT+' ', hh, confidence=confidence)
                    confidence[0] = c0
    return False
    
def testGoal(g):
    try:
        return g()
    except SUCCESS:
        return True
        
def success(g):
    raise SUCCESS(str(g))

def swappolarity(w):
    w.polarity = "-" if w.polarity == "+" else "-"
    
def promotenot(t):
    negate = False
    dtrs = t[1:]
    for i in range(len(dtrs)):
        d = dtrs[0]
        if d[0].form == "not":
            dtrs = dtrs[:i]+dtrs[i+1:]
            t[1:] = dtrs
            swappolarity(t[0])
            break
    for d in dtrs:
        promotenot(d)

def matchPattern(t, p, bindings=False):
    if isinstance(bindings, bool):
        bindings = {}
    if p[0] == "?":
        v = p[1:]
        try:
            if bindings[v] == t:
                return bindings
            else:
                raise Exception("already bound differently")
        except:
            bindings[v] = t
            return bindings
    else:
        if t[0][1] == p[0]:
            for dt, dp in zip(t[1:], p[1:]):
                if not matchPattern(dt, dp, bindings):
                    raise Exception("no match")
            return bindings
        else:
            raise Exception("no match")

def prove(goal, assumptions):
    try:
        bindings = matchPattern(goal, ["be", "?X", "?Y"])
    except:
        return False
        
        
"""
['be', ['cat', ['all']], ['mammal']]
['be', ['mammal', ['all']], ['animal']]
['be', ['Splodge'], ['cat', ['a']]]
----------------------------------------
['be', ['cat', ['all']], ['animal']]
['be', ['Splodge'], ['animal', ['a']]]

all cats are animals

because

all mammals are animals and all cats are mammals

Splodge is an animal 

because 
all mammals are animals and all cats are mammals and Splodge is a cat

So the pattern is

[be, K, [Z, a]]

if [be, K, [X, a]] and [be, [X, all], [Y, all]] and [be, [Y, all], [Z, all]]

What we'd like is [be, A, D] if [be, A, B] and [be, B, C] and [be, C, D]
or [be, A, D] if [be, C, D] and [be, B, C] and [be, A, B]

That will easily do "all cats are animals". 
What about "Splodge is a mammal"? 



[('love', 'VB'), 
 [('girl', 'NN'), [('every', 'DT')]], 
 [('sailor', 'NN'), [('a', 'DT')]]]
[('be', 'VX'), 
 [('Mary', 'PN')], 
 [('girl', 'NN'), [('a', 'DT')]]]
 --------------------------------
 [('like', 'VB'), 
 [('Mary', 'PN')], 
 [('sailor', 'NN'), [('a', 'DT')]]]
 
To prove [V N1 N2] you want [V' N1' N2'] where
V' -> V, N1' -> N1, N2' -> N2


"""
