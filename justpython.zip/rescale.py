#!/usr/bin/python

import sys, subprocess, os

def rescale(d="."):
    for f in os.listdir(d):
        print f
        if f[-4:] == ".wav":
            print f
            cmd = "sox %s/%s -r 8000 %s/%s8.wav"%(d, f, d, f[:-4])
            subprocess.Popen(cmd.split(" ")).wait()
            os.rename("%s/%s8.wav"%(d, f[:-4]), "%s/%s"%(d, f))
            
if "rescale" in sys.argv[0]:
    dir = "."
    for x in sys.argv[1:]:
        k, v = x.split("=")
        if k == "dir":
            dir = v
    rescale(dir)
    
