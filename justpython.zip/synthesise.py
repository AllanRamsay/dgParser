#!/usr/bin/python

import sys
from useful import *

if sys.platform == "darwin":
    whichPraat = "Praat"
elif sys.platform == "linux2":
    whichPraat = "praat64"
else:
    whichPraat = "praat"

def synth(text, dir="TEMP", outfile="temp.Praat"):
    if not outfile == sys.stdout:
        outfile = "%s/%s"%(dir, outfile)
    with safeout(outfile) as out:
        text = text.strip().split()
        for word in text:
            out("""
Read from file: "%s.wav"
"""%(word))
        select = "selectObject"
        for word in text:
            out("""
%s: "Sound %s"
"""%(select, word))
            select = "plusObject"
        out("""
Concatenate
Write to WAV file... synthesised.wav
Play
""")
    if not outfile == sys.stdout:
        execute("%s %s"%(whichPraat, outfile))

if "synthesise" in sys.argv[0]:
    d = "TEMP"
    for i in range(1, len(sys.argv)):
        flag, value = sys.argv[i].split("=")
        if flag == "dir":
            d = value
        elif flag == "text":
            text = value
        else:
            raise Exception("Unknown flag %s"%(flag))
    try:
        synth(text, dir=d)
    except Exception as e:
        print e
        print """synthesise.py text="the cat sat" dir=<dir>"""
