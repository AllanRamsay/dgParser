import datetime
import classes
from classes import RELATION
from useful import underline

METERING = 3


def getSubTree1(dtree, subtree={}, parsed=False):
    TREE = False
    if not len(dtree) == 1:
        TREE = True
    if TREE:
        hd = [dtree[0].form] + [t[0].form for t in dtree[1:]]
        key = ""
        for i in sorted(hd):
            key += i
        subtree[key] = []
        subtree[key].append(parsed.leaves[dtree[0].position].tag[:2])
        subtree[key].append([])
        for dtr in dtree[1:]:
            subtree[key][-1].append(parsed.leaves[dtr[0].position].tag[:2])
            getSubTree1(dtr, subtree=subtree, parsed=parsed)
    return subtree

def getSubTree2(dtree, subtree={}, parsed=False):
    TREE = False
    if not len(dtree) == 1:
        for i in dtree[1:]:
            if not len(i) == 1:
                TREE = True
                break
    if TREE:
        hd = [dtree[0].form]
        for i in dtree[1:]:
            hd.append(i[0].form)
            if not len(i) == 1:
                for j in i[1:]:
                    hd.append(j[0].form)
        key = ""
        for i in sorted(hd):
            key += i
        subtree[key] = []
        subtree[key].append(parsed.leaves[dtree[0].position].tag[:2])
        for dtr in dtree[1:]:
            subtree[key].append([parsed.leaves[dtr[0].position].tag[:2]])

            if not len(dtr) == 1:
                subtree[key][-1].append([])
                for leaf in dtr[1:]:
                    subtree[key][-1][-1].append(parsed.leaves[leaf[0].position].tag[:2])
            getSubTree2(dtr, subtree=subtree, parsed=parsed)
    return subtree

def getSubTree(dtree, parsed=False):
    subtree = {}
    st1 = getSubTree1(dtree, subtree={}, parsed=parsed)
    for i in st1:
        subtree[i] = str(st1[i])
    st2 = getSubTree2(dtree, subtree={}, parsed=parsed)
    for i in st2:
        subtree[i] = str(st2[i])
    return subtree

def getSubTree1head(dtree, gs=False, parsed=False,subtree={}, PARSED=False,GS=False):
    TREE = False
    if not len(dtree) == 1:
        TREE = True
    if TREE:
        hd = [dtree[0].form] + [t[0].form for t in dtree[1:]]
        key = ""
        for i in sorted(hd):
            key += i
        subtree[key] = []
        if PARSED:
            hd = parsed.parsed[dtree[0].position].hd
        if GS:
            hd = gs.goldstandard[dtree[0].position].hd
            # labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'], 'comp':['ccomp', 'xcomp'], 'det': ['det'], 'mod': ['acl', 'amod', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'], 'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
            # for i in labels:
            #     if hd in labels[i]:
            #         hd = i
            #         break
        # subtree[key].append(hd)
        subtree[key].append(hd - dtree[0].position)

        subtree[key].append([])
        for dtr in dtree[1:]:
            if PARSED:
                hd = parsed.parsed[dtr[0].position].hd
            if GS:
                hd = gs.goldstandard[dtr[0].position].hd
            #     labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'], 'comp':['ccomp', 'xcomp'], 'det': ['det'], 'mod': ['acl', 'amod', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'], 'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
            #     for i in labels:
            #         if hd in labels[i]:
            #             hd = i
            #             break
            # subtree[key][-1].append(hd)
            subtree[key][-1].append(hd - dtr[0].position)
            getSubTree1head(dtr, subtree=subtree, PARSED=PARSED, GS=GS, parsed=parsed, gs=gs)
    return subtree

def getSubTree2head(dtree, subtree={}, gs=False, parsed=False, PARSED=False, GS=False):
    TREE = False
    if not len(dtree) == 1:
        for i in dtree[1:]:
            if not len(i) == 1:
                TREE = True
                break
    if TREE:
        hd = [dtree[0].form]
        for i in dtree[1:]:
            hd.append(i[0].form)
            if not len(i) == 1:
                for j in i[1:]:
                    hd.append(j[0].form)
        key = ""
        for i in sorted(hd):
            key += i
        subtree[key] = []
        if PARSED:
            hd = parsed.parsed[dtree[0].position].hd
        if GS:
            hd = gs.goldstandard[dtree[0].position].hd
        #     labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'], 'comp':['ccomp', 'xcomp'], 'det': ['det'], 'mod': ['acl', 'amod', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'], 'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
        #     for i in labels:
        #         if hd in labels[i]:
        #             hd = i
        #             break
        # subtree[key].append(hd)
        subtree[key].append(hd - dtree[0].position)
        subtree[key].append([])
        for dtr in dtree[1:]:
            if PARSED:
                hd = parsed.parsed[dtr[0].position].hd
            if GS:
                hd = gs.goldstandard[dtr[0].position].hd
            #     labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'], 'comp':['ccomp', 'xcomp'], 'det': ['det'], 'mod': ['acl', 'amod', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'], 'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
            #     for i in labels:
            #         if hd in labels[i]:
            #             hd = i
            #             break
            # subtree[key][-1].append(hd)
            subtree[key][-1].append(hd-dtr[0].position)
            if not len(dtr) == 1:
                subtree[key][-1].append([])
                for leaf in dtr[1:]:
                    if PARSED:
                        hd = parsed.parsed[leaf[0].position].hd
                    if GS:
                        hd = gs.goldstandard[leaf[0].position].hd
                    #     labels = {'subj': ['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj': ['dobj'], 'iobj': ['iobj'], 'comp':['ccomp', 'xcomp'], 'det': ['det'], 'mod': ['acl', 'amod', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case': ['case'], 'root': ['root'], 'other': ['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
                    #     for i in labels:
                    #         if hd in labels[i]:
                    #             hd = i
                    #             break
                    # subtree[key][-1][-1].append(hd)
                    subtree[key][-1][-1].append(hd - leaf[0].position)
            getSubTree2head(dtr, subtree=subtree, PARSED=PARSED, GS=GS, parsed=parsed, gs=gs)
    return subtree


def getSubTreehead(dtree, gs=False, parsed=False, PARSED=False, GS=False):
    subtree = {}
    st1 = getSubTree1head(dtree, subtree={}, gs=gs, parsed=parsed, GS=GS, PARSED=PARSED)
    for i in st1:
        subtree[i] = str(st1[i])
    st2 = getSubTree2head(dtree, subtree={}, gs=gs, parsed=parsed, GS=GS, PARSED=PARSED)
    for i in st2:
        subtree[i] = str(st2[i])
    return subtree



def preProcess(sentences, parser, tagger):
    parsed = []
    for i in range(len(sentences)):
        s = sentences[i].sentence()
        o = parser.parse(s, tagger=tagger)
        for j in range(len(sentences[i].leaves)):
            if j not in o.parsed:
                o.parsed[j] = RELATION(-1, j, 'root')
        parsed.append(o)
    return parsed


def getTrainingdata(sentences, parser, tagger, TAG=True):
    parsed = []
    trainingdata = []
    for i in range(len(sentences)):
        s0 = sentences[i].sentence()
        p0 = parser.parse(s0, tagger=tagger)
        for j in range(len(sentences[i].leaves)):
            if j not in p0.parsed:
                p0.parsed[j] = classes.RELATION(-1, j, 'root')
        parsed.append(p0)
        if TAG:
            pst = getSubTree(dtree=p0.dtree, parsed=p0)
            gsst = getSubTree(dtree=sentences[i].dtree, parsed=p0)
        else:
            pst = getSubTreehead(dtree=p0.dtree, parsed=p0, gs=False, PARSED=True, GS=False)
            gsst = getSubTreehead(dtree=sentences[i].dtree, parsed=False, gs=sentences[i], PARSED=False, GS=True)
        instance = [pst, gsst]
        trainingdata.append(instance)
    return trainingdata


def findAllInstances(trainingdata, threshold=3):
    print "Initial score %.4f\nThreshold %s, dataset %s" % (float(accuracy(trainingdata)), threshold, len(trainingdata))
    rules = []
    while True:
        allinstances = {}
        for i in trainingdata:
            for k in i[1]:
                if k in i[0] and not i[0][k] == i[1][k]:
                    t = "%s > %s" % (i[0][k], i[1][k])
                    try:
                        allinstances[t] += 1
                    except KeyError:
                        allinstances[t] = 1
        tmp = []
        for k in allinstances:
            tmp.append([allinstances[k], k])
        tmp.sort()
        tmp.reverse()
        print underline("Top %s candidate rules") % METERING
        for i in range(METERING):
            print "Candidate rule %s: gross score %s" % (tmp[i][1], tmp[i][0])
        instances = []
        bestscore = 0
        for k in allinstances:
            score = 0
            st0, st1 = k.split(' > ')
            for i in trainingdata:
                for j in i[0]:
                    if i[0][j] == st0:
                        if j in i[1]:
                            if i[1][j] == st1:
                                score += 1
                            else:
                                score -= 1
            instances.append([score, allinstances[k], k])
            if score > bestscore:
                bestscore = score
        instances.sort()
        instances.reverse()
        print underline("Top %s net score rules") % METERING
        for i in range(METERING):
            print "rule: %s, gross score %s, net score %s" % (instances[i][2], instances[i][1], instances[i][0])
        if bestscore < threshold:
            break
        rules.append(instances[0])
        trainingdata = applyrules(trainingdata, rules=rules)
        print "Score %.4f" % (float(accuracy(trainingdata)))
    return rules


def accuracy(trainingdata):
    right = 0
    total = 0
    for i in trainingdata:
        for j in i[1]:
            total += 1
            if j in i[0] and i[0][j] == i[1][j]:
                right += 1
    return float(right) / float(total)


def applyrules(testdata, rules):
    before = accuracy(testdata)
    for rule in rules:
        st0, st1 = rule[2].split(' > ')
        for i in testdata:
            for j in i[0]:
                if i[0][j] == st0:
                    i[0][j] = st1
    after = accuracy(testdata)
    print "Before repairing %s (training size = %s)" % (before, len(testdata))
    print "After repairing %s (training size = %s)" % (after, len(testdata))
    return testdata


def getRepairRules(sentences, parser=False, tagger=False, N=1000, K=1000, threshold=2, TAG=True, trainingdata=False):
    N += K
    if trainingdata==False:
        trainingdata = getTrainingdata(sentences, parser=parser, tagger=tagger, TAG=TAG)
    print "Accuracy of parser on the training data (size %s): %s" % (
            len(trainingdata[0:-N]), accuracy(trainingdata[:-N]))
    print "Accuracy of parser on reserved data (size %s): %s" % (
            len(trainingdata[-N:]), accuracy(trainingdata[-N:]))
    print underline("Extracting TBL rules from half the reserved data (%s - %s)" % (-N, -K))
    t0 = datetime.datetime.now()
    rules = findAllInstances(trainingdata[-N:-K], threshold=threshold)
    print "finding rules took %s seconds"%((datetime.datetime.now()-t0).seconds)
    parser.rules = rules
    print underline("Testing extracted TBL rules on the remainder of the reserved data (%s)" % (-K))
    data = applyrules(trainingdata[-K:], rules)
    return rules, data
