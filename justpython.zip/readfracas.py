
import re
from useful import *
import latex
reload(latex)
        
pattern = re.compile("<(?P<tag>p|q|h)( idx\S*)?>(?P<text>.*?)</(?P=tag)>", re.DOTALL)
def readfracas(src="fracas.xml"):
    return [i.group("text").strip() for i in pattern.finditer(open(src).read())]

def testfracas(parser, tagger):
    analyses = []
    for s in readfracas():
        if s == "":
            continue
        s = replaceAll(s, [(".", " ."), ("?", " ?"), ("&apos;s", " s"), ("&", "and"), ("#", "NUM")])
        w = s.split(" ")[0]
        if w.lower() in tagger.basetagger.dict:
            s = s[0].lower()+s[1:]
        print s
        analyses.append([s, parser.parse(s, tagger=tagger).dtree])
    return analyses

def latexAll(analyses):
    s = ""
    for x, y in analyses:
        s += r"""
\vbox{\item
%s

%s}"""%(x, latex.latexDTree(y, False, 30, 30, []))
    runlatex(r"""
\begin{landscape}
\begin{examples}
%s
\end{examples}
\end{landscape}"""%(s),
        packages=["examples", "lscape"])
        
