#!/usr/bin/python
from useful import *
import sys
import dtw
import a2bw
import subprocess
import cgi
import cgitb
from sql import *

def text2csv(ifile="100KTaggedTweets-10-10-2016.txt", out="100K.csv"):
    with safeout(out) as write:
        for l in open(ifile):
            l = l.strip().split(" ")
            if len(l) > 0:
                write("**************************\n")
                for x in l:
                    x = x.split(",")
                    try:
                        write("%s\t%s\n"%(x[0], x[1]))
                    except:
                        pass
                    
header = """Content-type: text/html; charset=UTF-8

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
<h3>Colour coding</h3>
<p>
I've done two things to Fahad's tagged decliticised texts. 
<ol>
<li>
I've done some bits of preprocessing, partly to tidy things up, partly to replace some of Fahad's coarse-grained tags by finer-grained ones. Places where 
I've done that are marked in <span style="background-color: #aaaaff">blue</span>.
</li>
<li>
I've tried to introduce breaks where there is a natural break between sentences. 
These are marked a line separating the parts, and by marking the text in the original text which marked the break in
<span style="background-color: #aaffaa">green</span>.
</li>
</ol>
The first two columns are Fahad's output, the next three are what I
have at that position + the Buckwalter equivalent. Most of the time
these are the same, but there are lines where I have deleted something
from the original, so there are some blank sections in the last three
columns (and some weird ones where the conversion to Buckwalter
doesn't see to work, e.g. line 12). There's a textbox at the end of
each line where you can write comments. If you add a comment, please
leave your name, so that we know who has said what. You can extend
someone else's comment, but don't delete what has already been said
about an item. To save what you have just said, either click the "save
notes" button or just do <enter> while you are in the text box. It all
takes a couple of seconds to refresh, but not an intolerable amount of
time. Lines with a comment attach are marked in <span style="background-color: #faa">pink</span> to make them easy to
see.
</p>
<p>
My plan is to work through this page updating my preprocessing and segmentation programs till we are happy enough with what we've got, or till the end of next week, whichever comes sooner. 
</p>
<form method="post">
<input type="hidden" name="updatecomments" value="yes">
To search for a sequence of tags, enter them here <input type="text" name="findsequence" value=""> and then press enter.
<table>
"""

def nodummies(l):
    return [x for x in l if x]

def findMatchingSegments(lines, post, write):
    tags = checkPOST("findsequence", post).split(" ")
    alltags = []
    for l in lines:
        l = l.split("After")[0]
        try:
            for w in l.strip().split(" "):
                try:
                    alltags.append(w.split("+")[1]) 
                except:
                    pass
        except:
            pass
    msg = "<p>The sequence '%s' can be found at positions "%(tags)
    for i in range(len(alltags)):
        if tags == alltags[i:i+len(tags)]:
            write(msg)
            msg = ", "
            write('<a href="text2csv.py#l%s">%s</a>'%(i+1, i+1))
    if msg == ", ":
        write("</p>")
            
def segments2csv(ifile="segmented.txt", post={}, session={}, out=sys.stdout, html=False):
    t = 1
    with safeout(out) as write:
        if html:
            write(header)
        dump = "DUMPS/test%s.sql"%(now().strftime("-%m-%d-%H-%M"))
        with safeout(dump) as dump:
            dump("use tweets;\n")
            for l in execute("select * from notes", use("tweets")):
                dump("insert into notes set line='%s', text='%s';\n"%(tuple(l)))
        comments = {x[0]:x[1] for x in execute("select line, text from notes", use("tweets"))}
        lines = [l.strip() for l in open(ifile).read().replace(" +", "+").split("**********************************") if not l.strip() == ""]
        if "updatecomments" in post:
            execute('delete from notes', use("tweets"))
        if "findsequence" in post:
            findMatchingSegments(lines, post, write)
        i = 1
        skipThisOne = False
        for l in lines:
            if html:
                write("""
<tr><td><hr style="color:blue"></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td></tr>
<tr><td>tweet %s</td><td><input type="submit" value="save notes"></td><td></td><td></td><td></td><td></td><td></td></tr>
<tr><td><hr style="color:blue"></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td></tr>
"""%(t))
                t += 1
            else:
                write("\n")
            l = l.strip()
            original = l.split("\n")[0].split(" ")
            segmented = []
            for segment in l.split("After segmentation")[1:]:
                segmented += [s.strip() for s in segment.split(" ")]+[" !!!+!!!"]
            a = dtw.array(nodummies(original), nodummies(segmented))
            a.findPath()
            g = a.getAlignment()
            for p in reversed(g[1:-1]):
                if not p == ("", "!!!+!!!", 3):
                    line = "line%s"%(i)
                    if "updatecomments" in post:
                        note = checkPOST(line, post).replace("'", "").replace('"', '')
                    else:
                        try:
                            note = comments[line]
                        except:
                            note = ""
                    if html:
                        if len(p) > 0 and "!!!" in p[1]:
                            colour = "#aaffaa"
                            write("""
<tr> <td><hr style="color:blue"></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td><td><hr></td></tr>""")
                            if len(p[0].split("+")) < 2:
                                skipThisOne = True
                                continue
                        elif skipThisOne:
                            colour = "#afa"
                            skipThisOne = False
                        elif len(p) == 3:
                            colour = "#aaaaff"
                        else:
                            colour = "white"
                        if not note == "":
                            colour = "ffaaaa"
                        write("""
                        <tr style="background-color: %s">
                        """%(colour))
                    p, q = p[:2]
                    p = p.split("+")
                    while len(p) < 2:
                        p.append("")
                    q = q.split("+")
                    while len(q) < 3:
                        q.append("")
                    q = q[:1]+[a2bw.convert(q[0].decode("utf-8"))]+q[1:]
                    if html:
                        write("<td><a name='l%s'></a>%s</td>"%(i, i))
                        for x in p+q:
                            try:
                                if x == "*" or x == "!!!":
                                    x = ""
                                write("<td>%s</td>"%(x))
                            except:
                                write("<td>???</td>")
                        if not note == "":
                            execute('insert into notes set line="%s", text="%s"'%(line, note), use("tweets"))
                        if len(note) < 60:
                            write("""<td><input type="text" name="line%s" value="%s" size="60"></td>"""%(i, note))
                        else:
                            write("""<td><textarea name="line%s" cols="60" rows="%s">%s</textarea></td>"""%(i, len(note)/60+1, note))
                        i += 1
                    else:
                        write("\t".join(p))
                        write("\t")
                        write("\t".join(q))
                        write("\n")
                    if html:
                        write("""</tr>""")
            skipThisOne = False
        if html:
            write("""
</table>
</form>
</body>
</html>
""")
            
def preprocess(post={}, session={}, segmented="segmented.txt", out="segmented.html"):
    x = subprocess.Popen(("/usr/local/bin/sicstus -l preprocess.pl --goal ppandhalt('%s')."%(segmented)).split(" "),
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    a = segments2csv(post=post, session=session, ifile=segmented, out=out, html=True)

if "text2csv.py" in sys.argv[0]:
    cgitb.enable()
    preprocess(post=cgi.FieldStorage(), session=getSESSION(), out=sys.stdout)
