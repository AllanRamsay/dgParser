class LABELTAGGER:
    def __init__(self, condition=False, direction=False, label=False, labels=False):
        self.condition = condition
        self.direction = direction
        self.label = label
        self.labels = labels

def getlabel(trainingdata, useClasses=False):

    labeltagger = LABELTAGGER()
    labeltagger.condition = []
    labeltagger.direction = []
    labeltagger.label = []
    labeltagger.labels = []

    for i in range(len(trainingdata)):
        for j in range(len(trainingdata[i].leaves)):
            pposition = trainingdata[i].leaves[j].hd
            dposition = j
            parent = trainingdata[i].leaves[pposition].tag[:2]
            daughter = trainingdata[i].leaves[j].tag[:2]
            if dposition < pposition:
                cond = "%s<%s(L)" %(daughter, parent)
            else:
                cond = "%s<%s(R)" %(daughter, parent)
            label = trainingdata[i].leaves[j].label
            if useClasses:
                labels = {'subj':['nsubj', 'csubj', 'nsubjpass', 'csubjpass'], 'dobj':['dobj'], 'iobj':['iobj'], 'comp':['ccomp', 'xcomp'], 'mod':['acl', 'amod', 'det', 'neq', 'advcl', 'advmod', 'nummod', 'appos', 'nmod', 'nmod:tmod', 'nmod:npmod', 'nmod:poss', 'acl:relcl', 'det:predet'], 'case':['case'], 'root':['root'], 'other':['compound', 'compound:prt', 'conj', 'conj:preconj', 'foreign', 'cc', 'list', 'remnant', 'expl', 'vocative', 'neg', 'discourse', 'mark', 'auxpass', 'mwe', 'dislocated', 'aux', 'parataxis', 'punct', 'goeswith', 'cop', 'dep', 'reparandum']}
                for item in labels:
                    if label in labels[item]:
                        break
                label = item

            if cond not in labeltagger.condition:
                labeltagger.condition.append(cond)
                labeltagger.labels.append({})
                m = len(labeltagger.condition)-1
                labeltagger.labels[m][label] = 1
            else:
                m = labeltagger.condition.index(cond)
                if label not in labeltagger.labels[m]:
                    labeltagger.labels[m][label] = 1
                else:
                    labeltagger.labels[m][label] += 1

    for i in range(len(labeltagger.condition)):
        maximum = max(labeltagger.labels[i].values())
        keys = [x for x, y in labeltagger.labels[i].items() if y == maximum]
        labeltagger.label.append(keys)

    return labeltagger

