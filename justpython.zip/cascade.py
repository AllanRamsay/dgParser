#!/usr/bin/python

"""
CASCADE.PY

Programs to support COMP34411 Natural Language Systems: these programs
have more comments in them than code that I write for my own use, but
it's unlikely to be enough to make them easy to understand. If you
play with them then I hope they will help with understanding the ideas
and algorithms in the course. If you try to read the source code,
you'll probably just learn what a sloppy programmer I am.
"""

import re
import string
import os
import stat
import sys
import subprocess
import time
import cPickle


try:
    """
    from nltk.corpus import wordnet
    """
except:
    """
    Some machines where I want to run this don't have the NLTK installed: I'm
    only using it in order to get at morphy, so it's not a disaster if it's not
    there
    """
    
from useful import *

wordPattern = re.compile("(?P<tag>.*)!!(?P<form>.*)")

""" Set BNC to point to the right place on different machines """
if os.uname()[0] == "Darwin":
    BNC = '/Users/ramsay/BNC'
    programs = "/Users/ramsay/TEACHING/MODULES/COMP34411/PROGRAMS-2013/PYTHON"
else:
    BNC = '/opt/info/courses/COMP34411/PROGRAMS/BNC'
    programs = "/opt/info/courses/COMP34411/PROGRAMS"

mxl = cPickle.load(open("%s/mxl.pck"%(programs)))

def toBNCFormat(text):
    s = ""
    for form, tag in mxl.tag(text):
        s = s+"%s!!%s\n"%(tag, form)
    return s

cdefns = ['det0: ((AT.)|(DT.))',
          'adj: AJ.',
          'noun: NN.',
          'prep: PRP',

          'np: (det0? (nmod)? noun)',
          'nmod: adj | (nmod nmod)']

cdefns1 = ['det0: ((AT.)|(DT.))',
          'adj: AJ.',
          'noun: NN.',
          'prep: PRP',
          
          'nmod: adj',
          'nn: (noun | (nmod nn))',
          'np: (det0? nn)',]

def readCascade(tag):
    return re.compile("[a-zA-Z\d\.]+").sub((lambda m: "%s!![^\n]*\n"%(m.group(0))), tag).replace(" ", "")

def substGroup(m, tag):
    return "%s!!(%s)\n"%(tag, wordPattern.sub((lambda m1: "%s:%s"%(m1.group('tag'), m1.group('form'))), m.group(0)).strip().replace("\n", "+"))

"""
You can do this by applying all the rules that match anyting in the
current string in one go (singleStep=False), or by applying the first
one that matches and then starting again (singleStep=True). I find
singleStep=False produces behaviour that I find hard to follow, so
although I've left it as an option I STRONGLY recommend sticking with
singleStep=True)
"""
def cascade(text, defns=cdefns, top=True, singleStep=True):
    if top:
        text = toBNCFormat(text)
        defns = [x.split(":") for x in defns]
        print defns
    print '**************\n%s'%(text)
    changed = False
    text1 = text
    for tag, pattern in defns:
        pattern = readCascade(pattern)
        pattern = re.compile(pattern, re.DOTALL)
        text1 = pattern.sub((lambda m: substGroup(m, tag)), text1)
        if singleStep and not text == text1:
            return cascade(text1, defns, False)
    if not singleStep and not text == text1:
        return cascade(text1, defns, False)
    else:
        return text
