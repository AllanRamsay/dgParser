import re, sys, os, shutil
from useful import *
import a2bw

def tidytraining(ifile="training.txt", ofile=sys.stdout):
    sentencePattern = re.compile("([^\n]+\n?)+")
    with safeout(ofile) as out:
        for i in sentencePattern.finditer(a2bw.convert(open(ifile).read())):
            sentence = [word.split("\t") for word in i.group(0).split("\n") if not word.strip() == ""]
            start = int(sentence[0][0])
            for word in sentence:
                word[0] = str(int(word[0])+1-start)
                hd = int(word[-2])
                if hd < 0:
                    word[-2] = -1
                else:
                    word[-2] = hd+1-start
                word[-2] = str(word[-2])
                out("\t".join(word))
                out("\n")
            out("\n")
            
