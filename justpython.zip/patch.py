import re
from classes import *
from useful import *

def dense(l):
    print l
    l = sorted([x.position for x in l])
    t = {i:True for i in range(l[1], l[-1])}
    for i in range(l[1], l[-1]):
        if not i in t:
            return False
    return True

def extractSubTree(i, l, leaves, subtreetable=False):
    try:
        return subtreetable[i]
    except:
        tree = [leaves[i]]
        for k in l:
            x = l[k]
            if x.hd == i:
                tree += extractSubTree(x.dtr, l, leaves, subtreetable=subtreetable)
        subtreetable[i] = tree
        return tree

def extractTrees(l, leaves, threshold=1):
    subtreelist = []
    subtreetable = {}
    for i in range(len(l)):
        subtree = extractSubTree(i, l, leaves, subtreetable)
        subtreelist.append(subtree)
    return subtreelist

def extractmistakes(tree):
    printall(extractTrees(tree.goldstandard, tree.leaves))
    l1 = [x for x in extractTrees(tree.goldstandard, tree.leaves) if len(x) > 1 and dense(x)]
    l2 = [x for x in extractTrees(tree.parsed, tree.leaves) if len(x) > 1 and dense(x)]
    return l1, l2
