#!/usr/bin/python

import re, sys, os
from useful import *
import sounds
reload(sounds)
p = re.compile('"(?P<file>\S*).rec"(?P<lines>(\n\d+\s+\d+\s+(\S+)\s+\S*)*)\n\.')

def extractwords(d=".", recout="recout.mlf", wavfiles="."):
    try:
        os.mkdir("%s/%s"%(d, wavfiles))
    except:
        pass
    for i in p.finditer(open("%s/%s"%(d, recout)).read()):
        f = i.group("file")
        s = sounds.readsound("%s/%s.wav"%(d, f))
        wordboundaries = map(lambda l: getWordBoundaries(l, s.params[2]), i.group("lines").strip().split("\n"))
        for start, end, word in wordboundaries:
            print "sound %s, start %s, end %s, word %s, sample rate %s"%("%s/%s.wav"%(d, f), start, end, word, s.params[2])
            t = extractsegment(s, 2*start, 2*end, s.params)
            t.save(wavfile="%s/%s/%s.wav"%(d, wavfiles, word))
    
wb = re.compile('(?P<start>\d+)\s+(?P<end>\d+)\s+(?P<word>\S+)\s+\S*')

def getWordBoundaries(l, sfreq=8000):
    m = wb.match(l)
    htkfreq = 10000000.0
    return [int(sfreq*int(m.group("start"))/htkfreq), int(sfreq*int(m.group("end"))/htkfreq), m.group("word")]

def extractsegment(s, start, end, params):
    return sounds.SOUND(False, frames=s.frames[start:end], params=params)
    
if "extractwords" in sys.argv[0]:
    d = "TEMP"
    recout = "recout.mlf"
    wavfiles = "."
    for i in range(1, len(sys.argv)):
        flag, value = sys.argv[i].split("=")
        if flag == "dir":
            d = value
        elif flag == "recout":
            recout = value
        elif flag == "wavfiles":
            wavfiles = value
        else:
            raise Exception("Unknown flag %s"%(flag))
    try:
        extractwords(recout=recout, d=d, wavfiles=wavfiles)
    except Exception as e:
        print e
        print "extractwords dir=<dir> recout=<recout>"
