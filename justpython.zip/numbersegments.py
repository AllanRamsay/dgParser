import re, sys

def numbersegs(ifile="segmented.pl"):
    n = 0
    for i in re.compile("segment\((?P<seg>.*?)\)\.", re.DOTALL).finditer(open(ifile).read()):
        print "segment(%s, %s).\n"%(n, i.group("seg"))
        n += 1
