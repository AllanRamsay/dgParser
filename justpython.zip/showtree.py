#!/usr/bin/python

import sys, subprocess
from useful import *
import cgi
import cgitb
import a2bw

def segment2sicstus(s):
    return s.split(" ")

preprocessed = [segment.strip().replace(" +", "+") for segment in open("preprocessed.txt")]

header = """Content-type: text/html
%s

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
</head>
"""

body = """
<body>
<form method="post">
Text to be parsed <input type="text" style="font-size:10pt" size="140" name="target" value="%s">
<p>
<input type="submit" value="parse this sentence" name="parse">
<input type="submit" value="next" name="next">
<input type="submit" value="prev" name="prev">
</p>
</form>
<p>
%s
</p>
</body>
"""

footer = """
</html>
"""

def doParse(post, session, text="VB DEF INDEF"):
    try:
        counter = int(checkSESSION("counter", session))
    except:
        counter = 0
    tree = ""
    if "parse" in post:
        text = checkPOST("target", post)
        text = a2bw.convert(text.decode("utf-8"))
        setCookie(("target", text), session)
        tree = subprocess.Popen(["/usr/local/bin/sicstus", "-r", "dgparser.sav", "--goal", "((segment(P),jsParse(P), nl); halt)."], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
    elif "next" in post:
        counter += 1
        setCookie(("counter", counter), session)
    elif "prev" in post:
        counter -= 1
        setCookie(("counter", counter), session)
    print header%(session.output())+body%(preprocessed[counter], tree)+footer

if "showtree.py" in sys.argv[0]:
    doParse(cgi.FieldStorage(), getSESSION())
    
    
