fracas('an Italian became the world SSS greatest tenor .').
fracas('was there an Italian who became the world SSS greatest tenor ?').
fracas('there was an Italian who became the world SSS greatest tenor .').
fracas('every Italian man wants to be a great tenor .').
fracas('some Italian men are great tenors .').
fracas('are there Italian men who want to be a great tenor ?').
fracas('there are Italian men who want to be a great tenor .').
fracas('all Italian men want to be a great tenor .').
fracas('some Italian men are great tenors .').
fracas('are there Italian men who want to be a great tenor ?').
fracas('there are Italian men who want to be a great tenor .').
fracas('each Italian tenor wants to be great .').
fracas('some Italian tenors are great .').
fracas('are there Italian tenors who want to be great ?').
fracas('there are Italian tenors who want to be great .').
fracas('the really ambitious tenors are Italian .').
fracas('are there really ambitious tenors who are Italian ?').
fracas('there are really ambitious tenors who are Italian .').
fracas('no really great tenors are modest .').
fracas('are there really great tenors who are modest ?').
fracas('there are really great tenors who are modest .').
fracas('some great tenors are Swedish .').
fracas('are there great tenors who are Swedish ?').
fracas('there are great tenors who are Swedish .').
fracas('many great tenors are German .').
fracas('are there great tenors who are German ?').
fracas('there are great tenors who are German .').
fracas('several great tenors are British .').
fracas('are there great tenors who are British ?').
fracas('there are great tenors who are British .').
fracas('most great tenors are Italian .').
fracas('are there great tenors who are Italian ?').
fracas('there are great tenors who are Italian .').
fracas('a few great tenors sing popular music .').
fracas('some great tenors like popular music .').
fracas('are there great tenors who sing popular music ?').
fracas('there are great tenors who sing popular music .').
fracas('few great tenors are poor .').
fracas('are there great tenors who are poor ?').
fracas('there are great tenors who are poor .').
fracas('both leading tenors are excellent .').
fracas('leading tenors who are excellent are indispensable .').
fracas('are both leading tenors indispensable ?').
fracas('both leading tenors are indispensable .').
fracas('neither leading tenor comes cheap .').
fracas('one of the leading tenors is Pavarotti .').
fracas('is Pavarotti a leading tenor who comes cheap ?').
fracas('Pavarotti is a leading tenor who comes cheap .').
fracas('at least three tenors will take part in the concert .').
fracas('are there tenors who will take part in the concert ?').
fracas('there are tenors who will take part in the concert .').
fracas('at most two tenors will contribute their fees to charity .').
fracas('are there tenors who will contribute their fees to charity ?').
fracas('there are tenors who will contribute their fees to charity .').
fracas('an Irishman won the Nobel prize for literature .').
fracas('did an Irishman win a Nobel prize ?').
fracas('an Irishman won a Nobel prize .').
fracas('every European has the right to live in Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('can every European travel freely within Europe ?').
fracas('every European can travel freely within Europe .').
fracas('all Europeans have the right to live in Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('can all Europeans travel freely within Europe ?').
fracas('all Europeans can travel freely within Europe .').
fracas('each European has the right to live in Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('can each European travel freely within Europe ?').
fracas('each European can travel freely within Europe .').
fracas('the residents of member states have the right to live in Europe .').
fracas('all residents of member states are individuals .').
fracas('every individual who has the right to live in Europe can travel freely within Europe .').
fracas('can the residents of member states travel freely within Europe ?').
fracas('the residents of member states can travel freely within Europe .').
fracas('no delegate finished the report on time .').
fracas('did no delegate finish the report ?').
fracas('no delegate finished the report .').
fracas('some delegates finished the survey on time .').
fracas('did some delegates finish the survey ?').
fracas('some delegates finished the survey .').
fracas('many delegates obtained interesting results from the survey .').
fracas('did many delegates obtain results from the survey ?').
fracas('many delegates obtained results from the survey .').
fracas('several delegates got the results published in major national newspapers .').
fracas('did several delegates get the results published ?').
fracas('several delegates got the results published .').
fracas('most Europeans are resident in Europe .').
fracas('all Europeans are people .').
fracas('all people who are resident in Europe can travel freely within Europe .').
fracas('can most Europeans travel freely within Europe ?').
fracas('most Europeans can travel freely within Europe .').
fracas('a few committee members are from Sweden .').
fracas('all committee members are people .').
fracas('all people who are from Sweden are from Scandinavia .').
fracas('are at least a few committee members from Scandinavia ?').
fracas('at least a few committee members are from Scandinavia .').
fracas('few committee members are from Portugal .').
fracas('all committee members are people .').
fracas('all people who are from Portugal are from southern Europe .').
fracas('are there few committee members from southern Europe ?').
fracas('there are few committee members from southern Europe .').
fracas('both commissioners used to be leading businessmen .').
fracas('did both commissioners used to be businessmen ?').
fracas('both commissioners used to be businessmen .').
fracas('neither commissioner spends a lot of time at home .').
fracas('does neither commissioner spend time at home ?').
fracas('neither commissioner spends time at home .').
fracas('at least three commissioners spend a lot of time at home .').
fracas('do at least three commissioners spend time at home ?').
fracas('at least three commissioners spend time at home .').
fracas('at most ten commissioners spend a lot of time at home .').
fracas('do at most ten commissioners spend time at home ?').
fracas('at most ten commissioners spend time at home .').
fracas('an Irishman won a Nobel prize .').
fracas('did an Irishman win the Nobel prize for literature ?').
fracas('an Irishman won the Nobel prize for literature .').
fracas('every European can travel freely within Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('does every European have the right to live in Europe ?').
fracas('every European has the right to live in Europe .').
fracas('all Europeans can travel freely within Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('do all Europeans have the right to live in Europe ?').
fracas('all Europeans have the right to live in Europe .').
fracas('each European can travel freely within Europe .').
fracas('every European is a person .').
fracas('every person who has the right to live in Europe can travel freely within Europe .').
fracas('does each European have the right to live in Europe ?').
fracas('each European has the right to live in Europe .').
fracas('the residents of member states can travel freely within Europe .').
fracas('all residents of member states are individuals .').
fracas('every individual who has the right to live anywhere in Europe can travel freely within Europe .').
fracas('do the residents of member states have the right to live anywhere in Europe ?').
fracas('the residents of member states have the right to live anywhere in Europe .').
fracas('no delegate finished the report .').
fracas('did any delegate finish the report on time ?').
fracas('some delegate finished the report on time .').
fracas('some delegates finished the survey .').
fracas('did some delegates finish the survey on time ?').
fracas('some delegates finished the survey on time .').
fracas('many delegates obtained results from the survey .').
fracas('did many delegates obtain interesting results from the survey ?').
fracas('many delegates obtained interesting results from the survey .').
fracas('several delegates got the results published .').
fracas('did several delegates get the results published in major national newspapers ?').
fracas('several delegates got the results published in major national newspapers .').
fracas('most Europeans can travel freely within Europe .').
fracas('all Europeans are people .').
fracas('all people who are resident in Europe can travel freely within Europe .').
fracas('are most Europeans resident in Europe ?').
fracas('most Europeans are resident in Europe .').
fracas('a few committee members are from Scandinavia .').
fracas('all committee members are people .').
fracas('all people who are from Sweden are from Scandinavia .').
fracas('are at least a few committee members from Sweden ?').
fracas('at least a few committee members are from Sweden .').
fracas('few committee members are from southern Europe .').
fracas('all committee members are people .').
fracas('all people who are from Portugal are from southern Europe .').
fracas('are there few committee members from Portugal ?').
fracas('there are few committee members from Portugal .').
fracas('both commissioners used to be businessmen .').
fracas('did both commissioners used to be leading businessmen ?').
fracas('both commissioners used to be leading businessmen .').
fracas('neither commissioner spends time at home .').
fracas('does either commissioner spend a lot of time at home ?').
fracas('one of the commissioners spends a lot of time at home .').
fracas('at least three commissioners spend time at home .').
fracas('do at least three commissioners spend a lot of time at home ?').
fracas('at least three commissioners spend a lot of time at home .').
fracas('at most ten commissioners spend time at home .').
fracas('do at most ten commissioners spend a lot of time at home ?').
fracas('at most ten commissioners spend a lot of time at home .').
fracas('a Swede won a Nobel prize .').
fracas('every Swede is a Scandinavian .').
fracas('did a Scandinavian win a Nobel prize ?').
fracas('a Scandinavian won a Nobel prize .').
fracas('every Canadian resident can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can every resident of the north American continent travel freely within Europe ?').
fracas('every resident of the north American continent can travel freely within Europe .').
fracas('all Canadian residents can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can all residents of the north American continent travel freely within Europe ?').
fracas('all residents of the north American continent can travel freely within Europe .').
fracas('each Canadian resident can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can each resident of the north American continent travel freely within Europe ?').
fracas('each resident of the north American continent can travel freely within Europe .').
fracas('the residents of major western countries can travel freely within Europe .').
fracas('all residents of major western countries are residents of western countries .').
fracas('do the residents of western countries have the right to live in Europe ?').
fracas('the residents of western countries have the right to live in Europe .').
fracas('no Scandinavian delegate finished the report on time .').
fracas('did any delegate finish the report on time ?').
fracas('some delegate finished the report on time .').
fracas('some Irish delegates finished the survey on time .').
fracas('did any delegates finish the survey on time ?').
fracas('some delegates finished the survey on time .').
fracas('many British delegates obtained interesting results from the survey .').
fracas('did many delegates obtain interesting results from the survey ?').
fracas('many delegates obtained interesting results from the survey .').
fracas('several Portuguese delegates got the results published in major national newspapers .').
fracas('did several delegates get the results published in major national newspapers ?').
fracas('several delegates got the results published in major national newspapers .').
fracas('most Europeans who are resident in Europe can travel freely within Europe .').
fracas('can most Europeans travel freely within Europe ?').
fracas('most Europeans can travel freely within Europe .').
fracas('a few female committee members are from Scandinavia .').
fracas('are at least a few committee members from Scandinavia ?').
fracas('at least a few committee members are from Scandinavia .').
fracas('few female committee members are from southern Europe .').
fracas('are few committee members from southern Europe ?').
fracas('few committee members are from southern Europe .').
fracas('both female commissioners used to be in business .').
fracas('did both commissioners used to be in business ?').
fracas('both commissioners used to be in business .').
fracas('neither female commissioner spends a lot of time at home .').
fracas('does either commissioner spend a lot of time at home ?').
fracas('one of the commissioners spends a lot of time at home .').
fracas('at least three female commissioners spend time at home .').
fracas('do at least three commissioners spend time at home ?').
fracas('at least three commissioners spend time at home .').
fracas('at most ten female commissioners spend time at home .').
fracas('do at most ten commissioners spend time at home ?').
fracas('at most ten commissioners spend time at home .').
fracas('a Scandinavian won a Nobel prize .').
fracas('every Swede is a Scandinavian .').
fracas('did a Swede win a Nobel prize ?').
fracas('a Swede won a Nobel prize .').
fracas('every resident of the north American continent can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can every Canadian resident travel freely within Europe ?').
fracas('every Canadian resident can travel freely within Europe .').
fracas('all residents of the north American continent can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can all Canadian residents travel freely within Europe ?').
fracas('all Canadian residents can travel freely within Europe .').
fracas('each resident of the north American continent can travel freely within Europe .').
fracas('every Canadian resident is a resident of the north American continent .').
fracas('can each Canadian resident travel freely within Europe ?').
fracas('each Canadian resident can travel freely within Europe .').
fracas('the residents of western countries can travel freely within Europe .').
fracas('all residents of major western countries are residents of western countries .').
fracas('do the residents of major western countries have the right to live in Europe ?').
fracas('the residents of major western countries have the right to live in Europe .').
fracas('no delegate finished the report on time .').
fracas('did any Scandinavian delegate finish the report on time ?').
fracas('some Scandinavian delegate finished the report on time .').
fracas('some delegates finished the survey on time .').
fracas('did any Irish delegates finish the survey on time ?').
fracas('some Irish delegates finished the survey on time .').
fracas('many delegates obtained interesting results from the survey .').
fracas('did many British delegates obtain interesting results from the survey ?').
fracas('many British delegates obtained interesting results from the survey .').
fracas('several delegates got the results published in major national newspapers .').
fracas('did several Portuguese delegates get the results published in major national newspapers ?').
fracas('several Portuguese delegates got the results published in major national newspapers .').
fracas('most Europeans can travel freely within Europe .').
fracas('can most Europeans who are resident outside Europe travel freely within Europe ?').
fracas('most Europeans who are resident outside Europe can travel freely within Europe .').
fracas('a few committee members are from Scandinavia .').
fracas('are at least a few female committee members from Scandinavia ?').
fracas('at least a few female committee members are from Scandinavia .').
fracas('few committee members are from southern Europe .').
fracas('are few female committee members from southern Europe ?').
fracas('few female committee members are from southern Europe .').
fracas('both commissioners used to be in business .').
fracas('did both female commissioners used to be in business ?').
fracas('both female commissioners used to be in business .').
fracas('neither commissioner spends a lot of time at home .').
fracas('does either female commissioner spend a lot of time at home ?').
fracas('one of the female commissioners spends a lot of time at home .').
fracas('at least three commissioners spend time at home .').
fracas('do at least three male commissioners spend time at home ?').
fracas('at least three male commissioners spend time at home .').
fracas('at most ten commissioners spend time at home .').
fracas('do at most ten female commissioners spend time at home ?').
fracas('at most ten female commissioners spend time at home .').
fracas('Smith , Jones and Anderson signed the contract .').
fracas('did Jones sign the contract ?').
fracas('Jones signed the contract .').
fracas('Smith , Jones and several lawyers signed the contract .').
fracas('did Jones sign the contract ?').
fracas('Jones signed the contract .').
fracas('either Smith , Jones or Anderson signed the contract .').
fracas('did Jones sign the contract ?').
fracas('Jones signed the contract .').
fracas('either Smith , Jones or Anderson signed the contract .').
fracas('if Smith and Anderson did not sign the contract , did Jones sign the contract ?').
fracas('if Smith and Anderson did not sign the contract , Jones signed the contract .').
fracas('exactly two lawyers and three accountants signed the contract .').
fracas('did six lawyers sign the contract ?').
fracas('six lawyers signed the contract .').
fracas('exactly two lawyers and three accountants signed the contract .').
fracas('did six accountants sign the contract ?').
fracas('six accountants signed the contract .').
fracas('every representative and client was at the meeting .').
fracas('was every representative at the meeting ?').
fracas('every representative was at the meeting .').
fracas('every representative and client was at the meeting .').
fracas('was every representative at the meeting ?').
fracas('every representative was at the meeting .').
fracas('every representative or client was at the meeting .').
fracas('was every representative and every client at the meeting ?').
fracas('every representative and every client was at the meeting .').
fracas('the chairman read out the items on the agenda .').
fracas('did the chairman read out every item on the agenda ?').
fracas('the chairman read out every item on the agenda .').
fracas('the people who were at the meeting voted for a new chairman .').
fracas('did everyone at the meeting vote for a new chairman ?').
fracas('everyone at the meeting voted for a new chairman .').
fracas('all the people who were at the meeting voted for a new chairman .').
fracas('did everyone at the meeting vote for a new chairman ?').
fracas('everyone at the meeting voted for a new chairman .').
fracas('the people who were at the meeting all voted for a new chairman .').
fracas('did everyone at the meeting vote for a new chairman ?').
fracas('everyone at the meeting voted for a new chairman .').
fracas('the inhabitants of Cambridge voted for a Labour MP .').
fracas('did every inhabitant of Cambridge vote for a Labour MP ?').
fracas('every inhabitant of Cambridge voted for a Labour MP .').
fracas('the Ancient Greeks were noted philosophers .').
fracas('was every Ancient Greek a noted philosopher ?').
fracas('every Ancient Greek was a noted philosopher .').
fracas('the Ancient Greeks were all noted philosophers .').
fracas('was every Ancient Greek a noted philosopher ?').
fracas('every Ancient Greek was a noted philosopher .').
fracas('software faults were blamed for the system failure .').
fracas('was the system failure blamed on one or more software faults ?').
fracas('the system failure was blamed on one or more software faults .').
fracas('software faults were blamed for the system failure .').
fracas('bug # 32-985 is a known software fault .').
fracas('was bug # 32-985 blamed for the system failure ?').
fracas('bug # 32-985 was blamed for the system failure .').
fracas('clients at the demonstration were all impressed by the system SSS performance .').
fracas('Smith was a client at the demonstration .').
fracas('was Smith impressed by the system SSS performance ?').
fracas('Smith was impressed by the system SSS performance .').
fracas('clients at the demonstration were impressed by the system SSS performance .').
fracas('were most clients at the demonstration impressed by the system SSS performance ?').
fracas('most clients at the demonstration were impressed by the system SSS performance .').
fracas('University graduates make poor stock - market traders .').
fracas('Smith is a university graduate .').
fracas('is Smith likely to make a poor stock market trader ?').
fracas('Smith is likely to make a poor stock market trader .').
fracas('University graduates make poor stock - market traders .').
fracas('Smith is a university graduate .').
fracas('will Smith make a poor stock market trader ?').
fracas('Smith will make a poor stock market trader .').
fracas('all APCOM managers have company cars .').
fracas('Jones is an APCOM manager .').
fracas('does Jones have a company car ?').
fracas('Jones has a company car .').
fracas('all APCOM managers have company cars .')
fracas('Jones is an APCOM manager .').
fracas('does Jones have more than one company car ?').
fracas('Jones has more than one company car .').
fracas('just one accountant attended the meeting .').
fracas('did no accountants attend the meeting ?').
fracas('no accountants attended the meeting .').
fracas('just one accountant attended the meeting .').
fracas('did no accountant attend the meeting ?').
fracas('no accountant attended the meeting .').
fracas('just one accountant attended the meeting .').
fracas('did any accountants attend the meeting ?').
fracas('some accountants attended the meeting .').
fracas('just one accountant attended the meeting .').
fracas('did any accountant attend the meeting ?').
fracas('some accountant attended the meeting .').
fracas('just one accountant attended the meeting .').
fracas('did some accountants attend the meeting ?').
fracas('some accountants attended the meeting .').
fracas('just one accountant attended the meeting .').
fracas('did some accountant attend the meeting ?').
fracas('some accountant attended the meeting .').
fracas('Smith signed one contract .').
fracas('Jones signed another contract .').
fracas('did Smith and Jones sign two contracts ?').
fracas('Smith and Jones signed two contracts .').
fracas('Smith signed two contracts .').
fracas('Jones signed two contracts .').
fracas('did Smith and Jones sign two contracts ?').
fracas('Smith and Jones signed two contracts .').
fracas('Smith signed two contracts .').
fracas('Jones also signed them .').
fracas('did Smith and Jones sign two contracts ?').
fracas('Smith and Jones signed two contracts .').
fracas('Mary used her workstation .').
fracas('was Mary SSS workstation used ?').
fracas('Mary SSS workstation was used .').
fracas('Mary used her workstation .').
fracas('does Mary have a workstation ?').
fracas('Mary has a workstation .').
fracas('Mary used her workstation .').
fracas('is Mary female ?').
fracas('Mary is female .').
fracas('every student used her workstation .').
fracas('Mary is a student .').
fracas('did Mary use her workstation ?').
fracas('Mary used her workstation .').
fracas('every student used her workstation .').
fracas('Mary is a student .').
fracas('does Mary have a workstation ?').
fracas('Mary has a workstation .').
fracas('no student used her workstation .').
fracas('Mary is a student .').
fracas('did Mary use a workstation ?').
fracas('Mary used a workstation .').
fracas('Smith attended a meeting .').
fracas('she chaired it .').
fracas('did Smith chair a meeting ?').
fracas('Smith chaired a meeting .').
fracas('Smith delivered a report to ITEL .').
fracas('she also delivered them an invoice .').
fracas('and she delivered them a project proposal .').
fracas('did Smith deliver a report , an invoice and a project proposal to ITEL ?').
fracas('Smith delivered a report , an invoice and a project proposal to ITEL .').
fracas('every committee has a chairman .').
fracas('he is appointed its members .').
fracas('does every committee have a chairman appointed by members of the committee ?').
fracas('every committee has a chairman appointed by members of the committee .').
fracas('ITEL has sent most of the reports Smith needs .').
fracas('they are on her desk .').
fracas('are there some reports from ITEL on Smith SSS desk ?').
fracas('there are some reports from ITEL on Smith SSS desk .').
fracas('two out of ten machines are missing .').
fracas('they have been removed .').
fracas('Have two machines been removed ?').
fracas('two machines have been removed .').
fracas('two out of ten machines are missing .').
fracas('they have been removed .').
fracas('Have eight machines been removed ?').
fracas('Eight machines have been removed .').
fracas('two out of ten machines are missing .').
fracas('they were all here yesterday .').
fracas('were ten machines here yesterday ?').
fracas('Ten machines were here yesterday .').
fracas('Smith took a machine on Tuesday , and Jones took a machine on Wednesday .').
fracas('they put them in the lobby .').
fracas('did Smith and Jones put two machines in the lobby ?').
fracas('Smith and Jones put two machines in the lobby .').
fracas('John and his colleagues went to a meeting .').
fracas('they hated it .').
fracas('did John SSS colleagues hate the meeting ?').
fracas('John SSS colleagues hated the meeting .').
fracas('John and his colleagues went to a meeting .').
fracas('they hated it .').
fracas('did John hate the meeting ?').
fracas('John hated the meeting .').
fracas('John and his colleagues went to a meeting .').
fracas('they hated it .').
fracas('did John hate the meeting ?').
fracas('John hated the meeting .').
fracas('each department has a dedicated line .').
fracas('they rent them from BT .').
fracas('does every department rent a line from BT ?').
fracas('every department rents a line from BT .').
fracas('each department has a dedicated line .').
fracas('the sales department rents it from BT .').
fracas('does the sales department rent a line from BT ?').
fracas('the sales department rents a line from BT .').
fracas('GFI owns several computers .').
fracas('ITEL maintains them .').
fracas('does ITEL maintain all the computers that GFI owns ?').
fracas('ITEL maintains all the computers that GFI owns .').
fracas('every customer who owns a computer has a service contract for it .').
fracas('MFI is a customer that owns exactly one computer .').
fracas('does MFI have a service contract for all its computers ?').
fracas('MFI has a service contract for all its computers .').
fracas('every customer who owns a computer has a service contract for it .').
fracas('MFI is a customer that owns several computers .').
fracas('does MFI have a service contract for all its computers ?').
fracas('MFI has a service contract for all its computers .').
fracas('every executive who had a laptop computer brought it to take notes at the meeting .').
fracas('Smith is a executive who owns five different laptop computers .').
fracas('did Smith take five laptop computers to the meeting ?').
fracas('Smith took five laptop computers to the meeting .').
fracas('there are 100 companies .').
fracas('ICM is one of the companies and owns 150 computers .').
fracas('it does not have service contracts for any of its computers .').
fracas('each of the other 99 companies owns one computer .').
fracas('they have service contracts for them .').
fracas('do most companies that own a computer have a service contract for it ?').
fracas('most companies that own a computer have a service contract for it .').
fracas('every report has a cover page .').
fracas('R-95-103 is a report .').
fracas('Smith signed the cover page .').
fracas('did Smith sign the cover page of R-95-103 ?').
fracas('Smith signed the cover page of R-95-103 .').
fracas('a company director awarded himself a large payrise .').
fracas('has a company director awarded and been awarded a payrise ?').
fracas('a company director has awarded and been awarded a payrise .').
fracas('John said Bill had hurt himself .').
fracas('did John say Bill had been hurt ?').
fracas('John said Bill had been hurt .').
fracas('John said Bill had hurt himself .').
fracas('did anyone say John had been hurt ?').
fracas('someone said John had been hurt .').
fracas('John spoke to Mary .').
fracas('so did Bill .').
fracas('did Bill speak to Mary ?').
fracas('Bill spoke to Mary .').
fracas('John spoke to Mary .').
fracas('so did Bill .').
fracas('John spoke to Mary at four o APOS clock .').
fracas('did Bill speak to Mary at four o APOS clock ?').
fracas('Bill spoke to Mary at four o APOS clock .').
fracas('John spoke to Mary at four o APOS clock .').
fracas('so did Bill .').
fracas('did Bill speak to Mary at four o APOS clock ?').
fracas('Bill spoke to Mary at four o APOS clock .').
fracas('John spoke to Mary at four o APOS clock .').
fracas('and Bill did at five o APOS clock .').
fracas('did Bill speak to Mary at five o APOS clock ?').
fracas('Bill spoke to Mary at five o APOS clock .').
fracas('John has spoken to Mary .').
fracas('Bill is going to .').
fracas('will Bill speak to Mary ?').
fracas('Bill will speak to Mary .').
fracas('John spoke to Mary on Monday .').
fracas('Bill didn APOS t .').
fracas('did Bill speak to Mary on Monday ?').
fracas('Bill spoke to Mary on Monday .').
fracas('has John spoken to Mary ?').
fracas('Bill has .').
fracas('has Bill spoken to Mary ?').
fracas('Bill has spoken to Mary .').
fracas('John has spoken to Mary .').
fracas('the students have too .').
fracas('Have the students spoken to Mary ?').
fracas('the students have spoken to Mary .').
fracas('John went to Paris by car , and Bill by train .').
fracas('did Bill go to Paris by train ?').
fracas('Bill went to Paris by train .').
fracas('John went to Paris by car , and Bill by train to Berlin .').
fracas('did Bill go to Berlin by train ?').
fracas('Bill went to Berlin by train .').
fracas('John went to Paris by car , and Bill to Berlin .').
fracas('did Bill go to Berlin by car ?').
fracas('Bill went to Berlin by car .').
fracas('John is going to Paris by car , and the students by train .').
fracas('are the students going to Paris by train ?').
fracas('the students are going to Paris by train .').
fracas('John went to Paris by car .').
fracas('Bill by train .').
fracas('did Bill go to Paris by train ?').
fracas('Bill went to Paris by train .').
fracas('John owns a car .').
fracas('Bill owns one too .').
fracas('does Bill own a car ?').
fracas('Bill owns a car .').
fracas('John owns a car .').
fracas('Bill owns one too .').
fracas('is there a car that John and Bill own ?').
fracas('there is a car that John and Bill own .').
fracas('John owns a red car .').
fracas('Bill owns a blue one .').
fracas('does Bill own a blue car ?').
fracas('Bill owns a blue car .').
fracas('John owns a red car .').
fracas('Bill owns a blue one .').
fracas('does Bill own a red car ?').
fracas('Bill owns a red car .').
fracas('John owns a red car .').
fracas('Bill owns a fast one .').
fracas('does Bill own a fast car ?').
fracas('Bill owns a fast car .').
fracas('John owns a red car .').
fracas('Bill owns a fast one .').
fracas('does Bill own a fast red car ?').
fracas('Bill owns a fast red car .').
fracas('John owns a red car .').
fracas('Bill owns a fast one .').
fracas('does Bill own a fast red car ?').
fracas('Bill owns a fast red car .').
fracas('John owns a fast red car .').
fracas('Bill owns a slow one .').
fracas('does Bill own a slow red car ?').
fracas('Bill owns a slow red car .').
fracas('John had his paper accepted .').
fracas('Bill doesn APOS t know why .').
fracas('does Bill know why John had his paper accepted ?').
fracas('Bill knows why John had his paper accepted .').
fracas('John spoke to Mary .').
fracas('and to Sue .').
fracas('did John speak to Sue ?').
fracas('John spoke to Sue .').
fracas('John spoke to Mary .').
fracas('On Friday .').
fracas('did John speak to Mary on Friday ?').
fracas('John spoke to Mary on Friday .').
fracas('John spoke to Mary on Thursday .').
fracas('and on Friday .').
fracas('did John speak to Mary on Friday ?').
fracas('John spoke to Mary on Friday .').
fracas('Twenty men work in the Sales Department .').
fracas('But only one woman .').
fracas('do two women work in the Sales Department ?').
fracas('two women work in the Sales Department .').
fracas('Five men work part time .').
fracas('and forty five women .').
fracas('do forty five women work part time ?').
fracas('Forty five women work part time .').
fracas('John found Mary before Bill .').
fracas('did John find Mary before Bill found Mary ?').
fracas('John found Mary before Bill found Mary .').
fracas('John found Mary before Bill .').
fracas('did John find Mary before John found Bill ?').
fracas('John found Mary before John found Bill .').
fracas('John wants to know how many men work part time .').
fracas('and women .').
fracas('does John want to know how many women work part time ?').
fracas('John wants to know how many women work part time .').
fracas('John wants to know how many men work part time , and which .').
fracas('does John want to know which men work part time ?').
fracas('John wants to know which men work part time .').
fracas('Bill spoke to everyone that John did .').
fracas('John spoke to Mary .').
fracas('did Bill speak to Mary ?').
fracas('Bill spoke to Mary .').
fracas('Bill spoke to everyone that John did .').
fracas('Bill spoke to Mary .').
fracas('did John speak to Mary ?').
fracas('John spoke to Mary .').
fracas('John said Mary wrote a report , and Bill did too .').
fracas('did Bill say Mary wrote a report ?').
fracas('Bill said Mary wrote a report .').
fracas('John said Mary wrote a report , and Bill did too .').
fracas('did John say Bill wrote a report ?').
fracas('John said Bill wrote a report .').
fracas('John said that Mary wrote a report , and that Bill did too .').
fracas('did Bill say Mary wrote a report ?').
fracas('Bill said Mary wrote a report .').
fracas('John wrote a report , and Bill said Peter did too .').
fracas('did Bill say Peter wrote a report ?').
fracas('Bill said Peter wrote a report .').
fracas('ff John wrote a report , then Bill did too .').
fracas('John wrote a report .').
fracas('did Bill write a report ?').
fracas('Bill wrote a report .').
fracas('John wanted to buy a car , and he did .').
fracas('did John buy a car ?').
fracas('John bought a car .').
fracas('John needed to buy a car , and Bill did .').
fracas('did Bill buy a car ?').
fracas('Bill bought a car .').
fracas('Smith represents his company and so does Jones .').
fracas('does Jones represent Jones APOS company ?').
fracas('Jones represents Jones APOS company .').
fracas('Smith represents his company and so does Jones .').
fracas('does Jones represent Smith SSS company ?').
fracas('Jones represents Smith SSS company .').
fracas('Smith represents his company and so does Jones .').
fracas('does Smith represent Jones APOS company ?').
fracas('Smith represents Jones APOS company .').
fracas('Smith claimed he had costed his proposal and so did Jones .').
fracas('did Jones claim he had costed his own proposal ?').
fracas('Jones claimed he had costed his own proposal .').
fracas('Smith claimed he had costed his proposal and so did Jones .').
fracas('did Jones claim he had costed Smith SSS proposal ?').
fracas('Jones claimed he had costed Smith SSS proposal .').
fracas('Smith claimed he had costed his proposal and so did Jones .').
fracas('did Jones claim Smith had costed Smith SSS proposal ?').
fracas('Jones claimed Smith had costed Smith SSS proposal .').
fracas('Smith claimed he had costed his proposal and so did Jones .').
fracas('did Jones claim Smith had costed Jones APOS proposal ?').
fracas('Jones claimed Smith had costed Jones APOS proposal .').
fracas('John is a man and Mary is a woman .').
fracas('John represents his company and so does Mary .').
fracas('does Mary represent her own company ?').
fracas('Mary represents her own company .').
fracas('John is a man and Mary is a woman .').
fracas('John represents his company and so does Mary .').
fracas('does Mary represent John SSS company ?').
fracas('Mary represents John SSS company .').
fracas('Bill suggested to Frank SSS boss that they should go to the meeting together , and Carl to Alan SSS wife .').
fracas('if it was suggested that Bill and Frank should go together , was it suggested that Carl and Alan should go together ?').
fracas('if it was suggested that Bill and Frank should go together , it was suggested that Carl and Alan should go together .').
fracas('Bill suggested to Frank SSS boss that they should go to the meeting together , and Carl to Alan SSS wife .').
fracas('if it was suggested that Bill and Frank should go together , was it suggested that Carl and Alan SSS wife should go together ?').
fracas('if it was suggested that Bill and Frank should go together , it was suggested that Carl and Alan SSS wife should go together .').
fracas('Bill suggested to Frank SSS boss that they should go to the meeting together , and Carl to Alan SSS wife .').
fracas('if it was suggested that Bill and Frank SSS boss should go together , was it suggested that Carl and Alan SSS wife should go together ?').
fracas('if it was suggested that Bill and Frank SSS boss should go together , it was suggested that Carl and Alan SSS wife should go together .').
fracas('Bill suggested to Frank SSS boss that they should go to the meeting together , and Carl to Alan SSS wife .').
fracas('if it was suggested that Bill and Frank SSS boss should go together , was it suggested that Carl and Alan should go together ?').
fracas('if it was suggested that Bill and Frank SSS boss should go together , it was suggested that Carl and Alan should go together .').
fracas('Bill suggested to Frank SSS boss that they should go to the meeting together , and Carl to Alan SSS wife .').
fracas('if it was suggested that Bill , Frank and Frank SSS boss should go together , was it suggested that Carl , Alan and Alan SSS wife should go together ?').
fracas('if it was suggested that Bill , Frank and Frank SSS boss should go together , it was suggested that Carl , Alan and Alan SSS wife should go together .').
fracas('a lawyer signed every report , and so did an auditor .').
fracas('that is , there was one lawyer who signed all the reports .').
fracas('was there one auditor who signed all the reports ?').
fracas('there was one auditor who signed all the reports .').
fracas('John has a genuine diamond .').
fracas('does John have a diamond ?').
fracas('John has a diamond .').
fracas('John is a former university student .').
fracas('is John a university student ?').
fracas('John is a university student .').
fracas('John is a successful former university student .').
fracas('is John successful ?').
fracas('John is successful .').
fracas('John is a former successful university student .').
fracas('is John successful ?').
fracas('John is successful .').
fracas('John is a former successful university student .').
fracas('is John a university student ?').
fracas('John is a university student .').
fracas('every mammal is an animal .').
fracas('is every four - legged mammal a four - legged animal ?').
fracas('every four - legged mammal is a four - legged animal .').
fracas('Dumbo is a four - legged animal .').
fracas('is Dumbo four - legged ?').
fracas('Dumbo is four - legged .').
fracas('Mickey is a small animal .').
fracas('is Mickey a large animal ?').
fracas('Mickey is a large animal .').
fracas('Dumbo is a large animal .').
fracas('is Dumbo a small animal ?').
fracas('Dumbo is a small animal .').
fracas('Fido is not a small animal .').
fracas('is Fido a large animal ?').
fracas('Fido is a large animal .').
fracas('Fido is not a large animal .').
fracas('is Fido a small animal ?').
fracas('Fido is a small animal .').
fracas('Mickey is a small animal .').
fracas('Dumbo is a large animal .').
fracas('is Mickey smaller than Dumbo ?').
fracas('Mickey is smaller than Dumbo .').
fracas('Mickey is a small animal .').
fracas('Dumbo is a large animal .').
fracas('is Mickey larger than Dumbo ?').
fracas('Mickey is larger than Dumbo .').
fracas('all mice are small animals .').
fracas('Mickey is a large mouse .').
fracas('is Mickey a large animal ?').
fracas('Mickey is a large animal .').
fracas('all elephants are large animals .').
fracas('Dumbo is a small elephant .').
fracas('is Dumbo a small animal ?').
fracas('Dumbo is a small animal .').
fracas('all mice are small animals .').
fracas('all elephants are large animals .').
fracas('Mickey is a large mouse .').
fracas('Dumbo is a small elephant .').
fracas('is Dumbo larger than Mickey ?').
fracas('Dumbo is larger than Mickey .').
fracas('all mice are small animals .').
fracas('Mickey is a large mouse .').
fracas('is Mickey small ?').
fracas('Mickey is small .').
fracas('all legal authorities are law lecturers .').
fracas('all law lecturers are legal authorities .').
fracas('are all fat legal authorities fat law lecturers ?').
fracas('all fat legal authorities are fat law lecturers .').
fracas('all legal authorities are law lecturers .').
fracas('all law lecturers are legal authorities .').
fracas('are all competent legal authorities competent law lecturers ?').
fracas('all competent legal authorities are competent law lecturers .').
fracas('John is a fatter politician than Bill .').
fracas('is John fatter than Bill ?').
fracas('John is fatter than Bill .').
fracas('John is a cleverer politician than Bill .').
fracas('is John cleverer than Bill ?').
fracas('John is cleverer than Bill .').
fracas('Kim is a clever person .').
fracas('is Kim clever ?').
fracas('Kim is clever .').
fracas('Kim is a clever politician .').
fracas('is Kim clever ?').
fracas('Kim is clever .').
fracas('the PC-6082 is faster than the ITEL-XZ .').
fracas('the ITEL-XZ is fast .').
fracas('is the PC-6082 fast ?').
fracas('the PC-6082 is fast .').
fracas('the PC-6082 is faster than the ITEL-XZ .').
fracas('is the PC-6082 fast ?').
fracas('the PC-6082 is fast .').
fracas('the PC-6082 is faster than the ITEL-XZ .').
fracas('the PC-6082 is fast .').
fracas('is the ITEL-XZ fast ?').
fracas('the ITEL-XZ is fast .').
fracas('the PC-6082 is faster than the ITEL-XZ .').
fracas('the PC-6082 is slow .').
fracas('is the ITEL-XZ fast ?').
fracas('the ITEL-XZ is fast .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('the ITEL-XZ is fast .').
fracas('is the PC-6082 fast ?').
fracas('the PC-6082 is fast .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('is the PC-6082 fast ?').
fracas('the PC-6082 is fast .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('the PC-6082 is fast .').
fracas('is the ITEL-XZ fast ?').
fracas('the ITEL-XZ is fast .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('the PC-6082 is slow .').
fracas('is the ITEL-XZ fast ?').
fracas('the ITEL-XZ is fast .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('is the PC-6082 faster than the ITEL-XZ ?').
fracas('the PC-6082 is faster than the ITEL-XZ .').
fracas('the PC-6082 is as fast as the ITEL-XZ .').
fracas('is the PC-6082 slower than the ITEL-XZ ?').
fracas('the PC-6082 is slower than the ITEL-XZ .').
fracas('ITEL won more orders than APCOM did .').
fracas('did ITEL win some orders ?').
fracas('ITEL won some orders .').
fracas('ITEL won more orders than APCOM did .').
fracas('did APCOM win some orders ?').
fracas('APCOM won some orders .').
fracas('ITEL won more orders than APCOM did .').
fracas('APCOM won ten orders .').
fracas('did ITEL win at least eleven orders ?').
fracas('ITEL won at least eleven orders .').
fracas('ITEL won more orders than APCOM .').
fracas('did ITEL win some orders ?').
fracas('ITEL won some orders .').
fracas('ITEL won more orders than APCOM .').
fracas('did APCOM win some orders ?').
fracas('APCOM won some orders .').
fracas('ITEL won more orders than APCOM .').
fracas('APCOM won ten orders .').
fracas('did ITEL win at least eleven orders ?').
fracas('ITEL won at least eleven orders .').
fracas('ITEL won more orders than the APCOM contract .').
fracas('did ITEL win the APCOM contract ?').
fracas('ITEL won the APCOM contract .').
fracas('ITEL won more orders than the APCOM contract .').
fracas('did ITEL win more than one order ?').
fracas('ITEL won more than one order .').
fracas('ITEL won twice as many orders than APCOM .').
fracas('APCOM won ten orders .').
fracas('did ITEL win twenty orders ?').
fracas('ITEL won twenty orders .').
fracas('ITEL won more orders than APCOM lost .').
fracas('did ITEL win some orders ?').
fracas('ITEL won some orders .').
fracas('ITEL won more orders than APCOM lost .').
fracas('did APCOM lose some orders ?').
fracas('APCOM lost some orders .').
fracas('ITEL won more orders than APCOM lost .').
fracas('APCOM lost ten orders .').
fracas('did ITEL win at least eleven orders ?').
fracas('ITEL won at least eleven orders .').
fracas('the PC-6082 is faster than 500 MIPS .').
fracas('the ITEL-ZX is slower than 500 MIPS .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('ITEL sold 3000 more computers than APCOM .').
fracas('APCOM sold exactly 2500 computers .').
fracas('did ITEL sell 5500 computers ?').
fracas('ITEL sold 5500 computers .').
fracas('APCOM has a more important customer than ITEL .').
fracas('does APCOM have a more important customer than ITEL is ?').
fracas('APCOM has a more important customer than ITEL is .').
fracas('APCOM has a more important customer than ITEL .').
fracas('does APCOM has a more important customer than ITEL has ?').
fracas('APCOM has a more important customer than ITEL has .').
fracas('the PC-6082 is faster than every ITEL computer .').
fracas('the ITEL-ZX is an ITEL computer .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('the PC-6082 is faster than some ITEL computer .').
fracas('the ITEL-ZX is an ITEL computer .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('the PC-6082 is faster than any ITEL computer .').
fracas('the ITEL-ZX is an ITEL computer .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('the PC-6082 is faster than the ITEL-ZX and the ITEL-ZY .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('the PC-6082 is faster than the ITEL-ZX or the ITEL-ZY .').
fracas('is the PC-6082 faster than the ITEL-ZX ?').
fracas('the PC-6082 is faster than the ITEL-ZX .').
fracas('ITEL has a factory in Birmingham .').
fracas('does ITEL currently have a factory in Birmingham ?').
fracas('ITEL currently has a factory in Birmingham .').
fracas('since 1992 ITEL has been in Birmingham .').
fracas('it is now 1996 .').
fracas('was ITEL in Birmingham in 1993 ?').
fracas('Itel was in Birmingham in 1993 .').
fracas('ITEL has developed a new editor since 1992 .').
fracas('it is now 1996 .').
fracas('did ITEL develop a new editor in 1993 ?').
fracas('ITEL developed a new editor in 1993 .').
fracas('ITEL has expanded since 1992 .').
fracas('it is now 1996 .').
fracas('did ITEL expand in 1993 ?').
fracas('ITEL expanded in 1993 .').
fracas('since 1992 ITEL has made a loss .').
fracas('it is now 1996 .').
fracas('did ITEL make a loss in 1993 ?').
fracas('ITEL made a loss in 1993 .').
fracas('ITEL has made a loss since 1992 .').
fracas('it is now 1996 .').
fracas('did ITEL make a loss in 1993 ?').
fracas('ITEL made a loss in 1993 .').
fracas('ITEL has made a loss since 1992 .').
fracas('it is now 1996 .').
fracas('did ITEL make a loss in 1993 ?').
fracas('ITEL made a loss in 1993 .').
fracas('in March 1993 APCOM founded ITEL .').
fracas('did ITEL exist in 1992 ?').
fracas('ITEL existed in 1992 .').
fracas('the conference started on July 4th , 1994 .').
fracas('it lasted 2 days .').
fracas('was the conference over on July 8th , 1994 ?').
fracas('the conference was over on July 8th , 1994 .').
fracas('yesterday APCOM signed the contract .').
fracas('today is Saturday , July 14th .').
fracas('did APCOM sign the contract Friday , 13th . ?').
fracas('APCOM signed the contract Friday , 13th .').
fracas('Smith left before Jones left .').
fracas('Jones left before Anderson left .').
fracas('did Smith leave before Anderson left ?').
fracas('Smith left before Anderson left .').
fracas('Smith left after Jones left .').
fracas('Jones left after Anderson left .').
fracas('did Smith leave after Anderson left ?').
fracas('Smith left after Anderson left .').
fracas('Smith was present after Jones left .').
fracas('Jones left after Anderson was present .').
fracas('was Smith present after Anderson was present ?').
fracas('Smith was present after Anderson was present .').
fracas('Smith left .').
fracas('Jones left .').
fracas('Smith left before Jones left .').
fracas('did Jones leave after Smith left ?').
fracas('Jones left after Smith left .').
fracas('Smith left .').
fracas('Jones left .').
fracas('Smith left after Jones left .').
fracas('did Jones leave before Smith left ?').
fracas('Jones left before Smith left .').
fracas('Smith left .').
fracas('Jones left .').
fracas('Jones left before Smith left .').
fracas('did Smith leave after Jones left ?').
fracas('Smith left after Jones left .').
fracas('Jones revised the contract .').
fracas('Smith revised the contract .').
fracas('Jones revised the contract before Smith did .').
fracas('did Smith revise the contract after Jones did ?').
fracas('Smith revised the contract after Jones did .').
fracas('Jones revised the contract .').
fracas('Smith revised the contract .').
fracas('Jones revised the contract after Smith did .').
fracas('did Smith revise the contract before Jones did ?').
fracas('Smith revised the contract before Jones did .').
fracas('Smith swam .').
fracas('Jones swam .').
fracas('Smith swam before Jones swam .').
fracas('did Jones swim after Smith swam ?').
fracas('Jones swam after Smith swam .').
fracas('Smith swam to the shore .').
fracas('Jones swam to the shore .').
fracas('Smith swam to the shore before Jones swam to the shore .').
fracas('did Jones swim to the shore after Smith swam to the shore ?').
fracas('Jones swam to the shore after Smith swam to the shore .').
fracas('Smith was present .').
fracas('Jones was present .').
fracas('Smith was present after Jones was present .').
fracas('was Jones present before Smith was present ?').
fracas('Jones was present before Smith was present .').
fracas('Smith was present .').
fracas('Jones was present .').
fracas('Smith was present before Jones was present .').
fracas('was Jones present after Smith was present ?').
fracas('Jones was present after Smith was present .').
fracas('Smith was writing a report .').
fracas('Jones was writing a report .').
fracas('Smith was writing a report before Jones was writing a report .').
fracas('was Jones writing a report after Smith was writing a report . ?').
fracas('Jones was writing a report after Smith was writing a report .').
fracas('Smith was writing a report .').
fracas('Jones was writing a report .').
fracas('Smith was writing a report after Jones was writing a report .').
fracas('was Jones writing a report before Smith was writing a report ?').
fracas('Jones was writing a report before Smith was writing a report .').
fracas('Smith left the meeting before he lost his temper .').
fracas('did Smith lose his temper ?').
fracas('Smith lost his temper .').
fracas('When they opened the M25 , traffic increased .').
fracas('').
fracas('').
fracas('Smith lived in Birmingham in 1991 .').
fracas('did Smith live in Birmingham in 1992 ?').
fracas('Smith lived in Birmingham in 1992 .').
fracas('Smith wrote his first novel in 1991 .').
fracas('did Smith write his first novel in 1992 ?').
fracas('Smith wrote his first novel in 1992 .').
fracas('Smith wrote a novel in 1991 .').
fracas('did Smith write it in 1992 ?').
fracas('Smith wrote it in 1992 .').
fracas('Smith wrote a novel in 1991 .').
fracas('did Smith write a novel in 1992 ?').
fracas('Smith wrote a novel in 1992 .').
fracas('Smith was running a business in 1991 .').
fracas('was Smith running it in 1992 ?').
fracas('Smith was running it in 1992 .').
fracas('Smith discovered a new species in 1991 .').
fracas('did Smith discover it in 1992 ?').
fracas('Smith discovered it in 1992 .').
fracas('Smith discovered a new species in 1991 .').
fracas('did Smith discover a new species in 1992 ?').
fracas('Smith discovered a new species in 1992 .').
fracas('Smith wrote a report in two hours .').
fracas('Smith started writing the report at 8 am .').
fracas('Had Smith finished writing the report by 11 am ?').
fracas('Smith had finished writing the report by 11 am .').
fracas('Smith wrote a report in two hours .').
fracas('did Smith spend two hours writing the report ?').
fracas('Smith spent two hours writing the report .').
fracas('Smith wrote a report in two hours .').
fracas('did Smith spend more than two hours writing the report ?').
fracas('Smith spent more than two hours writing the report .').
fracas('Smith wrote a report in two hours .').
fracas('did Smith write a report in one hour ?').
fracas('Smith wrote a report in one hour .').
fracas('Smith wrote a report in two hours .').
fracas('did Smith write a report ?').
fracas('Smith wrote a report .').
fracas('Smith discovered a new species in two hours .').
fracas('did Smith spend two hours discovering the new species ?').
fracas('Smith spent two hours discovering the new species .').
fracas('Smith discovered a new species in two hours .').
fracas('did Smith discover a new species ?').
fracas('Smith discovered a new species .').
fracas('Smith discovered many new species in two hours .').
fracas('did Smith spend two hours discovering new species ?').
fracas('Smith spent two hours discovering new species .').
fracas('Smith was running his own business in two years .').
fracas('did Smith spend two years running his own business ?').
fracas('Smith spent two years running his own business .').
fracas('Smith was running his own business in two years .').
fracas('did Smith spend more than two years running his own business ?').
fracas('Smith spent more than two years running his own business .').
fracas('Smith was running his own business in two years .').
fracas('did Smith run his own business ?').
fracas('Smith ran his own business .').
fracas('in two years Smith owned a chain of businesses .').
fracas('did Smith own a chain of business for two years ?').
fracas('Smith owned a chain of business for two years .').
fracas('in two years Smith owned a chain of businesses .').
fracas('did Smith own a chain of business for more than two years ?').
fracas('Smith owned a chain of business for more than two years .').
fracas('in two years Smith owned a chain of businesses .').
fracas('did Smith own a chain of business ?').
fracas('Smith owned a chain of business .').
fracas('Smith lived in Birmingham for two years .').
fracas('did Smith live in Birmingham for a year ?').
fracas('Smith lived in Birmingham for a year .').
fracas('Smith lived in Birmingham for two years .').
fracas('did Smith live in Birmingham for exactly a year ?').
fracas('Smith lived in Birmingham for exactly a year .').
fracas('Smith lived in Birmingham for two years .').
fracas('did Smith live in Birmingham ?').
fracas('Smith lived in Birmingham .').
fracas('Smith ran his own business for two years .').
fracas('did Smith run his own business for a year ?').
fracas('Smith ran his own business for a year .').
fracas('Smith ran his own business for two years .').
fracas('did Smith run his own business ?').
fracas('Smith ran his own business .').
fracas('Smith wrote a report for two hours .').
fracas('did Smith write a report for an hour ?').
fracas('Smith wrote a report for an hour .').
fracas('Smith wrote a report for two hours .').
fracas('did Smith write a report ?').
fracas('Smith wrote a report .').
fracas('Smith discovered a new species for an hour .').
fracas('').
fracas('').
fracas('Smith discovered new species for two years .').
fracas('did Smith discover new species ?').
fracas('Smith discovered new species .').
fracas('in 1994 ITEL sent a progress report every month .').
fracas('did ITEL send a progress report in July 1994 ?').
fracas('ITEL sent a progress report in July 1994 .').
fracas('Smith wrote to a representative every week .').
fracas('is there a representative that Smith wrote to every week ?').
fracas('there is a representative that Smith wrote to every week .').
fracas('Smith left the house at a quarter past five .').
fracas('she took a taxi to the station and caught the first train to Luxembourg .').
fracas('').
fracas('').
fracas('Smith lost some files .').
fracas('they were destroyed when her hard disk crashed .').
fracas('').
fracas('').
fracas('Smith had left the house at a quarter past five .').
fracas('then she took a taxi to the station .').
fracas('did Smith leave the house before she took a taxi to the station ?').
fracas('Smith left the house before she took a taxi to the station .').
fracas('ITEL always delivers reports late .').
fracas('in 1993 ITEL delivered reports .').
fracas('did ITEL delivered reports late in 1993 ?').
fracas('ITEL delivered reports late in 1993 .').
fracas('ITEL never delivers reports late .').
fracas('in 1993 ITEL delivered reports .').
fracas('did ITEL delivered reports late in 1993 ?').
fracas('ITEL delivered reports late in 1993 .').
fracas('Smith arrived in Paris on the 5th of May , 1995 .').
fracas('Today is the 15th of May , 1995 .').
fracas('she is still in Paris .').
fracas('was Smith in Paris on the 7th of May , 1995 ?').
fracas('Smith was in Paris on the 7th of May , 1995 .').
fracas('when Smith arrived in Katmandu she had been travelling for three days .').
fracas('had Smith been travelling the day before she arrived in Katmandu ?').
fracas('Smith had been travelling the day before she arrived in Katmandu .').
fracas('Jones graduated in March and has been employed ever since .').
fracas('Jones has been unemployed in the past .').
fracas('was Jones unemployed at some time before he graduated ?').
fracas('Jones was unemployed at some time before he graduated .').
fracas('every representative has read this report .').
fracas('no two representatives have read it at the same time .').
fracas('no representative took less than half a day to read the report .').
fracas('there are sixteen representatives .').
fracas('did it take the representatives more than a week to read the report ?').
fracas('it took the representatives more than a week to read the report .').
fracas('while Jones was updating the program , Mary came in and told him about the board meeting .').
fracas('she finished before he did .').
fracas('did Mary SSS story last as long as Jones SSS updating the program ?').
fracas('Mary SSS story lasted as long as Jones SSS updating the program .').
fracas('before APCOM bought its present office building , it had been paying mortgage interest on the previous one for 8 years .').
fracas('since APCOM bought its present office building it has been paying mortgage interest on it for more than 10 years .').
fracas('has APCOM been paying mortgage interest for a total of 15 years or more ?').
fracas('APCOM has been paying mortgage interest for a total of 15 years or more .').
fracas('when Jones got his job at the CIA , he knew that he would never be allowed to write his memoirs .').
fracas('is it the case that Jones is not and will never be allowed to write his memoirs ?').
fracas('it is the case that Jones is not and will never be allowed to write his memoirs .').
fracas('Smith has been to Florence twice in the past .').
fracas('Smith will go to Florence twice in the coming year .').
fracas('two years from now will Smith have been to Florence at least four times ?').
fracas('two years from now Smith will have been to Florence at least four times .').
fracas('last week I already knew that when , in a month SSS time , Smith would discover that she had been duped she would be furious .').
fracas('will it be the case that in a few weeks Smith will discover that she has been duped ; and will she be furious ?').
fracas('it will be the case that in a few weeks Smith will discover that she has been duped ; and she will be furious .').
fracas('no one gambling seriously stops until he is broke .').
fracas('no one can gamble when he is broke .').
fracas('does everyone who starts gambling seriously stop the moment he is broke ?').
fracas('everyone who starts gambling seriously stops the moment he is broke .').
fracas('no one who starts gambling seriously stops until he is broke .').
fracas('does everyone who starts gambling seriously continue until he is broke ?').
fracas('everyone who starts gambling seriously continues until he is broke .').
fracas('nobody who is asleep ever knows that he is asleep .').
fracas('but some people know that they have been asleep after they have been asleep .').
fracas('do some people discover that they have been asleep ?').
fracas('some people discover that they have been asleep .').
fracas('ITEL built MTALK in 1993 .').
fracas('did ITEL finish MTALK in 1993 ?').
fracas('ITEL finished MTALK in 1993 .').
fracas('ITEL was building MTALK in 1993 .').
fracas('did ITEL finish MTALK in 1993 ?').
fracas('ITEL finished MTALK in 1993 .').
fracas('ITEL won the contract from APCOM in 1993 .').
fracas('did ITEL win a contract in 1993 ?').
fracas('ITEL won a contract in 1993 .').
fracas('ITEL was winning the contract from APCOM in 1993 .').
fracas('did ITEL win a contract in 1993 ?').
fracas('ITEL won a contract in 1993 .').
fracas('ITEL owned APCOM from 1988 to 1992 .').
fracas('did ITEL own APCOM in 1990 ?').
fracas('ITEL owned APCOM in 1990 .').
fracas('Smith and Jones left the meeting .').
fracas('did Smith leave the meeting ?').
fracas('Smith left the meeting .').
fracas('Smith and Jones left the meeting .').
fracas('did Jones leave the meeting ?').
fracas('Jones left the meeting .').
fracas('Smith , Anderson and Jones met .').
fracas('was there a group of people that met ?').
fracas('there was a group of people that met .').
fracas('Smith knew that ITEL had won the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('Smith believed that ITEL had won the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('ITEL managed to win the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('ITEL tried to win the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('it is true that ITEL won the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('it is false that ITEL won the contract in 1992 .').
fracas('did ITEL win the contract in 1992 ?').
fracas('ITEL won the contract in 1992 .').
fracas('Smith saw Jones sign the contract .').
fracas('if Jones signed the contract , his heart was beating .').
fracas('did Smith see Jones APOS heart beat ?').
fracas('Smith saw Jones APOS heart beat .').
fracas('Smith saw Jones sign the contract .').
fracas('when Jones signed the contract , his heart was beating .').
fracas('did Smith see Jones APOS heart beat ?').
fracas('Smith saw Jones APOS heart beat .').
fracas('Smith saw Jones sign the contract .').
fracas('did Jones sign the contract ?').
fracas('Jones signed the contract .').
fracas('Smith saw Jones sign the contract .').
fracas('Jones is the chairman of ITEL .').
fracas('did Smith see the chairman of ITEL sign the contract ?').
fracas('Smith saw the chairman of ITEL sign the contract .').
fracas('Helen saw the chairman of the department answer the phone .').
fracas('the chairman of the department is a person .').
fracas('is there anyone whom Helen saw answer the phone ?').
fracas('there is someone whom Helen saw answer the phone .').
fracas('Smith saw Jones sign the contract and his secretary make a copy .').
fracas('did Smith see Jones sign the contract ?').
fracas('Smith saw Jones sign the contract .').
fracas('Smith saw Jones sign the contract or cross out the crucial clause .').
fracas('did Smith either see Jones sign the contract or see Jones cross out the crucial clause ?').
fracas('Smith either saw Jones sign the contract or saw Jones cross out the crucial clause .').


