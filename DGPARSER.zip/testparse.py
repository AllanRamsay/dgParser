# -*- coding: utf-8 -*-
import sys
import re
import codecs
import subprocess 
"""
subprocess.call('sicstus -r dg.sav --goal dgParse("a cat",P), Shell=True)
"""

sicstusheader = re.compile(".*Licensed to man.ac.uk\s*", re.DOTALL)

class PrologException(Exception):

    def __init__(self, s):
        self.s = s

def parseFile():
   #ifile = codecs.open('ReadyToParse', mode='r')
   #for line in ifile:
    # for x in range(0, 3):
      # print line
       #line = [('@', 'REPL'),('Allan','USERNA'),('dhahb','VV'),('Moh','NN')]
      # line =[('@','REP'),('alabbas75','username'),('@','MEN'),('DrA_Farouk235','username'),('هذا','DT'),('حق','NN'),('ونحن','PRP'),('بحمد','NNP'),('الله','NN'),('كمصريين','JJ'),('نحب','VB'),('الله','NN'),('ورسوله','NN'),('محمد','NN'),('وكل','NN'),('الانبياء','NN'),('والرسل','vb'),('ونتاجر','vb'),('مع','NN'),('الله','NN'),('ولعن','VB'),('الله','NN'),('خوارج','NN'),('العصر','NN')]
       line = [('@','REP'),('AliAlaN_','username'),('من','IN'),('قلب','NN'),('الحدث','NN')]
       task = ['sicstus', '-r', 'dg.sav', '--goal', """(dgParseForPython(%s);write([])),halt."""%(line)]
       print " ".join(task)
       x = subprocess.Popen(task, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
       if not sicstusheader.match(x[1]):
          raise PrologException(x[1])
       print x[0]
       convertPrologAnswerToList(x[0])


def parse(text):
   
    task = ['sicstus', '-r', 'dg.sav', '--goal', """(dgParseForPython(%s);write([])),halt."""%(text)]
    print " ".join(task)
    x = subprocess.Popen(task, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    if not sicstusheader.match(x[1]):
        raise PrologException(x[1])
    print x[0]
  # # print  u'\u0646\u0627\u062f\u0631'
   # t = convertPrologAnswerToList(x[0])
  #  for l in t:
      #  for item in l:
          #  ofile.write(item[0][1])
          #  ofile.write(item[0][0])
          #  ofile.write(item[0][1])
          #  ofile.write(item[0][2])
   # ofile.close()
    return convertPrologAnswerToList(x[0])
# codecs.decode(convertPrologAnswerToList(x[0]),'utf-8')

def convertPrologAnswerToList(s):
    atomPattern = re.compile("\[(?P<x>[^:\[]*):(?P<y>[^:]*):(?P<z>[^,\]]*)(?P<t>(,|\]))")
    t = atomPattern.sub("[('\g<x>','\g<y>','\g<z>')\g<t>", s)
    ofile = codecs.open('ofile2', mode='a')
    ofile.write(t+'\n')
    ofile.close()
    return eval(atomPattern.sub("[('\g<x>','\g<y>','\g<z>')\g<t>", s))
   
    


