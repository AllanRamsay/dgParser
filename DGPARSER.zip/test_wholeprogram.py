import COMP34411
reload(COMP34411)
import conll
reload(conll)
import tblforparsing_new as tblp
reload(tblp)
import a2bw
import os, re
from useful import *

"""
We have three versions of the basic system:

(A) the original, just using shift, leftArc, rightArc: score 0.7385
(B) one with shift, leftArc-subj, leftArc-dobj, ... 
(C) one with leftArc-subj, ... which looks at the arguments that the proposed head already has: score 0.7426

C is best, followed by A. But A doesn't assign labels, so we need something to add labels to it.

We can do transformations to the UDT trees. Turning [sleeps, [John],
[park, [in]]] into [sleeps, [John], [in, [park]]] makes things worse,
turning [fool, [a], [John], [is]] into [is, [John], [fool, [a]]] makes
them better. It's a marginal effect either way (because, of course, it
only affects a subset of sentences, and we used to get some of those
right, and we now get some of the transformed ones wrong). But 0.5%
improvement just by doing this is not to be sneezed at.

That's all I've got for the moment for the base parser.

Then TBL gets you between 3-3.5% improvement. 

So we've now got baseline=0.7385, fix copulas and use best TBL=0.7447+0.03=0.777

"""

"""
sentences, pretagged = conll.readconll()
tagger = load('tagger.pck')

sentences, pretagged, brilltagger, parser, training, testing = COMP34411.train(metering=1, brilltagger=False, sentences=sentences, pretagged=pretagged, qwindow=3, stackwindow=2, folds=5, lastfold=0, tagsize=5)

# training is the data that was used for training the base parser,
# testing is what's left over. Testing then gets split into tbl
# training and testing. We can safely mix base parser training data in
# with tbl training, so long as we keep the tbl testing data separate.

trainingdata = tblp.getTrainingData(sentences=training, parser=parser, tagger=tagger, parsed=False)
testingdata = tblp.getTrainingData(sentences=testing, parser=parser, tagger=tagger, parsed=False)
print tblp.accuracy(testingdata)
rules = tblp.getRepairrules(parser=parser, tagger=tagger, threshold=6, trainingdata=trainingdata, testingdata=testingdata, howmuchtrainingdata=0.0, maxrules=0)

>>> sentences, pretagged = conll.readconll()
>>> sentences, pretagged, tagger, parser, training, testing = COMP34411.train(metering=1, brilltagger=tagger, sentences=sentences, pretagged=pretagged, qwindow=3, stackwindow=2, folds=5, lastfold=0, tagsize=5)
>>> train(training, testing, parser=parser, tagger=tagger, maxrules=200)
"""

UDT = "ud-treebanks-v1.1"

def fold(f, n, sentences):
    training = []
    testing = []
    for i in range(len(sentences)):
        if i % n == f:
            testing.append(sentences[i])
        else:
            training.append(sentences[i])
    return training, testing

def train(training, testing, parser, tagger, maxrules=0, howmuchmixeddata=0, howmuchreserveddata=1, howmuchtrainingdata=1, useTBL=True):
    print "**** train(maxrules=%s, howmuchmixeddata=%.2f, howmuchreserveddata=%.2f, howmuchtrainingdata=%.2f) ****"%(maxrules, howmuchmixeddata, howmuchreserveddata, howmuchtrainingdata)
    trainingdata = tblp.getTrainingData(sentences=training, parser=parser, tagger=tagger, parsed=False)
    testingdata = tblp.getTrainingData(sentences=testing, parser=parser, tagger=tagger, parsed=False)[:60000]
    print tblp.accuracy(testingdata)
    deprules = tblp.getRepairRules(threshold=0.00005, trainingdata=trainingdata, testingdata=testingdata, howmuchmixeddata=howmuchmixeddata, howmuchtrainingdata=howmuchtrainingdata, maxrules=maxrules)
    parser.trainingdata = trainingdata
    parser.testdata = testingdata
    return tblp.TBLPARSER(parser, deprules=deprules, tagger=tagger)

def wholething(parser=False, tagger=False, udt=UDT, language="English", f="wholething.txt", maxrules=50, tagsize=5, useTBL=True):
    print """sentences, pretagged, allrelations = conll.readconll(udt='%s', language='%s', f='%s')"""%(udt, language, f)
    sentences, pretagged, allrelations = conll.readconll(udt=udt, language=language, f=f)
    print "wholething(udt=%s, parser=%s, tagger=%s, language='%s', f='%s')"%(udt, parser, tagger, language, f)
    print allrelations.keys()
    print "len(pretagged) %s, len(sentences) %s"%(len(pretagged), len(sentences))
    print "sentences[0].leaves %s"%(sentences[0].leaves)
    sentences, pretagged, tagger, baseparser, training, testing = COMP34411.train(metering=1, brilltagger=tagger, sentences=sentences, pretagged=pretagged, qwindow=3, stackwindow=2, folds=5, lastfold=0, tagsize=tagsize)
    baseparser.language = language
    if useTBL:
        parser = train(training, testing, parser=baseparser, tagger=tagger, maxrules=maxrules, useTBL=useTBL)
        l = tblp.data2tblrelations(parser.baseparser.testdata)
        if  len(l) > 10000:
            print "Using deprel rules: %s"%(language)
            relabelRules = tblp.readTemplates(tblp.relabelling)
            parser.relabelrules = tblp.findAllInstances(relabelRules, l[:-5000], l[-5000:], threshold=6, maxrules=maxrules)
    else:
        parser = baseparser
    parser.tagger = tagger
    print "END %s"%(language)
    return parser

def alllanguages(udt=UDT):
    p = re.compile("UD_(?P<language>.*)")
    parsers = []
    for l in os.listdir("%s/%s/"%(conll.programs, udt)):
        print l
        if "-" in l or "Ancient" in l:
            continue
        l = p.match(l)
        if l:
            print l.group("language")
            try:
                parser = wholething(language=l.group("language"), udt=udt)
            except Exception as e:
                print e
    return parsers
    
"""
Gradually mix data that was used for training the base parser in with
the data that you kept aside for TBL. This is legit -- we can do what
we like with data that isn't being used for testing. The aim here is
to make use of as much data as possible for TBL. What happens is that
you get a small increase when you mix in a bit of original training
data, because you're increasing the amount of data available for TBL,
but after a while it becomes counter-productive, because the data
you're mixing in is stuff that the base parser does a good job on
(because it was trained on it), and hence is not characteristic of the
kinds of things that need to be patched.

Results are stored in mixeddata.txt, mixeddata.csv, mixeddata.xls:
mixeddata.csv is obtained from mixeddata.txt by
scores.scoremixtures. These contain results for hmdt=0, end=0.1,
inc=0.01; there is an experiment running for hmdt=0.1, end=0.2,
inc=0.02, which will show the tailing off effect.
"""

def incrementHMDT(hmdt=0, end=0.1, inc=0.01):
    while hmdt < end:
        train(sentences, parser, tagger, maxrules=100, howmuchtrainingdata=hmdt)
        hmdt += inc

"""
Gradually increase the amount of the reserved data to be used for TBL.
Not yet tested.
"""

def incrementTrainingData(start=0.5, inc=0.1):
    print "incrementTrainingData(start=%s, inc=%s)"%(start, inc)
    while start < 1.0001:
        train(sentences, parser, tagger, maxrules=100, howmuchtrainingdata=start)
        start += inc

