#!/usr/bin/python

import sys
import os
import shutil
from useful import getArg

def savedotfiles(src=".", dest="SAVEDDOTFILES"):
    try:
        shutil.rmtree(dest)
    except:
        print "No such directory as %s"%(dest)
    os.mkdir(dest)
    for f in os.listdir(src):
        if f[0] == "." and len(f) > 2:
            print "%s/%s -> %s/%s"%(src, f, dest, f)
            try:
                if os.path.isdir("%s/%s"%(src, f)):
                    shutil.copytree("%s/%s"%(src, f), "%s/%s"%(dest, f))
                else:
                    shutil.copy("%s/%s"%(src, f), "%s/%s"%(dest, f))
            except Exception as e:
                print "%s, %s"%(f, e)
                
if "savedotfiles.py" in sys.argv[0]:
    args = sys.argv[1:]
    src, args = getArg("--src", args, ".")
    dest, args = getArg("--dest", args, "SAVEDDOTFILES")
    if not args == []:
        raise Exception("Unexpected flag in list: %s. Expected --src <srcfile> --dest <destfile>"%(args))
    savedotfiles(src, dest)
