# -*- coding: utf-8 -*-
import re, sys, codecs
from useful import *
import a2bw
reload(a2bw)

def safe(s):
    return str(s).replace("'", '"').strip()

def readGS(ifile="GoldStandard-01-07-2016.txt", out=sys.stdout):
    s = codecs.open(ifile, encoding="utf-8").read()
    if out == sys.stdout:
        out = codecs.open("/dev/tty", mode="w", encoding="utf-8")
    elif isinstance(out, str):
        out = codecs.open(out, mode="w", encoding="utf-8")
    for l in s.split("\n"):
        l = [x for x in l.strip().split(" ") if len(x) > 0]
        if not l == []:
            out.write('sentence(['),
            sep = ""
            for x in l:
                x = x.split(",")
                if len(x) > 1:
                    if x[0] == "":
                        x[0] = "DUMMY"
                    out.write("%s('%s', '%s', '%s')"%(sep, x[0], a2bw.convert(x[0]), x[1]))
                    sep = ", "
            out.write("]).\n\n")
    out.close()
