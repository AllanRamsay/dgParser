from useful import *
import tag
import conll
reload(conll)
from fp_backup import fixlabel

reload(tag)
import re
from classes import *
import datetime

import malt
reload(malt)

if usingMac():
    BNC = '/Users/KEHOU/PycharmProjects/Parsing/BNC'
    programs = "/Users/KEHOU/PycharmProjects/Parsing"
else:
    BNC = '/opt/info/courses/COMP34411/PROGRAMS/BNC'
    programs = "/opt/info/courses/COMP34411/PROGRAMS"

METERING = 5  # METERING in here has to be an integer: 5 is a good value
tag.METERING = METERING

FORM=0
PARSED=1
GSHEAD=2
TAG=3
LABEL=4
POSITION=5
GSREL=6
ARGS = 7
SAVEDHD=-1

def resetOldHDs(sentences):
    for s in sentences:
        s[PARSED] = s[SAVEDHD]

def getTrainingData(sentences, parser=False, tagger=False, parsed=False, tagsize=5):
    outcome = []
    outsides = ["AAAA", 0, 0, "AA", "LL", False, "LL", 0]
    trainingdata = []
    if parsed == False:
        for i in range(len(sentences)):
            o = parser.parse(sentences[i], tagger=tagger)
            outcome.append(o)
    for i, sentence in enumerate(sentences):
        for j, word in enumerate(sentence.leaves):
            if j == 0:
                trainingdata.append(outsides)
                trainingdata.append(outsides)
            form = word.form
            try:
                gshead = sentence.goldstandard[j].hd-j
                gsrel = fixlabel(sentence.goldstandard[j].rel)
            except Exception as e:
                print "I %s, J %s"%(i, j)
                print sentence
                print sentence.goldstandard
                print sentence.goldstandard[j]
                raise e
            tag = word.tag[:tagsize]
            if outcome == []:
                head = sentence.parsed[j].hd-j
                label = sentence.parsed[j].rel
            else:
                head = outcome[i].parsed[j].hd-j
                label = outcome[i].parsed[j].rel
            instance = [form, head, gshead, tag, label, i, gsrel, head]
            trainingdata.append(instance)
    trainingdata.append(outsides)
    trainingdata.append(outsides)
    return trainingdata

def leaves2tuples(leaves, parsed):
    instances = []
    for word in leaves:
        r = parsed[word.position]
        instance = [word.form, r.hd, False, word.tag, r.rel, word.position, False, r.hd]
        instances.append(instance)
    return instances

def getRepairRules(threshold=0.0005, trainingdata=False, testingdata=False, testing=False, howmuchmixeddata=0.0, howmuchtrainingdata=1, maxrules=0):
    resetOldHDs(trainingdata)
    resetOldHDs(testingdata)
    if METERING:
        unlabelled, labelled = accuracy(trainingdata)
        print "Accuracy of parser on the training data (size %s): %.4f (%.4f)" % (len(trainingdata), unlabelled, labelled)
        unlabelled, labelled = accuracy(trainingdata)
        print "Accuracy of parser on reserved data (size %s): %.4f (%.4f)" % (len(testingdata), unlabelled, labelled)
    templates = readTemplates()
    if METERING:
        print underline("Extracting TBL rules from the reserved data")
    t0 = datetime.datetime.now()
    """
    split the reserved data into a chunk for TBL and a chunk for testing
    """
    N = min(len(testingdata)/2, 10000)
    tbldata, reserved = testingdata[:-N], testingdata[-N:]
    print box("RESERVED %s"%(reserved[:5]))
    """
    howmuchmixeddata: how much of the data that was used for training the base parser
    should we use for TBL? 

    set trainingdata to the appropriate fragment of the supplied dataset

    the obvious value fo howmuchtrainingdata is 0, meaning "don't use any of the data
    that you used for training the base parser for TBL"
    """
    trainingdata = trainingdata[:int(howmuchmixeddata*len(trainingdata))]
    """
    howmuchtrainingdata: this is for experiments where we use a reduced amount of
    data for TBL. 
    """
    rules = findAllInstances(templates, trainingdata+tbldata[int(len(tbldata)*(1-howmuchtrainingdata)):], reserved, threshold=threshold, maxrules=maxrules)
    if METERING:
        print "finding rules took %s seconds"%((datetime.datetime.now()-t0).seconds)
        print underline("Testing extracted TBL rules on the remainder of the reserved data")
    applyrules(reserved, rules)
    return rules

def accuracy(testdata):
    unlabelled = 0
    labelled = 0
    total = 0
    for x in testdata:
        if not x[FORM] == 'AAAA':
            total += 1
            if x[PARSED] == x[GSHEAD]:
                unlabelled += 1
                try:
                    if x[LABEL] == x[GSREL]:
                        labelled += 1
                except:
                    pass
    return float(unlabelled)/float(total), float(labelled)/float(total)

def showConfusion(confusion):
    t = {}
    for x in confusion:
        t[x] = sortTable(confusion[x])
    s = [(t[x][1][1], x) if len(t[x]) > 1 else (0, x) for x in t]
    for x in reversed(sorted(s)):
        x = x[1]
        l = t[x]
        n = l[0][1]
        k = 0.0
        for p in l[1:]:
            k += p[1]
        if n + k == 0:
            print x, t[x]
        else:
            print x, t[x], "%.2f" % (float(n) / float(n + k))

templatePattern = re.compile("#(?P<name>.*?)\s*:\s(?P<d0>\w*)\s*>\s*(?P<d1>\w*)\s*if\s+(?P<conditions>.*?);", re.DOTALL)

templates = """
#t0(D0, D1, P0, P1): D0 > D1 if head[0]=P0 and head[D1]=P1;
#t1(D0, D1, P0, P1, T): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[0]=T;
#t2(D0, D1, P0, P1, T): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T;
#t2a(D0, D1, P0, P1, T0, T1): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[0]=T0 and tag[D1]=T1;
#t3(D0, D1, P0, T0, T1, T2): D0 > D1 if head[0]=P0 and tag[0]=T0 and tag[-1]=T1 and tag[D1]=T2;
#t4(D0, D1, P0, T0, T1, T2): D0 > D1 if head[0]=P0 and tag[0]=T0 and tag[1]=T1 and tag[D1]=T2;
#t5(D0, D1, P0, P1, P2): D0 > D1 if head[0]=P0 and and head[D0]=P1 and head[D1]=P2;
#t6(D0, D1, P0, P1, T0, T1): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[-1]=T1;
#t7(D0, D1, P0, P1, T0, T1): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[1]=T1;
#t8(D0, D1, P0, P1, P2, L0): D0 > D1 if head[0]=P0 and and head[D0]=P1 and head[D1]=P2 and label[D0]=L0;
#t9(D0, D1, P0, P1, P2, L0): D0 > D1 if head[0]=P0 and and head[D0]=P1 and head[D1]=P2 and label[D1]=L0;
#t10(D0, D1, P0, T0, T1, T2, L0): D0 > D1 if head[0]=P0 and tag[0]=T0 and tag[-1]=T1 and tag[D1]=T2 and label[0]=L0;
#t11(D0, D1, P0, T0, T1, T2, L0): D0 > D1 if head[0]=P0 and tag[0]=T0 and tag[1]=T1 and tag[D1]=T2 and label[0]=L0;
#t12(D0, D1, P0, T0, T1, T2, L0): D0 > D1 if head[0]=P0 and tag[0]=T0 and tag[1]=T1 and tag[D1]=T2 and label[1]=L0;
#t13(D0, D1, P0, P1, T0, T1, L0): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[-1]=T1 and label[D1]=L0;
#t14(D0, D1, P0, P1, T0, T1, L0): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[-1]=T1 and label[0]=L0;
#t15(D0, D1, P0, P1, T0, T1, L0): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[1]=T1 and label[D1]=L0;
#t16(D0, D1, P0, P1, T0, T1, L0): D0 > D1 if head[0]=P0 and head[D1]=P1 and tag[D1]=T0 and tag[1]=T1 and label[0]=L0;
#t17(D0, D1, P0, P1, L0, L1, L2): D0 > D1 if head[0]=P0 and head[D1]=P1 and label[0]=L0 and label[D1]=L1 and label[-1]=L2;

"""

"""
current label is L0, change to L1.

We will want to look at people's tags and their labels. The main people we
will want to look at are this word (which is 0) and its head (which is in
the training data). So we need to treat HD specially when we are looking at
ranges. We may also want to look at their daughters: do that later.

data is

word, label, gslabel, pos, parentID
"""
relabelling = """
#t0(L0, L1, P0, P1): L0 > L1 if tag[0]=P0 and tag[HD]=P1;
#t1(L0, L1, P0): L0 > L1 if tag[0]=P0;
#t2(L0, L1, P0, P1): L0 > L1 if tag[0]=P0 and xdtrs[HD]=P1;
#t3(L0, L1, P0, P1, P2): L0 > L1 if tag[0]=P0 and tag[HD]=P1 and xdtrs[HD]=P2;
"""

conditionPattern = re.compile("(?P<what>\S*)\[(?P<range>(-?\d+(\s*,\s*-?\d+)*)|(\w*))\]\s*=(?P<value>\w*)\s*(and)?")

def makeRange(s):
    try:
        return [int(i) for i in re.compile("\s*,\s*").split(s)]
    except ValueError:
        return [i for i in re.compile("\s*,\s*").split(s)]


def readCondition(i):
    return [CONDITION(i.group("what").strip(), makeRange(r), i.group("value")) for r in
            i.group("range").strip().split("and")]

def readConditions(conditions):
    allconditions = []
    for i in conditionPattern.finditer(conditions):
        allconditions += readCondition(i)
    return allconditions

def inrange(i, l):
    return i >= 0 and i < len(l)

def offset(j, i, words):
    if j == 'D0':
        return int(words[i][1])
    elif j == 'D1':
        return int(words[i][2])
    elif j == 'HD':
        return int(words[i][4])
    else:
        raise Exception("Unknown offset '%s'"%(j))

def getword(i, words):
    return words[i][FORM]

def gethead(i, words):
    return words[i][PARSED]

def gettag(i, words):
    return words[i][TAG]

def getlabel(i, words):
    return words[i][LABEL]

def getxdtrs(i, words):
    return words[i][XARGS]

def getargs(i, words):
    return words[i][ARGS]

def checkitem(o, i, r, words, target):
    for j in r:
        try:
            if inrange(i + j, words) and words[i + j][o] == target:
                return True
        except TypeError:
            k = offset(j, i, words)
            if inrange(i + k, words) and words[i + k][o] == target:
                return True
    return False

def checktag(i, r, words, target):
    return checkitem(TAG, i, r, words, target)

def checkhead(i, r, words, target):
    return checkitem(PARSED, i, r, words, target)

def checklabel(i, r, words, target):
    return checkitem(LABEL, i, r, words, target)

def checkargs(i, r, words, target):
    return checkitem(ARGS, i, r, words, target)

def checkxdtrs(i, r, words, target):
    return checkitem(XARGS, i, r, words, target)

class CONDITION:
    
    @staticmethod
    def gstag(i, words):
        return words[i][2]

    def __init__(self, what, where, value):
        self.what = what
        self.where = where
        self.value = value
        self.func = eval('get%s' % what)

    def __repr__(self):
        return "%s%s=%s" % (self.what, self.where, self.value)

    def get(self, i, words):
        return self.func(i + self.where, words)

    def check(self, i, words, target):
        return self.func(i + self.where, words) == target

def tryReset(i, words, target):
    if words[i][1] == target and words[i][2] == target:
        return 0
    elif words[i][2] == target:
        return 1
    else:
        return -1

def doReset(i, words, head):
    try:
        words[i][1] = head
        return True
    except Exception as e:
        print "doReset(%s, %s, %s)"%(i, words, head)
        raise e

class TEMPLATE:
    def __init__(self, name, D0, D1, conditions):
        self.name = name
        self.D0 = D0
        self.D1 = D1
        self.conditions = readConditions(conditions)

    def __repr__(self):
        return "#%s: %s > %s if %s;" % (self.name, self.D0, self.D1, self.conditions)

    def instantiate(self, d):
        form = str(self)
        for k in d:
            form = form.replace(k, str(d[k]))
        return form

    @staticmethod
    def word(word):
        return word[0]

    @staticmethod
    def head(word):
        return word[1]

    @staticmethod
    def gshead(word):
        return word[2]

    @staticmethod
    def tag(word):
        return word[3]

    @staticmethod
    def label(word):
        return word[4]

    def findInstances(self, words, allinstances):
        for i in range(0, len(words)):
            if not words[i][1] == "AA":
                word = words[i]
                if not TEMPLATE.head(word) == TEMPLATE.gshead(word):
                    options = [[self.D0, [TEMPLATE.head(word)]],
                               [self.D1, [TEMPLATE.gshead(word)]]]
                    for c in self.conditions:
                        cd = []
                        for j in c.where:
                            try:
                                if inrange(i+j, words):
                                    cd.append(c.func(i+j, words))
                            except TypeError:
                                k = offset(j, i, words)
                                if inrange(i+k, words):
                                    cd.append(c.func(i+k, words))
                        options.append([c.value, cd])
                    d = {}
                    enumerateall(options, d, (lambda: incTable("%s::%s" % (self.name, d), allinstances)))


    def makeInstance(self, dict):
        s = ""
        for c in self.conditions:
            if c.what == "head":
                c = """check%s(i, %s, words, %s)""" % (c.what, c.where, dict[c.value])
            else:
                c = """check%s(i, %s, words, "%s")""" % (c.what, c.where, dict[c.value])
            if s == "":
                s = "%s" % (c)
            else:
                s += " and %s" % (c)
        replacement = dict[self.D1]
        if isinstance(replacement, str):
            replacement = "'%s'"%(replacement)
        s = """(lambda i, words: tryReset(i, words, %s) if %s else 0)""" % (replacement, s)
        s = s.replace('"""', """'"'""")
        f = eval(s)
        f.src = s
        return f

    def makeRule(self, dict):
        s = ""
        for c in self.conditions:
            if c.what == "head":
                c = """check%s(i, %s, words, %s)""" % (c.what, c.where, dict[c.value])
            else:
                c = """check%s(i, %s, words, "%s")""" % (c.what, c.where, dict[c.value])
            if s == "":
                s = "%s" % (c)
            else:
                s += " and %s" % (c)
        replacement = dict[self.D1]
        if isinstance(replacement, str):
            replacement = "'%s'"%(replacement)
        s = """(lambda i, words: doReset(i, words, %s) if %s else 0)""" % (replacement, s)
        s = s.replace('"""', """'"'""")
        f = eval(s)
        f.src = s
        return f

class RULE:
    
    def __init__(self, template, reset, grossScore, netScore):
        self.template = template
        self.reset = reset
        self.grossScore = grossScore
        self.netScore = netScore

    def __str__(self):
        return "RULE(%s, %s, grossScore:%s, netScore: %s)" % (
            self.template, self.reset.src, self.grossScore, self.netScore)

    def __call__(self, i, text):
        """
        We may have converted reset back into a string in order to pickle it,
        so if this goes wrong we will eval it (and set that as the value of reset)
        """
        try:
            return self.reset(i, text)
        except TypeError:
            r = self.reset
            self.reset = eval(r)
            self.reset.src = r
            return self.reset(i, text)

    def removeFunctions(self):
        self.reset = self.reset.src

def enumerateall(options, instance, task):
    if options == []:
        task()
    else:
        x, l = options[0]
        for y in l:
            instance[x] = y
            enumerateall(options[1:], instance, task)
            del instance[x]


def checkvar(var, value, table):
    if var in table:
        return table[var] == value
    else:
        table[var] = value
        return True

def readTemplates(templates=templates):
    alltemplates = []
    for t in [TEMPLATE(i.group('name'), i.group('d0'), i.group('d1'), i.group('conditions')) for i in
              templatePattern.finditer(templates)]:
        alltemplates.append(t)
    return alltemplates

"""
trainingdata and testdata are lists of lists, where each line is a set
of features. You can ask to see any feature of self or any (range of)
neighbours.

The list of features can be of arbitrary length, but we
do have to know what they are (obvs), beause we have a pile of
functions with names like checkhead and checklabel which need to know
which feature head and label are. When we want to use templates with a
different set of features, we have to define these functions. Probably be
better if we did that automatically, but right now we have to set them
up by hand.

For reassigning labels, we could use

my pos, my head's pos, my current label, head's current label, neighbours' pos and label.

"""

def findAllInstances(templates, trainingdata, testingdata, threshold=6, maxrules=0):
    if threshold < 1:
        threshold = threshold*len(trainingdata)
    if METERING:
        unlabelled, labelled = accuracy(trainingdata)
        print "Initial score %.3f (labelled %.3f) \nThreshold %s, dataset %s" % (float(unlabelled), float(labelled), threshold, len(trainingdata))
    templatetable = {}
    for t in templates:
        templatetable[t.name] = t
    rules = []
    while True:
        allinstances = {}
        if METERING:
            print underline("Finding initial instances")
        for t in templates:
            t.findInstances(trainingdata, allinstances)
        if METERING:
            print "Found--reorganising them"
        instances = []
        for i in allinstances:
            k, d = i.split("::")
            d = eval(d)
            f = templatetable[k].makeInstance(d)
            instances.append([allinstances[i], f, k, d])
        instances.sort()
        instances.reverse()
        if METERING:
            print underline("Top %s candidate rules" % (METERING))
            for x in instances[:METERING]:
                print "Candidate rule %s: gross score %s" % (templatetable[x[2]].instantiate(x[3]), x[0])
        bestscore = 0
        best = False
        if METERING:
            print "Sorted--scoring them"
        l = []
        for i in instances:
            f = i[1]
            if i[0] < bestscore:
                break
            score = 0
            for j in range(len(trainingdata)):
                score += f(j, trainingdata)
            i.append(score)
            if score > bestscore:
                bestscore = score
                best = i
            if METERING:
                l.append((i[-1], i))
        if bestscore < threshold:
            break
        r = makeRule(best, templatetable)
        if METERING:
            print underline("Top %s net scoring rules") % (METERING)
            l.sort()
            l.reverse()
            for i in l[:METERING]:
                t = makeRule(i[1], templatetable)
                print "rule: %s, gross score %s, net score %s" % (t.template, t.grossScore, t.netScore)
        for j in range(len(trainingdata)):
            r(j, trainingdata)
        rules.append(r)
        if METERING:
            unlabelled, labelled = accuracy(trainingdata)
            print "Score=%.4f (%.3f), len(rules)=%s" % (unlabelled, labelled, len(rules))
        resetOldHDs(testingdata)
        start = now()
        applyrules(testingdata, rules)
        print "Application of TBL rules @ %s words/sec"%(int(len(testingdata)/timeSince(start)))
        if len(rules) == maxrules:
            break
    return rules

def makeRule(k, templatetable):
    t = str(templatetable[k[2]])
    f = k[1]
    for x in k[3]:
        t = t.replace(x, str(k[3][x]))
    f.template = t
    t = templatetable[k[2]]
    d = k[3]
    return RULE(t.instantiate(d), t.makeRule(d), k[0], k[-1])

def sentence2list(sentence):
    words = []
    for word in sentence.leaves:
        relation = sentence.parsed[word.position]
        words.append([word.form, relation.hd, relation.hd, word.tag, relation.rel, word.position, relation.rel, 0, -1])
    outsides = ["AAAA", 0, 0, "AA", "LL", False, "LL", 0]
    return [outsides]+words+[outsides]

def applyrules(text, rules, testing=True):
    print "testdata %s"%(text[:10])
    testsize = len(text)
    if testing:
        beforeu, beforel = accuracy(text)
    for rule in rules:
        for i in range(len(text)):
            rule(i, text)
    if testing:
        afteru, afterl = accuracy(text)
        if METERING:
            print "Before repairing %.4f (%.4f) (test size = %s)" % (beforeu, beforel, testsize)
            print "After repairing %.4f (%.4f) (test size = %s)" % (afteru, afterl, testsize)
            # print underline("Confusion matrix")
            # tag.showConfusion(confusion)
        else:
            print ", %s, %s" % (before, after)
    return text


# def plot(pretagged, p=1.5, n0=500, n1=40000):
#     while n0 < n1:
#         print n0
#         rules = trainwithmxlandbrill(pretagged=pretagged, N=n0, mxltagsize=2, tagsize=2, atagsize=2)
#         n0 = int(p*n0)

import math

def importdict(targetdict, importeddict):
    for x in importeddict:
        NN = 0
        VV = 0
        for k in importeddict[x]:
            if k[0] == 'N':
                NN += importeddict[x][k]
            elif k[0] == 'V':
                VV += importeddict[x][k]
        if (NN > 0 or VV > 0) and not x in targetdict:
            targetdict[x] = {}
        if NN > 0:
            targetdict[x]['NN'] = math.sqrt(NN)
        if VV > 0:
            targetdict[x]['VB'] = math.sqrt(VV)
        if NN > 0 or VV > 0:
            normalise(targetdict[x])

XLABEL = 1
XHD = 4
ARGS = 7
XARGS = 8

def tblparsing2tblrelations(x):
    return [x[FORM], x[LABEL], x[GSREL], x[TAG], x[PARSED], x[POSITION], x[GSHEAD], [], [], x[LABEL]]

def rem1(x, l0):
    l1 = []
    noneFound = True
    for y in l0:
        if noneFound and not y == x:
            l1.append(y)
            noneFound = False
    return l1

def bitwise(l):
    bits = 0
    for i, x in enumerate(l):
        if x in {"subj": True, "dobj": True, "det": True, "case": True}:
            bits = bits | (1 << i)
    return bits
            
def data2tblrelations(data):
    newdata = map(tblparsing2tblrelations, data)
    for i, d in enumerate(data):
        h = newdata[i+d[PARSED]]
        h[ARGS].append(d[LABEL])
    for i, d in enumerate(newdata):
        h = newdata[i+d[XHD]]
        d[XARGS] = bitwise(rem1(d[XLABEL], h[ARGS]))
    return newdata

class TBLPARSER:

    def __init__(self, baseparser=False, chunker=False, stackwindow=2, qwindow=3, tagsize=5, deprules=False, relabelrules=False, tagger=False):
        self.chunker = chunker
        self.baseparser = baseparser
        self.stackwindow = stackwindow
        self.qwindow = qwindow
        self.tagsize = tagsize
        self.deprules = deprules
        self.relabelrules = relabelrules
        self.tagger = tagger

    def parse(self, text, tagger=False, keepscore=True, justParse=True):
        if isinstance(text, str):
            text = self.tagger.tag(text)
        sentence = self.baseparser.parse(text, tagger=self.tagger, keepscore=keepscore, justParse=justParse)
        if self.deprules:
            sentence.tuples = leaves2tuples(sentence.leaves, sentence.parsed)
            applyrules(sentence.tuples, self.deprules)
            sentence.parsed = {}
            for x in sentence.tuples: 
                sentence.parsed[x[POSITION]] = RELATION(x[PARSED], x[POSITION], x[LABEL])
        if False and self.relabelrules:
            tuples4relabelling = data2blrelations(sentence.tuples)
            relabelled = applyrules(tuples4relabelling, self.relabelrules)
            sentence.relabelled = relabelled
        if justParse:
            sentence.dtree = malt.buildtree(sentence.parsed, sentence.leaves)
        return sentence
    
    def removeFunctions(self):
        if self.deprules:
            for rule in self.deprules:
                rule.removeFunctions()
        if self.relabelrules:
            for rule in self.relabelrules:
                rule.removeFunctions()
            
    def dump(self, dfile):
        self.removeFunctions()
        self.parser.removeFunctions()
        self.baseparser.classifier.data = False
        self.baseparser.classifier.trainingdata = False
        self.baseparser.classifier.testdata = False
        self.baseparser.classifier.instances = False
        dump(self, dfile)

def finddtrs(x, indent=""):
    print ("%sdtr %s"%(indent, x))[:100]
    if callable(x):
        print "!!! %s"%(x)
    try:
        for key in x.__dict__:
            print "%skey %s"%(indent, key)
            finddtrs(x.__dict__[key], indent=indent+" ")
    except:
        pass

import types
def modules(module, indent=""):
    if module.__class__ == types.ModuleType:
        if not "/System" in str(module):
            print "%s%s"%(indent, module.__name__)
            try:
                for x in module.__dict__.values():
                    modules(x, indent=indent+" ")
            except:
                pass
