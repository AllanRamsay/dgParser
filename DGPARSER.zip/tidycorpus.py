
from useful import *# -*- coding: utf-8 -*-
import re, sys, codecs
from useful import *
import a2bw
reload(a2bw)

NONARABIC = re.compile("(\S*(ai|e)\S*,(NN|V))|(atin)|(,(JJ(R|S)|VB(I|N|D|G|P)|PRP$|NNS|MD|SYM|LS))")
def tidyCorpus(ifile, out=sys.stdout):
    with safeout(out) as write:
        commaPattern = re.compile(",,\S+")
        for l in open(ifile):
            if not NONARABIC.search(l) :
                while l[0] == " ":
                    l = l[1:]
                commaPattern.sub("COMMA,COMMA", l)
                l = l.replace("'", "SQUOTE").replace("""'",WRP""", '",PUNC').replace('",PUNC', 'DQUOTE,DQUOTE').replace("'", "").replace(",,PUNC", "COMMA,COMMA").replace(",,,", "COMMA,COMMA")
                write(l)

def safe(s):
    return str(s).replace("'", '"').strip()

def corpus2prolog(ifile="patched.txt", out=sys.stdout, N=-1):
    s = codecs.open(ifile, encoding="utf-8").read()
    if out == sys.stdout:
        out = codecs.open("/dev/tty", mode="w", encoding="utf-8")
    elif isinstance(out, str):
        out = codecs.open(out, mode="w", encoding="utf-8")
    if not out == sys.stdout:
        out.write("""
%%%% This file was made by calling 'corpus2prolog("%s", "%s")'
"""%(ifile, out.name))

    n = 0
    with safeout(out, encoding="UTF-8") as write:
        for l in s.split("\n"):
            l = [x for x in l.strip().split(" ") if len(x) > 0]
            if not l == []:
                n += 1
                write(u'sentence(['),
                sep = ""
                for x in l:
                    x = x.split(",")
                    if len(x) > 1:
                        if x[0] == "":
                            x0 = "DUMMY"
                        else:
                            x0 = x[0]
                        x0bw = a2bw.convert(x0, a2bw.bw2atable)
                        write(u"%s('%s', '%s', '%s')"%(sep, x0bw, x0, x[1]))
                        sep = u", "
                write(u"]).\n\n")
                if n == N:
                    break
  
