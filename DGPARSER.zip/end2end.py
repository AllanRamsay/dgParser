#!/usr/bin/python

import re, sys, os, subprocess, shutil
from useful import *
import a2bw, tidytraining, tidycorpus
reload(a2bw)
reload(tidycorpus)
reload(tidytraining)
import test_wholeprogram as wp
reload(wp)

"""
Read a file from Fahad's segmenter and run it through the Prolog parser
to generate a file of segments.

Problems at this point: 

-- non-UTF-8 emojis are horrible. Python does worse with them than Prolog.  
-- not all nouns with Al- are segmented correctly ('AlErAq', 'Alkbyr', ...)
-- some unexpected tags: NNS, FW, EMOJP, MD, VBN ... I think these are mainly 
   non-Arabic, so I'm excluding sentences that include them (apart from FW)
"""

corpus = "100TaggedTweets-15-10-2016"

def conll2prolog(corpus="100TaggedTweets-15-10-2016", N1=-1):
    """ Original may contain some stuff that needs patching (e.g. English) """
    tidycorpus.tidyCorpus("%s.txt"%(corpus), out="%stidy.txt"%(corpus))
    """ Now turn that into N Prolog clauses """
    tidycorpus.corpus2prolog("%stidy.txt"%(corpus), out="%ssentences.pl"%(corpus), N=N1)
    """ Split sentences into manageable segments """
    process = "/usr/local/bin/sicstus -r parser.sav --goal consult('%ssentences.pl'),ppandhalt('%ssegments')."%(corpus, corpus)
    sys.stdout.flush()
    subprocess.Popen(process.split(" "), stdout=sys.stdout, stderr=subprocess.STDOUT).wait()

"""
Use the rule-based parser to create the initial treebank
""" 
def makeBaseTreeBank(corpus):
    sys.stdout.flush()
    subprocess.Popen(("/usr/local/bin/sicstus -r parser.sav --goal consult('%ssegments'),parse2conll('%sbasetreebank.cnll'),halt."%(corpus, corpus)).split(" "), stdout=sys.stdout, stderr=subprocess.STDOUT).wait()

"""
We sometimes create CNLL files with the wrong offsets. This sorts that out
"""

def tidyCNLL(corpus):
    tidytraining.tidytraining("%s.cnll"%(corpus), "%stidy.cnll"%(corpus))
    os.remove("%s.cnll"%(corpus))
    os.rename("%stidy.cnll"%(corpus), "%s.cnll"%(corpus))

"""
Read a Fahad style file, convert it to a list of [word, tag] pairs to be fed
directly to the parser.
"""
def text2conll(ifile):
    rawtext = []
    for l in codecs.open(ifile, encoding="utf-8").read().split("\n"):
        l1 = []
        for x in l.split(" "):
            x = x.split(",")
            if len(x) == 2:
                x[0] = a2bw.convert(x[0]).strip().encode("UTF-8")
                try:
                    x[1] = str(x[1]).strip().encode("UTF-8")
                except:
                    print x[1].strip()
                    raise Exception("AAA")
                l1.append(x)
        rawtext.append(l1)
    return rawtext

def train(corpus, useTBL=True, maxrules=50):
    makeBaseTreeBank(corpus)
    tidyCNLL('%sbasetreebank'%(corpus))
    return wp.wholething(parser=False, tagger=False, udt=".", language="", f="%sbasetreebank.cnll"%(corpus), maxrules=maxrules, useTBL=useTBL)

def makeCompleteTreeBank(corpus, parser, outsink=sys.stdout, N2=-1):
    alltrees = []
    print box("makeCompleteTreeBank('%s', %s, '%s', %s)"%(corpus, parser, outsink, N2))
    conll = text2conll("%stidy.txt"%(corpus))
    for sentence in conll:
        print "%s %s %.3f"%(len(alltrees), len(conll), float(len(alltrees))/float(len(conll)))
        if len(sentence) > 2:
            print u"RUNNING PARSER IN MAKECOMPLETETREEBANK %s"%(sentence[:5])
            parser.tagger = False
            tree = parser.parse(sentence)
            try:
                wp.tblp.applyrules(tree, parser.rules)
            except:
                pass
            alltrees.append(tree)
            if len(alltrees) == N2:
                break
    with safeout(outsink) as write:
        for i, tree in enumerate(alltrees):
            s = u"constrained(%s, ["%(i)
            sep = u""
            offset = tree.leaves[0].position+1
            for w in tree.leaves:
                try:
                    wroot = u"%s"%(w.root).replace("'", "").replace("\\", "/")
                    if wroot == u"":
                        wroot = "???"
                except:
                    wroot = "???"
                try:
                    wform = u"%s"%(w.form).replace("'", "").replace("\\", "/")
                    if wform == u"":
                        wform = "???"
                except:
                    wform = "???"
                s += u"%s('%s', '%s', '%s')"%(sep, wroot, wform, w.tag)
                sep = u", "
            s += u"], [%s,"%(offset)
            sep= u""
            for link in tree.parsed.values():
                s += u"%slinked(%s, %s, %s)"%(sep, i, link.dtr+1, link.hd+1)
                sep = u", "
            s += u"]).\n\n"
            if not tidycorpus.NONARABIC.search(s):
                try:
                    write(str(s))
                except:
                    write(s)

def retrain(corpus, parser, N2=-1, maxrules=50, useTBL=True):
    makeCompleteTreeBank(corpus, parser, outsink="%sconstrained.pl"%(corpus), N2=N2)
    sys.stdout.flush()
    subprocess.Popen(("/usr/local/bin/sicstus -r parser.sav --goal consult('%sconstrained'),parseConstrained('%sreparsed.cnll'),halt."%(corpus, corpus)).split(" "), stdout=sys.stdout, stderr=subprocess.STDOUT).wait()
    tidyCNLL("%sreparsed"%(corpus))
    return wp.wholething(parser=False, tagger=False, udt=".", language="", f="%sreparsed.cnll"%(corpus), maxrules=maxrules, useTBL=useTBL)

def fixerrors(corpus, parser, N2=-1, maxrules=50, useTBL=True):
    print box("fixerrors(%s, %s, %s, %s, %s)"%(corpus, parser, N2, maxrules, useTBL))
    makeCompleteTreeBank(corpus, parser, outsink="%sconstrained.pl"%(corpus), N2=N2)
    sys.stdout.flush()
    print box("about to find errors")
    subprocess.Popen(("/usr/local/bin/sicstus -r parser.sav --goal consult('%sconstrained'),findAllErrors('%serrors.cnll',%s),halt."%(corpus, corpus, N2)).split(" "), stdout=sys.stdout, stderr=subprocess.STDOUT).wait()
    tidytraining.tidytraining("%serrors.cnll"%(corpus), "%serrorstidy.cnll"%(corpus))
    with safeout("%soriginalwitherrors.cnll"%(corpus)) as write:
        write(open("%sbasetreebank.cnll"%(corpus)).read())
        write(open("%serrorstidy.cnll"%(corpus)).read())
    return wp.wholething(parser=False, tagger=False, udt=".", language="", f="%soriginalwitherrors.cnll"%(corpus), maxrules=maxrules, useTBL=useTBL)
        
def doItAll(corpus="100TaggedTweets-15-10-2016", N1=1000, N2=20000, maxrules=50, useTBL=True, bootstrapping=False):
    """
    Convert from Fahad's format to cnll and Prolog, break 
    into N1 sentences and break these into segments
    """
    T0 = now()
    print box("START TIME %s"%(T0))
    print box("./end2end.py corpus=%s N1=%s N2=%s"%(corpus, N1, N2))
    conll2prolog(corpus=corpus, N1=N1)
    """
    Use the rule-based parser to make a treebank from the
    segments you've just made and train a MALT (with TBL)
    on this
    """
    T1 = now()
    parser = train(corpus, maxrules=maxrules, useTBL=useTBL)
    T2 = now()
    print box("Time for first round of training %s"%(timediff(T2, T1)))
    """
    Parse N2 sentences using this parser, make a new 
    treebank out of the examples that the rule-based parser
    likes, train a new parser on this. This bit doesn't look
    great, because the rule-based parser doesn't seem to
    like very much of what the parser produces.
    """
    while bootstrapping:
        if bootstrapping == "fixerrors":
            parse = fixerrors(corpus, parser, N2=N2, maxrules=maxrules, useTBL=useTBL)
        else:
            parser = retrain(corpus, parser, N2=N2, maxrules=maxrules, useTBL=useTBL)
        bootstrapping = False
    T3 = now()
    print box("Time for retraining %s"%(timediff(T3, T2)))
    TN = now()
    print box("END TIME %s, total time %s"%(TN, timediff(TN, T0)))
    return parser

if "end2end.py" in sys.argv[0]:
    N1=1000
    N2=1000
    bootstrapping = False
    useTBL = False
    corpus = "100TaggedTweets-15-10-2016"
    maxrules=50
    for flag in sys.argv[1:]:
        flag = flag.split("=")
        if len(flag) > 1:
            [flag, value] = flag
            print flag, value
            if flag=="N1":
                N1 = int(value)
            elif flag=="N2":
                N2 = int(value)
            elif "corpus".startswith(flag):
                corpus = value
            elif "maxrules".startswith(flag):
                maxrules = int(value)
            elif "bootstrapping".startswith(flag):
                bootstrapping = value
            else:
                print "No such flag %s"%(flag)
                sys.exit()
        else:
            flag = flag[0]
            if "-redirect".startswith(flag):
                try:
                    sys.stdout = open("end2end.py corpus=%s N1=%s N2=%s.log"%(corpus, N1, N2), 'w')
                except Exception as e:
                    print e
                    sys.exit()
            elif "-help".startswith(flag):
                print "end2end N1=<segments for base treebank> N2=<trees for retraining> corpus=<100TaggedTweets-15-10-2016 or similar> -redirect"
                sys.exit()
            elif "-useTBL".startswith(flag):
                useTBL = True
            else:
                print "No such flag %s"%(flag)
                sys.exit()
    doItAll(corpus=corpus, N1=N1, N2=N2, maxrules=maxrules, useTBL=useTBL, bootstrapping=bootstrapping)
