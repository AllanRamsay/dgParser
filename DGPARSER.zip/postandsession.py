import Cookie
import os
import re
import datetime

def checkPOST(field, post):
    if field in post:
        x = post[field]
        if isinstance(x, list):
            x = x[0]
        x = x.value
        if isinstance(x, tuple):
            x = x[0]
        return x.strip()
    else:
        return ""

def checkSESSION(field, session):
    if session and field in session:
        x = session[field].value
        if isinstance(x, tuple):
            x = x[0]
        return x.strip()
    else:
        return ""

def checkPOSTandSESSION(field, post, session, trustpost=False):
    value = checkPOST(field, post)
    if not value == "" or (trustpost and field in post):
        return value
    else:
        return checkSESSION(field, session)
    
def checkPOSTRadio(field, post):
    v = checkPOST(field, post)
    if v == "on" or v == "true":
        return "true"
    else:
        return "false"
    
def checkPOSTandSESSIONRadio(field, post, session):
    v = checkPOSTandSESSION(field, post, session)
    if v == "on" or v == "true":
        return "true"
    else:
        return "false"

def copyFromPOSTtoSESSION(fields, post, session):
    for field in fields:
        if checkSESSION(field, session) == "":
            session[field] = unhtmlsafe(checkPOST(field, post))

def getAllFromPOSTandSESSION(fields, post, session):
    return [checkPOSTandSESSION(field, post, session) for field in fields]

def copyAllPOSTtoSESSION(post, session):
    copyFromPOSTtoSESSION(post, post, session)
        
def clearSESSION(fields, session):
    for f in fields:
        if f in session:
            session[f] = ""

def clearSessionExcept(session, fields):
    for f in session.keys():
        if not f in fields:
            session[f] = ""

def plantOptions(options, selected):
    s = ""
    for x, y in options:
        if x == selected:
            s +="""
  <option value="%s" selected>%s</option>
  """%(x, y)
        else:
            s +="""
  <option value="%s">%s</option>
  """%(x, y)
    return s

def encode(s):
    return md5(s).hexdigest()

def setFromPOST(post, session, name, type, otherstuff=""):
    if post.has_key(name):
        value = post[name].value
    elif session and session.has_key(name):
        value = session[name].value
    else:
        value = False
    if value:
        return """<input type="%s" name="%s" id="%s" value="%s" %s>"""%(type, name, name, value, otherstuff)
    else:
        return """<input type="%s" name="%s" id="%s" %s>"""%(type, name, name, otherstuff)

def javascript(action):
    return """<script type="text/javascript">%s</script>"""%(action)

def allPOST(fields, post):
    return [checkPOST(k, post) for k in fields]

def tupleAllPOST(fields, post):
    return tuple(allPOST(fields, post))

def makeForm(url):
    content = "myform = document.createElement('form');\n"
    content = content+"document.body.appendChild(myform);\n"
    content = content+"myform.method='post';\n"
    content = content+"myform.action='%s';\n"%(url)
    return content

def getArgsFromPOST(args, post):
    return [(arg, checkPOST(arg, post)) for arg in args]

def addArgs(args):
    content = ""
    for (arg, value) in args:
        content = content+"myvar = document.createElement('input');\n"
        content = content+"myvar.type = 'hidden';\n"
        content = content+"myvar.name = '%s';\n"%(arg)
        content = content+"myvar.value = '%s';\n"%(value)
	content = content+"myform.appendChild(myvar);\n"
    return content

def redirect1(url, args=[]):
    content = makeForm(url)
    content = content+addArgs(args)
    content = content+"myform.submit();\n"
    return content

def redirect(url, args=[]):
    return javascript(redirect1(url, args))

def alert(msg):
    return javascript("alert(%s)"%(msg))

def confirm(msg, action1, action2):
    return javascript("try{if(confirm('%s')){%s}else{%s}}catch(e){alert(e)}"%(msg, action1, action2))

"""
def checkCookie():
    try:
        return Cookie.SimpleCookie(os.environ["HTTP_COOKIE"])
    except:
        return Cookie.SimpleCookie()
"""

def checkCookie():
    cookie = Cookie.SimpleCookie()
    cookie_string = os.environ.get('HTTP_COOKIE')
    if cookie_string:
        cookie.load(cookie_string)
    return cookie
    
def setRadioButton(name):
    return "<input type='radio' name='%s'/>"%(name)

def htmlspaces(s):
    return s.replace(" ", "&nbsp;")

def nl2br(s):
    return s.replace("\n", "<br>")
    
def menu(menuitems, top):
    s = '<div valign="top"><div valign="top" id="section-navigation"><ul>'
    for menuitem in menuitems:
	s = s+'<li><a href="xxx">%s</a></li>'%(menuitem)
    return s+'</ul></div></div>'

pound = u'\xa3'
escapes = {'"':"&#34;",
           "#":"&#35;",
           "$":"&#36;",
           "%":"&#37;",
           "&":"&#38;",
           "'":"&#39;",
           "(":"&#40;",
           ")":"&#41;",
           "*":"&#42;",
           "+":"&#43;",
           ",":"&#44;",
           "-":"&#45;",
           "/":"&#47;",
           "[":"&#91;",
           "\\":"&#92;",
           "]":"&#93;",
           "^":"&#94;",
           "_":"&#95;",
           "`":"&#96;",
           "{":"&#123;",	
           "|":"&#124;",	 
           "}":"&#125;",
           ".":"&#46;",
           "~":"&#126;",
           "UKP":"&#163;",
           "\n":"<br>",
           "\r":"<br>"}
