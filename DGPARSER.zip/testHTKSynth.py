#!/usr/bin/python

import sys
from htk import testsynth, ArgException

def testHTKSynth(argv):
    n = 100
    d = "."
    grammar = "grammar.txt"
    words2phones = "dict.txt"
    phonelengths = "phonedict.txt"
    for i in range(1, len(argv), 2):
        flag = argv[i]
        value = argv[i+1]
        if flag == "-g" or "--grammar".startswith(flag):
            grammar = value
        elif flag == "-w" or "--words2phones".startswith(flag):
            words2phones = value
        elif flag == "-p" or "--phonelengths".startswith(flag):
            phonelengths = value
        elif flag =="-n":
            n = value
        elif flag == "-d" or "--directory".startswith(flag):
            d = value
        else:
            raise ArgException("Unrecognised flag: %s"%(flag))
    acc, aligned = testsynth(d, testing="testprompts.txt", dict=words2phones, htkdict="htkdict.txt",phonelengths=phonelengths, model='hmm15', tied='tiedlist', n=n)
    print acc
    for a in aligned:
        print a
        
if "testHTKSynth" in sys.argv[0]:
    try:
        testHTKSynth(sys.argv)
    except ArgException as e:
        print "%s: %s"%(e.__class__.__name__, e.msg)
        print """
testHTKSynth.py --grammar <grammar> --words2phones <dict> --phonelengths <pldict> -n <N> --directory <dir>
        
directory defaults to ".", words2phones to "words2phones.txt",
phonelengths to "phonedict.txt", grammar to "grammar.txt", n to 100

Any of the flags may be abbreviated, e.g. --directory to --d
"""
