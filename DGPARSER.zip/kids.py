import re, sys, codecs
from useful import *

def kids(ifile="kids.txt", outsink="kids1.txt"):
    with safeout(outsink) as write:
        for line in open(ifile):
            if re.compile(".*\d+$").match(line):
                write("%s\n"%(re.compile("\s\s*").sub(" ", line.strip())))

def merge(parsed="patchedtrees.txt", source="kids1.txt", patched="patched.txt", original="unpatched.txt", outsink=sys.stdout):
    segment = re.compile(".*segment\((?P<segment>\d*).*", re.DOTALL)
    segments = {}
    for s in re.compile("\*+\n").split(open(parsed).read().strip()):
        m = segment.match(s)
        if m:
            s = s.decode("utf-8")
            i = int(m.group("segment"))
            try: 
                segments[i].append(s)
            except:
                segments[i] = [s]
    patched = [x for x in open(patched)]
    original = [x for x in open(original)]
    source = open(source).read().strip().split("\n")
    with safeout(outsink, encoding="UTF-8") as write:
        for i, sent in enumerate(source):
            sent = sent.split("(")
            write(u"****************************************\n%s %s\n\n"%(sent[0].strip().decode("utf-8"), sent[1].strip().decode("utf-8")))
            tags0 = original[i]
            tags1 = patched[i]
            write("Tagged and segmented by Fahad: %s\n"%(tags0.strip()))
            if not tags1 == tags0:
                write("Retagged & segmented by Allan: %s\n\n"%(tags1.strip()))
            for s in segments[i+1]:
                write(s)
