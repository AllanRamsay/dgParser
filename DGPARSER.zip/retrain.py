import re, sys, os
from useful import *
from classes import *

def extractmistakes(training):
    return training+[s for s in training if not s.goldstandard = s.parsed]
