tagged('an Italian became the world APOS greatest tenor .', ['an', ['Italian', 'NN', ''], ['become', 'VV', 'ed'], 'the', ['world', 'NN', ''], 'APOS', ['greatest', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('was there an Italian who became the world APOS greatest tenor ?', ['was', 'there', 'an', ['Italian', 'NN', ''], 'who', ['become', 'VV', 'ed'], 'the', ['world', 'NN', ''], 'APOS', ['greatest', 'AJ', ''], ['tenor', 'NN', ''], '?']).
tagged('there was an Italian who became the world APOS greatest tenor .', ['there', 'was', 'an', ['Italian', 'NN', ''], 'who', ['become', 'VV', 'ed'], 'the', ['world', 'NN', ''], 'APOS', ['greatest', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('every Italian man wants to be a great tenor .', ['every', ['Italian', 'AJ', ''], ['man', 'NN', ''], ['want', 'VV', 's'], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('some Italian mans are great tenors .', ['some', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], '.']).
tagged('are there Italian mans who want to be a great tenor ?', ['are', 'there', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '?']).
tagged('there are Italian mans who want to be a great tenor .', ['there', 'are', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('all Italian mans want to be a great tenor .', ['all', ['Italian', 'AJ', ''], ['man', 'NN', 's'], ['want', 'VV', ''], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('some Italian mans are great tenors .', ['some', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], '.']).
tagged('are there Italian mans who want to be a great tenor ?', ['are', 'there', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '?']).
tagged('there are Italian mans who want to be a great tenor .', ['there', 'are', ['Italian', 'AJ', ''], ['man', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', 'a', ['great', 'AJ', ''], ['tenor', 'NN', ''], '.']).
tagged('each Italian tenor wants to be great .', ['each', ['Italian', 'AJ', ''], ['tenor', 'NN', ''], ['want', 'VV', 's'], 'to', 'be', ['great', 'AJ', ''], '.']).
tagged('some Italian tenors are great .', ['some', ['Italian', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['great', 'AJ', ''], '.']).
tagged('are there Italian tenors who want to be great ?', ['are', 'there', ['Italian', 'AJ', ''], ['tenor', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', ['great', 'AJ', ''], '?']).
tagged('there are Italian tenors who want to be great .', ['there', 'are', ['Italian', 'AJ', ''], ['tenor', 'NN', 's'], 'who', ['want', 'VV', ''], 'to', 'be', ['great', 'AJ', ''], '.']).
tagged('the really ambitious tenors are Italian .', ['the', ['really', 'AV', ''], ['ambitious', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['Italian', 'AJ', ''], '.']).
tagged('are there really ambitious tenors who are Italian ?', ['are', 'there', ['really', 'AV', ''], ['ambitious', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Italian', 'AJ', ''], '?']).
tagged('there are really ambitious tenors who are Italian .', ['there', 'are', ['really', 'AV', ''], ['ambitious', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Italian', 'AJ', ''], '.']).
tagged('no really great tenors are modest .', ['no', ['really', 'AV', ''], ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['modest', 'AJ', ''], '.']).
tagged('are there really great tenors who are modest ?', ['are', 'there', ['really', 'AV', ''], ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['modest', 'AJ', ''], '?']).
tagged('there are really great tenors who are modest .', ['there', 'are', ['really', 'AV', ''], ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['modest', 'AJ', ''], '.']).
tagged('some great tenors are Swedish .', ['some', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['Swedish', 'AJ', ''], '.']).
tagged('are there great tenors who are Swedish ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Swedish', 'AJ', ''], '?']).
tagged('there are great tenors who are Swedish .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Swedish', 'AJ', ''], '.']).
tagged('many great tenors are German .', ['many', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', 'German', '.']).
tagged('are there great tenors who are German ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', 'German', '?']).
tagged('there are great tenors who are German .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', 'German', '.']).
tagged('several great tenors are British .', ['several', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', 'British', '.']).
tagged('are there great tenors who are British ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', 'British', '?']).
tagged('there are great tenors who are British .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', 'British', '.']).
tagged('most great tenors are Italian .', [['most', 'AV', ''], ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['Italian', 'AJ', ''], '.']).
tagged('are there great tenors who are Italian ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Italian', 'AJ', ''], '?']).
tagged('there are great tenors who are Italian .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['Italian', 'AJ', ''], '.']).
tagged('a few great tenors sing popular music .', ['a', 'few', ['great', 'AJ', ''], ['tenor', 'NN', 's'], ['sing', 'VV', ''], ['popular', 'AJ', ''], ['music', 'NN', ''], '.']).
tagged('some great tenors like popular music .', ['some', ['great', 'AJ', ''], ['tenor', 'NN', 's'], ['like', 'PRP'], ['popular', 'AJ', ''], ['music', 'NN', ''], '.']).
tagged('are there great tenors who sing popular music ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', ['sing', 'VV', ''], ['popular', 'AJ', ''], ['music', 'NN', ''], '?']).
tagged('there are great tenors who sing popular music .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', ['sing', 'VV', ''], ['popular', 'AJ', ''], ['music', 'NN', ''], '.']).
tagged('few great tenors are poor .', ['few', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['poor', 'AJ', ''], '.']).
tagged('are there great tenors who are poor ?', ['are', 'there', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['poor', 'AJ', ''], '?']).
tagged('there are great tenors who are poor .', ['there', 'are', ['great', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['poor', 'AJ', ''], '.']).
tagged('both leading tenors are excellent .', [['both', 'AV', ''], ['leading', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['excellent', 'AJ', ''], '.']).
tagged('leading tenors who are excellent are indispensable .', [['leading', 'AJ', ''], ['tenor', 'NN', 's'], 'who', 'are', ['excellent', 'AJ', ''], 'are', ['indispensable', 'AJ', ''], '.']).
tagged('are both leading tenors indispensable ?', ['are', ['both', 'AV', ''], ['leading', 'AJ', ''], ['tenor', 'NN', 's'], ['indispensable', 'AJ', ''], '?']).
tagged('both leading tenors are indispensable .', [['both', 'AV', ''], ['leading', 'AJ', ''], ['tenor', 'NN', 's'], 'are', ['indispensable', 'AJ', ''], '.']).
tagged('neither leading tenor comes cheap .', [['neither', 'AV', ''], ['leading', 'AJ', ''], ['tenor', 'NN', ''], ['come', 'VV', 's'], ['cheap', 'AJ', ''], '.']).
tagged('one of the leading tenors is Pavarotti .', ['one', 'of', 'the', ['leading', 'AJ', ''], ['tenor', 'NN', 's'], 'is', ['Pavarotti', 'NN', ''], '.']).
tagged('Is Pavarotti a leading tenor who comes cheap ?', ['Is', 'Pavarotti', 'a', ['leading', 'AJ', ''], ['tenor', 'NN', ''], 'who', ['come', 'VV', 's'], ['cheap', 'AJ', ''], '?']).
tagged('Pavarotti is a leading tenor who comes cheap .', [['Pavarotti', 'NN', ''], 'is', 'a', ['leading', 'AJ', ''], ['tenor', 'NN', ''], 'who', ['come', 'VV', 's'], ['cheap', 'AJ', ''], '.']).
tagged('at least three tenors will take part in the concert .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['tenor', 'NN', 's'], 'will', ['take', 'VV', ''], ['part', 'NN', ''], ['in', 'PRP'], 'the', ['concert', 'NN', ''], '.']).
tagged('are there tenors who will take part in the concert ?', ['are', 'there', ['tenor', 'NN', 's'], 'who', 'will', ['take', 'VV', ''], ['part', 'NN', ''], ['in', 'PRP'], 'the', ['concert', 'NN', ''], '?']).
tagged('there are tenors who will take part in the concert .', ['there', 'are', ['tenor', 'NN', 's'], 'who', 'will', ['take', 'VV', ''], ['part', 'NN', ''], ['in', 'PRP'], 'the', ['concert', 'NN', ''], '.']).
tagged('at most two tenors will contribute their fees to charity .', [['at', 'PRP'], ['most', 'AV', ''], ['two', 'CRD'], ['tenor', 'NN', 's'], 'will', ['contribute', 'VV', ''], 'their', ['fee', 'NN', 's'], 'to', ['charity', 'NN', ''], '.']).
tagged('are there tenors who will contribute their fees to charity ?', ['are', 'there', ['tenor', 'NN', 's'], 'who', 'will', ['contribute', 'VV', ''], 'their', ['fee', 'NN', 's'], 'to', ['charity', 'NN', ''], '?']).
tagged('there are tenors who will contribute their fees to charity .', ['there', 'are', ['tenor', 'NN', 's'], 'who', 'will', ['contribute', 'VV', ''], 'their', ['fee', 'NN', 's'], 'to', ['charity', 'NN', ''], '.']).
tagged('an Irishman won the nobel prize for literature .', ['an', ['Irishman', 'NN', ''], ['win', 'VV', 'ed'], 'the', ['nobel', 'NN', ''], ['prize', 'NN', ''], ['for', 'PRP'], ['literature', 'NN', ''], '.']).
tagged('did an Irishman win a nobel prize ?', ['did', 'an', ['Irishman', 'NN', ''], ['win', 'VV', ''], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '?']).
tagged('an Irishman won a nobel prize .', ['an', ['Irishman', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('every European has the right to live in Europe .', ['every', 'European', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('Can every European travel freely within Europe ?', [['Can', 'VV', ''], 'every', 'European', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('every European can travel freely within Europe .', ['every', 'European', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all Europeans have the right to live in Europe .', ['all', 'Europeans', 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can all Europeans travel freely within Europe ?', ['can', 'all', 'Europeans', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('all Europeans can travel freely within Europe .', ['all', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('each European has the right to live in Europe .', ['each', 'European', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can each European travel freely within Europe ?', ['can', 'each', 'European', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('each European can travel freely within Europe .', ['each', 'European', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('the residents of member states have the right to live in Europe .', ['the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('all residents of member states are individuals .', ['all', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'are', ['individual', 'NN', 's'], '.']).
tagged('every individual who has the right to live in Europe can travel freely within Europe .', ['every', ['individual', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can the residents of member states travel freely within Europe ?', ['can', 'the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('the residents of member states can travel freely within Europe .', ['the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('no delegate finished the report on time .', ['no', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did no delegate finish the report ?', ['did', 'no', ['delegate', 'NN', ''], ['finish', 'VV', ''], 'the', ['report', 'NN', ''], '?']).
tagged('no delegate finished the report .', ['no', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], '.']).
tagged('some delegates finished the survey on time .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did some delegates finish the survey ?', ['did', 'some', ['delegate', 'NN', 's'], ['finish', 'VV', ''], 'the', ['survey', 'NN', ''], '?']).
tagged('some delegates finished the survey .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], '.']).
tagged('many delegates obtained interesting results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('did many delegates obtain results from the survey ?', ['did', 'many', ['delegate', 'NN', 's'], ['obtain', 'VV', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '?']).
tagged('many delegates obtained results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('several delegates got the results published in major national newspapers .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('did several delegates get the results published ?', ['did', 'several', ['delegate', 'NN', 's'], ['get', 'VV', ''], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], '?']).
tagged('several delegates got the results published .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], '.']).
tagged('most Europeans are resident in Europe .', ['most', 'Europeans', 'are', ['resident', 'AJ', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('all Europeans are people .', ['all', 'Europeans', 'are', ['people', 'NN', ''], '.']).
tagged('all people who are resident in Europe can travel freely within Europe .', ['all', ['people', 'NN', ''], 'who', 'are', ['resident', 'AJ', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can most Europeans travel freely within Europe ?', ['can', ['most', 'AV', ''], 'Europeans', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('most Europeans can travel freely within Europe .', ['most', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('a few committee members are from Sweden .', ['a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Sweden', '.']).
tagged('all committee members are people .', ['all', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['people', 'NN', ''], '.']).
tagged('all people who are from Sweden are from Scandinavia .', ['all', ['people', 'NN', ''], 'who', 'are', ['from', 'PRP'], 'Sweden', 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('are at least a few committee members from Scandinavia ?', ['are', ['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Scandinavia', '?']).
tagged('at least a few committee members are from Scandinavia .', [['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('few committee members are from Portugal .', ['few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Portugal', '.']).
tagged('all committee members are people .', ['all', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['people', 'NN', ''], '.']).
tagged('all people who are from Portugal are from southern Europe .', ['all', ['people', 'NN', ''], 'who', 'are', ['from', 'PRP'], 'Portugal', 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('are there few committee members from southern Europe ?', ['are', 'there', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '?']).
tagged('there are few committee members from southern Europe .', ['there', 'are', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('both commissioners used to be leading businessmen .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['leading', 'AJ', ''], ['businessmen', 'NN', ''], '.']).
tagged('did both commissioners used to be businessmen ?', ['did', 'both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['businessmen', 'NN', ''], '?']).
tagged('both commissioners used to be businessmen .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['businessmen', 'NN', ''], '.']).
tagged('neither commissioner spends a lot of time at home .', ['neither', ['commissioner', 'NN', ''], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('does neither commissioner spend time at home ?', ['does', 'neither', ['commissioner', 'NN', ''], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('neither commissioner spends time at home .', ['neither', ['commissioner', 'NN', ''], ['spend', 'VV', 's'], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at least three commissioners spend a lot of time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at least three commissioners spend time at home ?', ['do', ['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at least three commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at most ten commissioners spend a lot of time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at most ten commissioners spend time at home ?', ['do', ['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at most ten commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('an Irishman won a nobel prize .', ['an', ['Irishman', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('did an Irishman win the nobel prize for literature ?', ['did', 'an', ['Irishman', 'NN', ''], ['win', 'VV', ''], 'the', ['nobel', 'NN', ''], ['prize', 'NN', ''], ['for', 'PRP'], ['literature', 'NN', ''], '?']).
tagged('an Irishman won the nobel prize for literature .', ['an', ['Irishman', 'NN', ''], ['win', 'VV', 'ed'], 'the', ['nobel', 'NN', ''], ['prize', 'NN', ''], ['for', 'PRP'], ['literature', 'NN', ''], '.']).
tagged('every European can travel freely within Europe .', ['every', 'European', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('does every European have the right to live in Europe ?', ['does', 'every', 'European', 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('every European has the right to live in Europe .', ['every', 'European', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('all Europeans can travel freely within Europe .', ['all', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('do all Europeans have the right to live in Europe ?', ['do', 'all', 'Europeans', 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('all Europeans have the right to live in Europe .', ['all', 'Europeans', 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('each European can travel freely within Europe .', ['each', 'European', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every European is a person .', ['every', 'European', 'is', 'a', ['person', 'NN', ''], '.']).
tagged('every person who has the right to live in Europe can travel freely within Europe .', ['every', ['person', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('does each European have the right to live in Europe ?', ['does', ['each', 'AV', ''], 'European', 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('each European has the right to live in Europe .', ['each', 'European', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('the residents of member states can travel freely within Europe .', ['the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all residents of member states are individuals .', ['all', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'are', ['individual', 'NN', 's'], '.']).
tagged('every individual who has the right to live anywhere in Europe can travel freely within Europe .', ['every', ['individual', 'NN', ''], 'who', 'has', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['anywhere', 'AV', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('do the residents of member states have the right to live anywhere in Europe ?', ['do', 'the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['anywhere', 'AV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('the residents of member states have the right to live anywhere in Europe .', ['the', ['resident', 'NN', 's'], 'of', ['member', 'NN', ''], ['state', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['anywhere', 'AV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('no delegate finished the report .', ['no', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], '.']).
tagged('did any delegate finish the report on time ?', ['did', 'any', ['delegate', 'NN', ''], ['finish', 'VV', ''], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some delegate finished the report on time .', ['some', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('some delegates finished the survey .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], '.']).
tagged('did some delegates finish the survey on time ?', ['did', 'some', ['delegate', 'NN', 's'], ['finish', 'VV', ''], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some delegates finished the survey on time .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('many delegates obtained results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('did many delegates obtain interesting results from the survey ?', ['did', 'many', ['delegate', 'NN', 's'], ['obtain', 'VV', ''], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '?']).
tagged('many delegates obtained interesting results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('several delegates got the results published .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], '.']).
tagged('did several delegates get the results published in major national newspapers ?', ['did', 'several', ['delegate', 'NN', 's'], ['get', 'VV', ''], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '?']).
tagged('several delegates got the results published in major national newspapers .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('most Europeans can travel freely within Europe .', ['most', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all Europeans are people .', ['all', 'Europeans', 'are', ['people', 'NN', ''], '.']).
tagged('all people who are resident in Europe can travel freely within Europe .', ['all', ['people', 'NN', ''], 'who', 'are', ['resident', 'AJ', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('are most Europeans resident in Europe ?', ['are', 'most', 'Europeans', ['resident', 'NN', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('most Europeans are resident in Europe .', ['most', 'Europeans', 'are', ['resident', 'AJ', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('a few committee members are from Scandinavia .', ['a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('all committee members are people .', ['all', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['people', 'NN', ''], '.']).
tagged('all people who are from Sweden are from Scandinavia .', ['all', ['people', 'NN', ''], 'who', 'are', ['from', 'PRP'], 'Sweden', 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('are at least a few committee members from Sweden ?', ['are', ['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Sweden', '?']).
tagged('at least a few committee members are from Sweden .', [['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Sweden', '.']).
tagged('few committee members are from southern Europe .', ['few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('all committee members are people .', ['all', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['people', 'NN', ''], '.']).
tagged('all people who are from Portugal are from southern Europe .', ['all', ['people', 'NN', ''], 'who', 'are', ['from', 'PRP'], 'Portugal', 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('are there few committee members from Portugal ?', ['are', 'there', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Portugal', '?']).
tagged('there are few committee members from Portugal .', ['there', 'are', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Portugal', '.']).
tagged('both commissioners used to be businessmen .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['businessmen', 'NN', ''], '.']).
tagged('did both commissioners used to be leading businessmen ?', ['did', 'both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['leading', 'AJ', ''], ['businessmen', 'NN', ''], '?']).
tagged('both commissioners used to be leading businessmen .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['leading', 'AJ', ''], ['businessmen', 'NN', ''], '.']).
tagged('neither commissioner spends time at home .', ['neither', ['commissioner', 'NN', ''], ['spend', 'VV', 's'], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('does either commissioner spend a lot of time at home ?', ['does', 'either', ['commissioner', 'NN', ''], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('one of the commissioners spends a lot of time at home .', ['one', 'of', 'the', ['commissioner', 'NN', 's'], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at least three commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at least three commissioners spend a lot of time at home ?', ['do', ['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at least three commissioners spend a lot of time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at most ten commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at most ten commissioners spend a lot of time at home ?', ['do', ['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at most ten commissioners spend a lot of time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('a Swede won a nobel prize .', ['a', ['Swede', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('every Swede is a Scandinavian .', ['every', ['Swede', 'NN', ''], 'is', 'a', ['Scandinavian', 'NN', ''], '.']).
tagged('did a Scandinavian win a nobel prize ?', ['did', 'a', ['Scandinavian', 'NN', ''], ['win', 'NN', ''], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '?']).
tagged('a Scandinavian won a nobel prize .', ['a', ['Scandinavian', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('every canadian resident can travel freely within Europe .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can every resident of the north American continent travel freely within Europe ?', ['can', 'every', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('every resident of the north American continent can travel freely within Europe .', ['every', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all canadian residents can travel freely within Europe .', ['all', ['canadian', 'AJ', ''], ['resident', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can all residents of the north American continent travel freely within Europe ?', ['can', 'all', ['resident', 'NN', 's'], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('all residents of the north American continent can travel freely within Europe .', ['all', ['resident', 'NN', 's'], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('each canadian resident can travel freely within Europe .', ['each', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can each resident of the north American continent travel freely within Europe ?', ['can', 'each', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('each resident of the north American continent can travel freely within Europe .', ['each', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('the residents of major western countries can travel freely within Europe .', ['the', ['resident', 'NN', 's'], 'of', ['major', 'AJ', ''], ['western', 'AJ', ''], ['country', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all residents of major western countries are residents of western countries .', ['all', ['resident', 'NN', 's'], 'of', ['major', 'AJ', ''], ['western', 'AJ', ''], ['country', 'NN', 's'], 'are', ['resident', 'NN', 's'], 'of', ['western', 'AJ', ''], ['country', 'NN', 's'], '.']).
tagged('do the residents of western countries have the right to live in Europe ?', ['do', 'the', ['resident', 'NN', 's'], 'of', ['western', 'AJ', ''], ['country', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('the residents of western countries have the right to live in Europe .', ['the', ['resident', 'NN', 's'], 'of', ['western', 'AJ', ''], ['country', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('no Scandinavian delegate finished the report on time .', ['no', ['Scandinavian', 'AJ', ''], ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did any delegate finish the report on time ?', ['did', 'any', ['delegate', 'NN', ''], ['finish', 'VV', ''], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some delegate finished the report on time .', ['some', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('some Irish delegates finished the survey on time .', ['some', 'Irish', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did any delegates finish the survey on time ?', ['did', 'any', ['delegate', 'NN', 's'], ['finish', 'VV', ''], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some delegates finished the survey on time .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('many British delegates obtained interesting results from the survey .', ['many', 'British', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('did many delegates obtain interesting results from the survey ?', ['did', 'many', ['delegate', 'NN', 's'], ['obtain', 'VV', ''], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '?']).
tagged('many delegates obtained interesting results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('several Portuguese delegates got the results published in major national newspapers .', ['several', ['Portuguese', 'AJ', ''], ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('did several delegates get the results published in major national newspapers ?', ['did', 'several', ['delegate', 'NN', 's'], ['get', 'VV', ''], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '?']).
tagged('several delegates got the results published in major national newspapers .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('most Europeans who are resident in Europe can travel freely within Europe .', ['most', 'Europeans', 'who', 'are', ['resident', 'AJ', ''], ['in', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can most Europeans travel freely within Europe ?', ['can', ['most', 'AV', ''], 'Europeans', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('most Europeans can travel freely within Europe .', ['most', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('a few female committee members are from Scandinavia .', ['a', 'few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('are at least a few committee members from Scandinavia ?', ['are', ['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Scandinavia', '?']).
tagged('at least a few committee members are from Scandinavia .', [['at', 'PRP'], 'least', 'a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('few female committee members are from southern Europe .', ['few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('are few committee members from southern Europe ?', ['are', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '?']).
tagged('few committee members are from southern Europe .', ['few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('both female commissioners used to be in business .', ['both', ['female', 'AJ', ''], ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '.']).
tagged('did both commissioners used to be in business ?', ['did', 'both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '?']).
tagged('both commissioners used to be in business .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '.']).
tagged('neither female commissioner spends a lot of time at home .', ['neither', ['female', 'AJ', ''], ['commissioner', 'NN', ''], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('does either commissioner spend a lot of time at home ?', ['does', 'either', ['commissioner', 'NN', ''], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('one of the commissioners spends a lot of time at home .', ['one', 'of', 'the', ['commissioner', 'NN', 's'], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at least three female commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['female', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at least three commissioners spend time at home ?', ['do', ['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at least three commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at most ten female commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['female', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at most ten commissioners spend time at home ?', ['do', ['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at most ten commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('a Scandinavian won a nobel prize .', ['a', ['Scandinavian', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('every Swede is a Scandinavian .', ['every', ['Swede', 'NN', ''], 'is', 'a', ['Scandinavian', 'NN', ''], '.']).
tagged('did a Swede win a nobel prize ?', ['did', 'a', ['Swede', 'NN', ''], ['win', 'VV', ''], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '?']).
tagged('a Swede won a nobel prize .', ['a', ['Swede', 'NN', ''], ['win', 'VV', 'ed'], 'a', ['nobel', 'NN', ''], ['prize', 'NN', ''], '.']).
tagged('every resident of the north American continent can travel freely within Europe .', ['every', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can every canadian resident travel freely within Europe ?', ['can', 'every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('every canadian resident can travel freely within Europe .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all residents of the north American continent can travel freely within Europe .', ['all', ['resident', 'NN', 's'], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can all canadian residents travel freely within Europe ?', ['can', 'all', ['canadian', 'AJ', ''], ['resident', 'NN', 's'], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('all canadian residents can travel freely within Europe .', ['all', ['canadian', 'AJ', ''], ['resident', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('each resident of the north American continent can travel freely within Europe .', ['each', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('every canadian resident is a resident of the north American continent .', ['every', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'is', 'a', ['resident', 'NN', ''], 'of', 'the', ['north', 'NN', ''], 'American', ['continent', 'NN', ''], '.']).
tagged('can each canadian resident travel freely within Europe ?', ['can', 'each', ['canadian', 'AJ', ''], ['resident', 'NN', ''], ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('each canadian resident can travel freely within Europe .', ['each', ['canadian', 'AJ', ''], ['resident', 'NN', ''], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('the residents of western countries can travel freely within Europe .', ['the', ['resident', 'NN', 's'], 'of', ['western', 'AJ', ''], ['country', 'NN', 's'], 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('all residents of major western countries are residents of western countries .', ['all', ['resident', 'NN', 's'], 'of', ['major', 'AJ', ''], ['western', 'AJ', ''], ['country', 'NN', 's'], 'are', ['resident', 'NN', 's'], 'of', ['western', 'AJ', ''], ['country', 'NN', 's'], '.']).
tagged('do the residents of major western countries have the right to live in Europe ?', ['do', 'the', ['resident', 'NN', 's'], 'of', ['major', 'AJ', ''], ['western', 'AJ', ''], ['country', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '?']).
tagged('the residents of major western countries have the right to live in Europe .', ['the', ['resident', 'NN', 's'], 'of', ['major', 'AJ', ''], ['western', 'AJ', ''], ['country', 'NN', 's'], 'have', 'the', ['right', 'NN', ''], 'to', ['live', 'VV', ''], ['in', 'PRP'], 'Europe', '.']).
tagged('no delegate finished the report on time .', ['no', ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did any Scandinavian delegate finish the report on time ?', ['did', 'any', ['Scandinavian', 'AJ', ''], ['delegate', 'NN', ''], ['finish', 'VV', ''], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some Scandinavian delegate finished the report on time .', ['some', ['Scandinavian', 'AJ', ''], ['delegate', 'NN', ''], ['finish', 'VV', 'ed'], 'the', ['report', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('some delegates finished the survey on time .', ['some', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('did any Irish delegates finish the survey on time ?', ['did', 'any', 'Irish', ['delegate', 'NN', 's'], ['finish', 'VV', ''], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '?']).
tagged('some Irish delegates finished the survey on time .', ['some', 'Irish', ['delegate', 'NN', 's'], ['finish', 'VV', 'ed'], 'the', ['survey', 'NN', ''], ['on', 'PRP'], ['time', 'NN', ''], '.']).
tagged('many delegates obtained interesting results from the survey .', ['many', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('did many British delegates obtain interesting results from the survey ?', ['did', 'many', 'British', ['delegate', 'NN', 's'], ['obtain', 'VV', ''], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '?']).
tagged('many British delegates obtained interesting results from the survey .', ['many', 'British', ['delegate', 'NN', 's'], ['obtain', 'VV', 'ed'], ['interesting', 'AJ', ''], ['result', 'NN', 's'], ['from', 'PRP'], 'the', ['survey', 'NN', ''], '.']).
tagged('several delegates got the results published in major national newspapers .', ['several', ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('did several Portuguese delegates get the results published in major national newspapers ?', ['did', 'several', ['Portuguese', 'AJ', ''], ['delegate', 'NN', 's'], ['get', 'VV', ''], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '?']).
tagged('several Portuguese delegates got the results published in major national newspapers .', ['several', ['Portuguese', 'AJ', ''], ['delegate', 'NN', 's'], ['get', 'VV', 'ed'], 'the', ['result', 'NN', 's'], ['publish', 'VV', 'ed'], ['in', 'PRP'], ['major', 'AJ', ''], ['national', 'AJ', ''], ['newspaper', 'NN', 's'], '.']).
tagged('most Europeans can travel freely within Europe .', ['most', 'Europeans', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('can most Europeans who are resident outside Europe travel freely within Europe ?', ['can', ['most', 'AV', ''], 'Europeans', 'who', 'are', ['resident', 'AJ', ''], ['outside', 'PRP'], 'Europe', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '?']).
tagged('most Europeans who are resident outside Europe can travel freely within Europe .', ['most', 'Europeans', 'who', 'are', ['resident', 'AJ', ''], ['outside', 'PRP'], 'Europe', 'can', ['travel', 'VV', ''], ['freely', 'AV', ''], ['within', 'PRP'], 'Europe', '.']).
tagged('a few committee members are from Scandinavia .', ['a', 'few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('are at least a few female committee members from Scandinavia ?', ['are', ['at', 'PRP'], 'least', 'a', 'few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], 'Scandinavia', '?']).
tagged('at least a few female committee members are from Scandinavia .', [['at', 'PRP'], 'least', 'a', 'few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], 'Scandinavia', '.']).
tagged('few committee members are from southern Europe .', ['few', ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('are few female committee members from southern Europe ?', ['are', 'few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '?']).
tagged('few female committee members are from southern Europe .', ['few', ['female', 'AJ', ''], ['committee', 'NN', ''], ['member', 'NN', 's'], 'are', ['from', 'PRP'], ['southern', 'AJ', ''], 'Europe', '.']).
tagged('both commissioners used to be in business .', ['both', ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '.']).
tagged('did both female commissioners used to be in business ?', ['did', 'both', ['female', 'AJ', ''], ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '?']).
tagged('both female commissioners used to be in business .', ['both', ['female', 'AJ', ''], ['commissioner', 'NN', 's'], ['use', 'VV', 'ed'], 'to', 'be', ['in', 'PRP'], ['business', 'NN', ''], '.']).
tagged('neither commissioner spends a lot of time at home .', ['neither', ['commissioner', 'NN', ''], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('does either female commissioner spend a lot of time at home ?', ['does', 'either', ['female', 'AJ', ''], ['commissioner', 'NN', ''], ['spend', 'VV', ''], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('one of the female commissioners spends a lot of time at home .', ['one', 'of', 'the', ['female', 'AJ', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', 's'], 'a', ['lot', 'NN', ''], 'of', ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at least three commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at least three male commissioners spend time at home ?', ['do', ['at', 'PRP'], 'least', ['three', 'CRD'], ['male', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at least three male commissioners spend time at home .', [['at', 'PRP'], 'least', ['three', 'CRD'], ['male', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('at most ten commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('do at most ten female commissioners spend time at home ?', ['do', ['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['female', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '?']).
tagged('at most ten female commissioners spend time at home .', [['at', 'PRP'], ['most', 'AV', ''], ['ten', 'CRD'], ['female', 'NN', ''], ['commissioner', 'NN', 's'], ['spend', 'VV', ''], ['time', 'NN', ''], ['at', 'PRP'], ['home', 'NN', ''], '.']).
tagged('Smith, Jones and Anderson signed the contract .', [['Smith,', 'NN', ''], 'Jones', 'and', 'Anderson', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('did Jones sign the contract ?', ['did', 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Jones signed the contract .', ['Jones', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Smith, Jones and several lawyers signed the contract .', [['Smith,', 'NN', ''], 'Jones', 'and', 'several', ['lawyer', 'NN', 's'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('did Jones sign the contract ?', ['did', 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Jones signed the contract .', ['Jones', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('either Smith, Jones or Anderson signed the contract .', ['either', ['Smith,', 'NN', ''], 'Jones', 'or', 'Anderson', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('did Jones sign the contract ?', ['did', 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Jones signed the contract .', ['Jones', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('either Smith, Jones or Anderson signed the contract .', ['either', ['Smith,', 'NN', ''], 'Jones', 'or', 'Anderson', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('if Smith and Anderson did not sign the contract, did Jones sign the contract ?', ['if', 'Smith', 'and', 'Anderson', 'did', 'not', ['sign', 'VV', ''], 'the', ['contract,', 'NN', ''], 'did', 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('if Smith and Anderson did not sign the contract, Jones signed the contract .', ['if', 'Smith', 'and', 'Anderson', 'did', 'not', ['sign', 'VV', ''], 'the', ['contract,', 'NN', ''], 'Jones', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('exactly two lawyers and three accountants signed the contract .', [['exactly', 'AV', ''], ['two', 'CRD'], ['lawyer', 'NN', 's'], 'and', ['three', 'CRD'], ['accountant', 'NN', 's'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('did six lawyers sign the contract ?', ['did', ['six', 'CRD'], ['lawyer', 'NN', 's'], ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('six lawyers signed the contract .', [['six', 'CRD'], ['lawyer', 'NN', 's'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('exactly two lawyers and three accountants signed the contract .', [['exactly', 'AV', ''], ['two', 'CRD'], ['lawyer', 'NN', 's'], 'and', ['three', 'CRD'], ['accountant', 'NN', 's'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('did six accountants sign the contract ?', ['did', ['six', 'CRD'], ['accountant', 'NN', 's'], ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('six accountants signed the contract .', [['six', 'CRD'], ['accountant', 'NN', 's'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('every representative and client was at the meeting .', ['every', ['representative', 'NN', ''], 'and', ['client', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('was every representative at the meeting ?', ['was', 'every', ['representative', 'NN', ''], ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '?']).
tagged('every representative was at the meeting .', ['every', ['representative', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('every representative and client was at the meeting .', ['every', ['representative', 'NN', ''], 'and', ['client', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('was every representative at the meeting ?', ['was', 'every', ['representative', 'NN', ''], ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '?']).
tagged('every representative was at the meeting .', ['every', ['representative', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('every representative or client was at the meeting .', ['every', ['representative', 'NN', ''], 'or', ['client', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('was every representative and every client at the meeting ?', ['was', 'every', ['representative', 'NN', ''], 'and', 'every', ['client', 'NN', ''], ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '?']).
tagged('every representative and every client was at the meeting .', ['every', ['representative', 'NN', ''], 'and', 'every', ['client', 'NN', ''], 'was', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('the chairman read out the items on the agenda .', ['the', ['chairman', 'NN', ''], ['read', 'VV', ''], ['out', 'PRP'], 'the', ['item', 'NN', 's'], ['on', 'PRP'], 'the', ['agenda', 'NN', ''], '.']).
tagged('did the chairman read out every item on the agenda ?', ['did', 'the', ['chairman', 'NN', ''], ['read', 'VV', ''], ['out', 'PRP'], 'every', ['item', 'NN', ''], ['on', 'PRP'], 'the', ['agenda', 'NN', ''], '?']).
tagged('the chairman read out every item on the agenda .', ['the', ['chairman', 'NN', ''], ['read', 'VV', ''], ['out', 'PRP'], 'every', ['item', 'NN', ''], ['on', 'PRP'], 'the', ['agenda', 'NN', ''], '.']).
tagged('the people who were at the meeting voted for a new chairman .', ['the', ['people', 'NN', ''], 'who', 'were', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('did every one at the meeting vote for a new chairman ?', ['did', 'every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'NN', ''], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '?']).
tagged('every one at the meeting voted for a new chairman .', ['every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('all the people who were at the meeting voted for a new chairman .', ['all', 'the', ['people', 'NN', ''], 'who', 'were', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('did every one at the meeting vote for a new chairman ?', ['did', 'every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'NN', ''], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '?']).
tagged('every one at the meeting voted for a new chairman .', ['every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('the people who were at the meeting all voted for a new chairman .', ['the', ['people', 'NN', ''], 'who', 'were', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], 'all', ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('did every one at the meeting vote for a new chairman ?', ['did', 'every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'NN', ''], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '?']).
tagged('every one at the meeting voted for a new chairman .', ['every', 'one', ['at', 'PRP'], 'the', ['meeting', 'NN', ''], ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', ['new', 'AJ', ''], ['chairman', 'NN', ''], '.']).
tagged('the inhabitants of Cambridge voted for a Labour MP .', ['the', ['inhabitant', 'NN', 's'], 'of', 'Cambridge', ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', 'Labour', 'MP', '.']).
tagged('did every inhabitant of Cambridge vote for a Labour MP ?', ['did', 'every', ['inhabitant', 'NN', ''], 'of', 'Cambridge', ['vote', 'NN', ''], ['for', 'PRP'], 'a', 'Labour', 'MP', '?']).
tagged('every inhabitant of Cambridge voted for a Labour MP .', ['every', ['inhabitant', 'NN', ''], 'of', 'Cambridge', ['vote', 'VV', 'ed'], ['for', 'PRP'], 'a', 'Labour', 'MP', '.']).
tagged('the Ancient Greeks were noted philosophers .', ['the', ['Ancient', 'NN', ''], ['Greeks', 'NN', ''], 'were', ['note', 'VV', 'ed'], ['philosopher', 'NN', 's'], '.']).
tagged('was every Ancient Greek a noted philosopher ?', ['was', 'every', ['Ancient', 'NN', ''], ['Greek', 'VV', ''], 'a', ['noted', 'AJ', ''], ['philosopher', 'NN', ''], '?']).
tagged('every Ancient Greek was a noted philosopher .', ['every', ['Ancient', 'NN', ''], ['Greek', 'NN', ''], 'was', 'a', ['noted', 'AJ', ''], ['philosopher', 'NN', ''], '.']).
tagged('the Ancient Greeks were all noted philosophers .', ['the', ['Ancient', 'NN', ''], ['Greeks', 'NN', ''], 'were', 'all', ['noted', 'AJ', ''], ['philosopher', 'NN', 's'], '.']).
tagged('was every Ancient Greek a noted philosopher ?', ['was', 'every', ['Ancient', 'NN', ''], ['Greek', 'VV', ''], 'a', ['noted', 'AJ', ''], ['philosopher', 'NN', ''], '?']).
tagged('every Ancient Greek was a noted philosopher .', ['every', ['Ancient', 'NN', ''], ['Greek', 'NN', ''], 'was', 'a', ['noted', 'AJ', ''], ['philosopher', 'NN', ''], '.']).
tagged('software faults were blamed for the system failure .', [['software', 'NN', ''], ['fault', 'NN', 's'], 'were', ['blame', 'VV', 'ed'], ['for', 'PRP'], 'the', ['system', 'NN', ''], ['failure', 'NN', ''], '.']).
tagged('was the system failure blamed on one or more software faults ?', ['was', 'the', ['system', 'NN', ''], ['failure', 'NN', ''], ['blame', 'VV', 'ed'], ['on', 'PRP'], 'one', 'or', 'more', ['software', 'NN', ''], ['fault', 'NN', 's'], '?']).
tagged('the system failure was blamed on one or more software faults .', ['the', ['system', 'NN', ''], ['failure', 'NN', ''], 'was', ['blame', 'VV', 'ed'], ['on', 'PRP'], 'one', 'or', 'more', ['software', 'NN', ''], ['fault', 'NN', 's'], '.']).
tagged('software faults were blamed for the system failure .', [['software', 'NN', ''], ['fault', 'NN', 's'], 'were', ['blame', 'VV', 'ed'], ['for', 'PRP'], 'the', ['system', 'NN', ''], ['failure', 'NN', ''], '.']).
tagged('Bug # 32-985 is a known software fault .', [['Bug', 'NN', ''], ['#', 'NN', ''], ['32-985', 'CRD'], 'is', 'a', ['known', 'AJ', ''], ['software', 'NN', ''], ['fault', 'NN', ''], '.']).
tagged('was Bug # 32-985 blamed for the system failure ?', ['was', ['Bug', 'NN', ''], ['#', 'NN', ''], ['32-985', 'CRD'], ['blame', 'VV', 'ed'], ['for', 'PRP'], 'the', ['system', 'NN', ''], ['failure', 'NN', ''], '?']).
tagged('Bug # 32-985 was blamed for the system failure .', [['Bug', 'NN', ''], ['#', 'NN', ''], ['32-985', 'CRD'], 'was', ['blame', 'VV', 'ed'], ['for', 'PRP'], 'the', ['system', 'NN', ''], ['failure', 'NN', ''], '.']).
tagged('clients at the demonstration were all impressed by the system APOS performance .', [['client', 'NN', 's'], ['at', 'PRP'], 'the', ['demonstration', 'NN', ''], 'were', 'all', ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '.']).
tagged('Smith was a client at the demonstration .', ['Smith', 'was', 'a', ['client', 'NN', ''], ['at', 'PRP'], 'the', ['demonstration', 'NN', ''], '.']).
tagged('was Smith impressed by the system APOS performance ?', ['was', 'Smith', ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '?']).
tagged('Smith was impressed by the system APOS performance .', ['Smith', 'was', ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '.']).
tagged('clients at the demonstration were impressed by the system APOS performance .', [['client', 'NN', 's'], ['at', 'PRP'], 'the', ['demonstration', 'NN', ''], 'were', ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '.']).
tagged('were most clients at the demonstration impressed by the system APOS performance ?', ['were', 'most', ['client', 'NN', 's'], ['at', 'PRP'], 'the', ['demonstration', 'NN', ''], ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '?']).
tagged('most clients at the demonstration were impressed by the system APOS performance .', ['most', ['client', 'NN', 's'], ['at', 'PRP'], 'the', ['demonstration', 'NN', ''], 'were', ['impress', 'VV', 'ed'], ['by', 'PRP'], 'the', ['system', 'NN', ''], 'APOS', ['performance', 'NN', ''], '.']).
tagged('University graduates make poor stock-market traders .', ['University', ['graduate', 'NN', 's'], ['make', 'VV', ''], ['poor', 'AJ', ''], ['stock-market', 'NN', ''], ['trader', 'NN', 's'], '.']).
tagged('Smith is a university graduate .', ['Smith', 'is', 'a', ['university', 'NN', ''], ['graduate', 'NN', ''], '.']).
tagged('is Smith likely to make a poor stock market trader ?', ['is', 'Smith', ['likely', 'AJ', ''], 'to', ['make', 'VV', ''], 'a', ['poor', 'AJ', ''], ['stock', 'NN', ''], ['market', 'NN', ''], ['trader', 'NN', ''], '?']).
tagged('Smith is likely to make a poor stock market trader .', ['Smith', 'is', ['likely', 'AJ', ''], 'to', ['make', 'VV', ''], 'a', ['poor', 'AJ', ''], ['stock', 'NN', ''], ['market', 'NN', ''], ['trader', 'NN', ''], '.']).
tagged('University graduates make poor stock-market traders .', ['University', ['graduate', 'NN', 's'], ['make', 'VV', ''], ['poor', 'AJ', ''], ['stock-market', 'NN', ''], ['trader', 'NN', 's'], '.']).
tagged('Smith is a university graduate .', ['Smith', 'is', 'a', ['university', 'NN', ''], ['graduate', 'NN', ''], '.']).
tagged('Will Smith make a poor stock market trader ?', ['Will', 'Smith', ['make', 'VV', ''], 'a', ['poor', 'AJ', ''], ['stock', 'NN', ''], ['market', 'NN', ''], ['trader', 'NN', ''], '?']).
tagged('Smith will make a poor stock market trader .', ['Smith', 'will', ['make', 'VV', ''], 'a', ['poor', 'AJ', ''], ['stock', 'NN', ''], ['market', 'NN', ''], ['trader', 'NN', ''], '.']).
tagged('all APCOM managers have company cars .', ['all', ['APCOM', 'PRP'], ['manager', 'NN', 's'], 'have', ['company', 'NN', ''], ['car', 'NN', 's'], '.']).
tagged('Jones is an APCOM manager .', ['Jones', 'is', 'an', 'APCOM', ['manager', 'NN', ''], '.']).
tagged('does Jones have a company car ?', ['does', 'Jones', 'have', 'a', ['company', 'NN', ''], ['car', 'NN', ''], '?']).
tagged('Jones has a company car .', ['Jones', 'has', 'a', ['company', 'NN', ''], ['car', 'NN', ''], '.']).
tagged('all APCOM managers have company cars .', ['all', ['APCOM', 'PRP'], ['manager', 'NN', 's'], 'have', ['company', 'NN', ''], ['car', 'NN', 's'], '.']).
tagged('Jones is an APCOM manager .', ['Jones', 'is', 'an', 'APCOM', ['manager', 'NN', ''], '.']).
tagged('does Jones have more than one company car ?', ['does', 'Jones', 'have', ['more', 'AV', ''], 'than', 'one', ['company', 'NN', ''], ['car', 'NN', ''], '?']).
tagged('Jones has more than one company car .', ['Jones', 'has', ['more', 'AV', ''], 'than', 'one', ['company', 'NN', ''], ['car', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did no accountants attend the meeting ?', ['did', 'no', ['accountant', 'NN', 's'], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('no accountants attended the meeting .', ['no', ['accountant', 'NN', 's'], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did no accountant attend the meeting ?', ['did', 'no', ['accountant', 'NN', ''], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('no accountant attended the meeting .', ['no', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did any accountants attend the meeting ?', ['did', 'any', ['accountant', 'NN', 's'], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('some accountants attended the meeting .', ['some', ['accountant', 'NN', 's'], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did any accountant attend the meeting ?', ['did', 'any', ['accountant', 'NN', ''], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('some accountant attended the meeting .', ['some', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did some accountants attend the meeting ?', ['did', 'some', ['accountant', 'NN', 's'], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('some accountants attended the meeting .', ['some', ['accountant', 'NN', 's'], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Just one accountant attended the meeting .', [['Just', 'AV', ''], 'one', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did some accountant attend the meeting ?', ['did', 'some', ['accountant', 'NN', ''], ['attend', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('some accountant attended the meeting .', ['some', ['accountant', 'NN', ''], ['attend', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Smith signed one contract .', ['Smith', ['sign', 'VV', 'ed'], 'one', ['contract', 'NN', ''], '.']).
tagged('Jones signed another contract .', ['Jones', ['sign', 'VV', 'ed'], 'another', ['contract', 'NN', ''], '.']).
tagged('did Smith and Jones sign two contracts ?', ['did', 'Smith', 'and', 'Jones', ['sign', 'NN', ''], ['two', 'CRD'], ['contract', 'NN', 's'], '?']).
tagged('Smith and Jones signed two contracts .', ['Smith', 'and', 'Jones', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('Smith signed two contracts .', ['Smith', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('Jones signed two contracts .', ['Jones', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('did Smith and Jones sign two contracts ?', ['did', 'Smith', 'and', 'Jones', ['sign', 'NN', ''], ['two', 'CRD'], ['contract', 'NN', 's'], '?']).
tagged('Smith and Jones signed two contracts .', ['Smith', 'and', 'Jones', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('Smith signed two contracts .', ['Smith', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('Jones also signed them .', ['Jones', ['also', 'AV', ''], ['sign', 'VV', 'ed'], 'them', '.']).
tagged('did Smith and Jones sign two contracts ?', ['did', 'Smith', 'and', 'Jones', ['sign', 'NN', ''], ['two', 'CRD'], ['contract', 'NN', 's'], '?']).
tagged('Smith and Jones signed two contracts .', ['Smith', 'and', 'Jones', ['sign', 'VV', 'ed'], ['two', 'CRD'], ['contract', 'NN', 's'], '.']).
tagged('Mary used her workstation .', ['Mary', ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('was Mary APOS workstation used ?', ['was', 'Mary', 'APOS', ['workstation', 'NN', ''], ['use', 'VV', 'ed'], '?']).
tagged('Mary APOS workstation was used .', ['Mary', 'APOS', ['workstation', 'NN', ''], 'was', ['use', 'VV', 'ed'], '.']).
tagged('Mary used her workstation .', ['Mary', ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('does Mary have a workstation ?', ['does', 'Mary', 'have', 'a', ['workstation', 'NN', ''], '?']).
tagged('Mary has a workstation .', ['Mary', 'has', 'a', ['workstation', 'NN', ''], '.']).
tagged('Mary used her workstation .', ['Mary', ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('is Mary female ?', ['is', 'Mary', ['female', 'NN', ''], '?']).
tagged('Mary is female .', ['Mary', 'is', ['female', 'AJ', ''], '.']).
tagged('every student used her workstation .', ['every', ['student', 'NN', ''], ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('Mary is a student .', ['Mary', 'is', 'a', ['student', 'NN', ''], '.']).
tagged('did Mary use her workstation ?', ['did', 'Mary', ['use', 'VV', ''], 'her', ['workstation', 'NN', ''], '?']).
tagged('Mary used her workstation .', ['Mary', ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('every student used her workstation .', ['every', ['student', 'NN', ''], ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('Mary is a student .', ['Mary', 'is', 'a', ['student', 'NN', ''], '.']).
tagged('does Mary have a workstation ?', ['does', 'Mary', 'have', 'a', ['workstation', 'NN', ''], '?']).
tagged('Mary has a workstation .', ['Mary', 'has', 'a', ['workstation', 'NN', ''], '.']).
tagged('no student used her workstation .', ['no', ['student', 'NN', ''], ['use', 'VV', 'ed'], 'her', ['workstation', 'NN', ''], '.']).
tagged('Mary is a student .', ['Mary', 'is', 'a', ['student', 'NN', ''], '.']).
tagged('did Mary use a workstation ?', ['did', 'Mary', ['use', 'VV', ''], 'a', ['workstation', 'NN', ''], '?']).
tagged('Mary used a workstation .', ['Mary', ['use', 'VV', 'ed'], 'a', ['workstation', 'NN', ''], '.']).
tagged('Smith attended a meeting .', ['Smith', ['attend', 'VV', 'ed'], 'a', ['meeting', 'NN', ''], '.']).
tagged('she chaired it .', ['she', ['chair', 'VV', 'ed'], 'it', '.']).
tagged('did Smith chair a meeting ?', ['did', 'Smith', ['chair', 'NN', ''], 'a', ['meeting', 'NN', ''], '?']).
tagged('Smith chaired a meeting .', ['Smith', ['chair', 'VV', 'ed'], 'a', ['meeting', 'NN', ''], '.']).
tagged('Smith delivered a report to ITEL .', ['Smith', ['deliver', 'VV', 'ed'], 'a', ['report', 'NN', ''], 'to', 'ITEL', '.']).
tagged('she also delivered them an invoice .', ['she', ['also', 'AV', ''], ['deliver', 'VV', 'ed'], 'them', 'an', ['invoice', 'NN', ''], '.']).
tagged('and she delivered them a project proposal .', ['and', 'she', ['deliver', 'VV', 'ed'], 'them', 'a', ['project', 'NN', ''], ['proposal', 'NN', ''], '.']).
tagged('did Smith deliver a report, an invoice and a project proposal to ITEL ?', ['did', 'Smith', ['deliver', 'VV', ''], 'a', ['report,', 'NN', ''], 'an', ['invoice', 'NN', ''], 'and', 'a', ['project', 'NN', ''], ['proposal', 'NN', ''], 'to', 'ITEL', '?']).
tagged('Smith delivered a report, an invoice and a project proposal to ITEL .', ['Smith', ['deliver', 'VV', 'ed'], 'a', ['report,', 'NN', ''], 'an', ['invoice', 'NN', ''], 'and', 'a', ['project', 'NN', ''], ['proposal', 'NN', ''], 'to', 'ITEL', '.']).
tagged('every committee has a chairman .', ['every', ['committee', 'NN', ''], 'has', 'a', ['chairman', 'NN', ''], '.']).
tagged('he is appointed its members .', ['he', 'is', ['appoint', 'VV', 'ed'], 'its', ['member', 'NN', 's'], '.']).
tagged('does every committee have a chairman appointed by members of the committee ?', ['does', 'every', ['committee', 'NN', ''], 'have', 'a', ['chairman', 'NN', ''], ['appoint', 'VV', 'ed'], ['by', 'PRP'], ['member', 'NN', 's'], 'of', 'the', ['committee', 'NN', ''], '?']).
tagged('every committee has a chairman appointed by members of the committee .', ['every', ['committee', 'NN', ''], 'has', 'a', ['chairman', 'NN', ''], ['appoint', 'VV', 'ed'], ['by', 'PRP'], ['member', 'NN', 's'], 'of', 'the', ['committee', 'NN', ''], '.']).
tagged('ITEL has sent most of the reports Smith needs .', ['ITEL', 'has', ['send', 'VV', ''], 'most', 'of', 'the', ['report', 'NN', 's'], 'Smith', ['need', 'NN', 's'], '.']).
tagged('they are on her desk .', ['they', 'are', ['on', 'PRP'], 'her', ['desk', 'NN', ''], '.']).
tagged('are there some reports from ITEL on Smith APOS desk ?', ['are', 'there', 'some', ['report', 'NN', 's'], ['from', 'PRP'], 'ITEL', ['on', 'PRP'], 'Smith', 'APOS', ['desk', 'NN', ''], '?']).
tagged('there are some reports from ITEL on Smith APOS desk .', ['there', 'are', 'some', ['report', 'NN', 's'], ['from', 'PRP'], 'ITEL', ['on', 'PRP'], 'Smith', 'APOS', ['desk', 'NN', ''], '.']).
tagged('two out of ten machines are missing .', [['two', 'CRD'], ['out', 'PRP'], 'of', ['ten', 'CRD'], ['machine', 'NN', 's'], 'are', ['miss', 'VV', 'ed'], '.']).
tagged('they have been removed .', ['they', 'have', 'been', ['remove', 'VV', 'ed'], '.']).
tagged('Have two machines been removed ?', [['Have', 'VV', ''], ['two', 'CRD'], ['machine', 'NN', 's'], 'been', ['remove', 'VV', 'ed'], '?']).
tagged('two machines have been removed .', [['two', 'CRD'], ['machine', 'NN', 's'], 'have', 'been', ['remove', 'VV', 'ed'], '.']).
tagged('two out of ten machines are missing .', [['two', 'CRD'], ['out', 'PRP'], 'of', ['ten', 'CRD'], ['machine', 'NN', 's'], 'are', ['miss', 'VV', 'ed'], '.']).
tagged('they have been removed .', ['they', 'have', 'been', ['remove', 'VV', 'ed'], '.']).
tagged('Have eight machines been removed ?', [['Have', 'VV', ''], ['eight', 'CRD'], ['machine', 'NN', 's'], 'been', ['remove', 'VV', 'ed'], '?']).
tagged('Eight machines have been removed .', [['Eight', 'NN', ''], ['machine', 'NN', 's'], 'have', 'been', ['remove', 'VV', 'ed'], '.']).
tagged('two out of ten machines are missing .', [['two', 'CRD'], ['out', 'PRP'], 'of', ['ten', 'CRD'], ['machine', 'NN', 's'], 'are', ['miss', 'VV', 'ed'], '.']).
tagged('they were all here yesterday .', ['they', 'were', 'all', ['here', 'AV', ''], ['yesterday', 'AV', ''], '.']).
tagged('were ten machines here yesterday ?', ['were', ['ten', 'CRD'], ['machine', 'NN', 's'], ['here', 'AV', ''], ['yesterday', 'AV', ''], '?']).
tagged('Ten machines were here yesterday .', [['Ten', 'NN', ''], ['machine', 'NN', 's'], 'were', ['here', 'AV', ''], ['yesterday', 'AV', ''], '.']).
tagged('Smith took a machine on Tuesday, and Jones took a machine on Wednesday .', ['Smith', ['take', 'VV', 'ed1'], 'a', ['machine', 'NN', ''], ['on', 'PRP'], ['Tuesday,', 'NN', ''], 'and', 'Jones', ['take', 'VV', 'ed1'], 'a', ['machine', 'NN', ''], ['on', 'PRP'], 'Wednesday', '.']).
tagged('they put them in the lobby .', ['they', ['put', 'VV', ''], 'them', ['in', 'PRP'], 'the', ['lobby', 'NN', ''], '.']).
tagged('did Smith and Jones put two machines in the lobby ?', ['did', 'Smith', 'and', 'Jones', ['put', 'VV', ''], ['two', 'CRD'], ['machine', 'NN', 's'], ['in', 'PRP'], 'the', ['lobby', 'NN', ''], '?']).
tagged('Smith and Jones put two machines in the lobby .', ['Smith', 'and', 'Jones', ['put', 'VV', ''], ['two', 'CRD'], ['machine', 'NN', 's'], ['in', 'PRP'], 'the', ['lobby', 'NN', ''], '.']).
tagged('John and his colleagues went to a meeting .', ['John', 'and', 'his', ['colleague', 'NN', 's'], ['go', 'VV', 'ed'], 'to', 'a', ['meeting', 'NN', ''], '.']).
tagged('they hated it .', ['they', ['hate', 'VV', 'ed'], 'it', '.']).
tagged('did John APOS colleagues hate the meeting ?', ['did', 'John', 'APOS', ['colleague', 'NN', 's'], ['hate', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('John APOS colleagues hated the meeting .', ['John', 'APOS', ['colleague', 'NN', 's'], ['hate', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('John and his colleagues went to a meeting .', ['John', 'and', 'his', ['colleague', 'NN', 's'], ['go', 'VV', 'ed'], 'to', 'a', ['meeting', 'NN', ''], '.']).
tagged('they hated it .', ['they', ['hate', 'VV', 'ed'], 'it', '.']).
tagged('did John hate the meeting ?', ['did', 'John', ['hate', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('John hated the meeting .', ['John', ['hate', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('John and his colleagues went to a meeting .', ['John', 'and', 'his', ['colleague', 'NN', 's'], ['go', 'VV', 'ed'], 'to', 'a', ['meeting', 'NN', ''], '.']).
tagged('they hated it .', ['they', ['hate', 'VV', 'ed'], 'it', '.']).
tagged('did John hate the meeting ?', ['did', 'John', ['hate', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('John hated the meeting .', ['John', ['hate', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('each department has a dedicated line .', ['each', ['department', 'NN', ''], 'has', 'a', ['dedicated', 'AJ', ''], ['line', 'NN', ''], '.']).
tagged('they rent them from BT .', ['they', ['rent', 'VV', ''], 'them', ['from', 'PRP'], 'BT', '.']).
tagged('does every department rent a line from BT ?', ['does', 'every', ['department', 'NN', ''], ['rent', 'VV', ''], 'a', ['line', 'NN', ''], ['from', 'PRP'], 'BT', '?']).
tagged('every department rents a line from BT .', ['every', ['department', 'NN', ''], ['rent', 'NN', 's'], 'a', ['line', 'NN', ''], ['from', 'PRP'], 'BT', '.']).
tagged('each department has a dedicated line .', ['each', ['department', 'NN', ''], 'has', 'a', ['dedicated', 'AJ', ''], ['line', 'NN', ''], '.']).
tagged('the sales department rents it from BT .', ['the', ['sales', 'NN', ''], ['department', 'NN', ''], ['rent', 'NN', 's'], 'it', ['from', 'PRP'], 'BT', '.']).
tagged('does the sales department rent a line from BT ?', ['does', 'the', ['sales', 'NN', ''], ['department', 'NN', ''], ['rent', 'VV', ''], 'a', ['line', 'NN', ''], ['from', 'PRP'], 'BT', '?']).
tagged('the sales department rents a line from BT .', ['the', ['sales', 'NN', ''], ['department', 'NN', ''], ['rent', 'NN', 's'], 'a', ['line', 'NN', ''], ['from', 'PRP'], 'BT', '.']).
tagged('GFI owns several computers .', [['GFI', 'NN', ''], ['own', 'VV', 's'], 'several', ['computer', 'NN', 's'], '.']).
tagged('ITEL maintains them .', ['ITEL', ['maintain', 'VV', 's'], 'them', '.']).
tagged('does ITEL maintain all the computers that GFI owns ?', ['does', 'ITEL', ['maintain', 'VV', ''], 'all', 'the', ['computer', 'NN', 's'], 'that', ['GFI', 'NN', ''], ['own', 'VV', 's'], '?']).
tagged('ITEL maintains all the computers that GFI owns .', ['ITEL', ['maintain', 'VV', 's'], 'all', 'the', ['computer', 'NN', 's'], 'that', ['GFI', 'NN', ''], ['own', 'VV', 's'], '.']).
tagged('every customer who owns a computer has a service contract for it .', ['every', ['customer', 'NN', ''], 'who', ['own', 'VV', 's'], 'a', ['computer', 'NN', ''], 'has', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'it', '.']).
tagged('MFI is a customer that owns exactly one computer .', [['MFI', 'NN', ''], 'is', 'a', ['customer', 'NN', ''], 'that', ['own', 'VV', 's'], ['exactly', 'AV', ''], 'one', ['computer', 'NN', ''], '.']).
tagged('does MFI have a service contract for all its computers ?', ['does', ['MFI', 'NN', ''], 'have', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'all', 'its', ['computer', 'NN', 's'], '?']).
tagged('MFI has a service contract for all its computers .', [['MFI', 'NN', ''], 'has', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'all', 'its', ['computer', 'NN', 's'], '.']).
tagged('every customer who owns a computer has a service contract for it .', ['every', ['customer', 'NN', ''], 'who', ['own', 'VV', 's'], 'a', ['computer', 'NN', ''], 'has', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'it', '.']).
tagged('MFI is a customer that owns several computers .', [['MFI', 'NN', ''], 'is', 'a', ['customer', 'NN', ''], 'that', ['own', 'VV', 's'], 'several', ['computer', 'NN', 's'], '.']).
tagged('does MFI have a service contract for all its computers ?', ['does', ['MFI', 'NN', ''], 'have', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'all', 'its', ['computer', 'NN', 's'], '?']).
tagged('MFI has a service contract for all its computers .', [['MFI', 'NN', ''], 'has', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'all', 'its', ['computer', 'NN', 's'], '.']).
tagged('every executive who had a laptop computer brought it to take notes at the meeting .', ['every', ['executive', 'NN', ''], 'who', 'had', 'a', ['laptop', 'NN', ''], ['computer', 'NN', ''], ['bring', 'VV', 'ed1'], 'it', 'to', ['take', 'VV', ''], ['note', 'NN', 's'], ['at', 'PRP'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Smith is a executive who owns five different laptop computers .', ['Smith', 'is', 'a', ['executive', 'NN', ''], 'who', ['own', 'VV', 's'], ['five', 'CRD'], ['different', 'AJ', ''], ['laptop', 'NN', ''], ['computer', 'NN', 's'], '.']).
tagged('did Smith take five laptop computers to the meeting ?', ['did', 'Smith', ['take', 'VV', ''], ['five', 'CRD'], ['laptop', 'NN', ''], ['computer', 'NN', 's'], 'to', 'the', ['meeting', 'NN', ''], '?']).
tagged('Smith took five laptop computers to the meeting .', ['Smith', ['take', 'VV', 'ed1'], ['five', 'CRD'], ['laptop', 'NN', ''], ['computer', 'NN', 's'], 'to', 'the', ['meeting', 'NN', ''], '.']).
tagged('there are 100 companies .', ['there', 'are', ['100', 'CRD'], ['company', 'NN', 's'], '.']).
tagged('ICM is one of the companies and owns 150 computers .', [['ICM', 'NN', ''], 'is', 'one', 'of', 'the', ['company', 'NN', 's'], 'and', ['own', 'VV', 's'], ['150', 'CRD'], ['computer', 'NN', 's'], '.']).
tagged('it does not have service contracts for any of its computers .', ['it', 'does', 'not', 'have', ['service', 'NN', ''], ['contract', 'NN', 's'], ['for', 'PRP'], 'any', 'of', 'its', ['computer', 'NN', 's'], '.']).
tagged('each of the other 99 companies owns one computer .', ['each', 'of', 'the', ['other', 'AJ', ''], ['99', 'CRD'], ['company', 'NN', 's'], ['own', 'VV', 's'], 'one', ['computer', 'NN', ''], '.']).
tagged('they have service contracts for them .', ['they', 'have', ['service', 'NN', ''], ['contract', 'NN', 's'], ['for', 'PRP'], 'them', '.']).
tagged('do most companies that own a computer have a service contract for it ?', ['do', 'most', ['company', 'NN', 's'], 'that', 'own', 'a', ['computer', 'NN', ''], 'have', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'it', '?']).
tagged('most companies that own a computer have a service contract for it .', ['most', ['company', 'NN', 's'], 'that', 'own', 'a', ['computer', 'NN', ''], 'have', 'a', ['service', 'NN', ''], ['contract', 'NN', ''], ['for', 'PRP'], 'it', '.']).
tagged('every report has a cover page .', ['every', ['report', 'NN', ''], 'has', 'a', ['cover', 'NN', ''], ['page', 'NN', ''], '.']).
tagged('R-95-103 is a report .', [['R-95-103', 'CRD'], 'is', 'a', ['report', 'NN', ''], '.']).
tagged('Smith signed the cover page .', ['Smith', ['sign', 'VV', 'ed'], 'the', ['cover', 'NN', ''], ['page', 'NN', ''], '.']).
tagged('did Smith sign the cover page of R-95-103 ?', ['did', 'Smith', ['sign', 'VV', ''], 'the', ['cover', 'NN', ''], ['page', 'NN', ''], 'of', ['R-95-103', 'CRD'], '?']).
tagged('Smith signed the cover page of R-95-103 .', ['Smith', ['sign', 'VV', 'ed'], 'the', ['cover', 'NN', ''], ['page', 'NN', ''], 'of', ['R-95-103', 'CRD'], '.']).
tagged('a company director awarded himself a large payrise .', ['a', ['company', 'NN', ''], ['director', 'NN', ''], ['award', 'VV', 'ed'], 'himself', 'a', ['large', 'AJ', ''], ['payrise', 'NN', ''], '.']).
tagged('has a company director awarded and been awarded a payrise ?', ['has', 'a', ['company', 'NN', ''], ['director', 'NN', ''], ['award', 'VV', 'ed'], 'and', 'been', ['award', 'VV', 'ed'], 'a', ['payrise', 'NN', ''], '?']).
tagged('a company director has awarded and been awarded a payrise .', ['a', ['company', 'NN', ''], ['director', 'NN', ''], 'has', ['award', 'VV', 'ed'], 'and', 'been', ['award', 'VV', 'ed'], 'a', ['payrise', 'NN', ''], '.']).
tagged('John said Bill had hurt himself .', ['John', ['say', 'VV', 'ed'], 'Bill', 'had', ['hurt', 'VV', ''], 'himself', '.']).
tagged('did John say Bill had been hurt ?', ['did', 'John', ['say', 'VV', ''], 'Bill', 'had', 'been', ['hurt', 'VV', ''], '?']).
tagged('John said Bill had been hurt .', ['John', ['say', 'VV', 'ed'], 'Bill', 'had', 'been', ['hurt', 'VV', ''], '.']).
tagged('John said Bill had hurt himself .', ['John', ['say', 'VV', 'ed'], 'Bill', 'had', ['hurt', 'VV', ''], 'himself', '.']).
tagged('did any one say John had been hurt ?', ['did', 'any', 'one', ['say', 'VV', ''], 'John', 'had', 'been', ['hurt', 'VV', ''], '?']).
tagged('some one said John had been hurt .', ['some', 'one', ['say', 'VV', 'ed'], 'John', 'had', 'been', ['hurt', 'VV', ''], '.']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('so did Bill .', ['so', 'did', 'Bill', '.']).
tagged('did Bill speak to Mary ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', '?']).
tagged('Bill spoke to Mary .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('so did Bill .', ['so', 'did', 'Bill', '.']).
tagged('John spoke to Mary at four o&apos;clock .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('did Bill speak to Mary at four o&apos;clock ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '?']).
tagged('Bill spoke to Mary at four o&apos;clock .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('John spoke to Mary at four o&apos;clock .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('so did Bill .', ['so', 'did', 'Bill', '.']).
tagged('did Bill speak to Mary at four o&apos;clock ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '?']).
tagged('Bill spoke to Mary at four o&apos;clock .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('John spoke to Mary at four o&apos;clock .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['four', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('and Bill did at five o&apos;clock .', ['and', 'Bill', 'did', ['at', 'PRP'], ['five', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('did Bill speak to Mary at five o&apos;clock ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', ['at', 'PRP'], ['five', 'CRD'], ['o&apos;clock', 'NN', ''], '?']).
tagged('Bill spoke to Mary at five o&apos;clock .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['at', 'PRP'], ['five', 'CRD'], ['o&apos;clock', 'NN', ''], '.']).
tagged('John has spoken to Mary .', ['John', 'has', ['speak', 'VV', 'ed'], 'to', 'Mary', '.']).
tagged('Bill is going to .', ['Bill', 'is', ['go', 'VV', 'ed'], 'to', '.']).
tagged('Will Bill speak to Mary ?', ['Will', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', '?']).
tagged('Bill will speak to Mary .', ['Bill', 'will', ['speak', 'VV', ''], 'to', 'Mary', '.']).
tagged('John spoke to Mary on Monday .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['on', 'PRP'], 'Monday', '.']).
tagged('Bill did not .', ['Bill', 'did', 'not', '.']).
tagged('did Bill speak to Mary on Monday ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', ['on', 'PRP'], 'Monday', '?']).
tagged('Bill spoke to Mary on Monday .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['on', 'PRP'], 'Monday', '.']).
tagged('has John spoken to Mary ?', ['has', 'John', ['speak', 'VV', 'ed'], 'to', 'Mary', '?']).
tagged('Bill has .', ['Bill', 'has', '.']).
tagged('has Bill spoken to Mary ?', ['has', 'Bill', ['speak', 'VV', 'ed'], 'to', 'Mary', '?']).
tagged('Bill has spoken to Mary .', ['Bill', 'has', ['speak', 'VV', 'ed'], 'to', 'Mary', '.']).
tagged('John has spoken to Mary .', ['John', 'has', ['speak', 'VV', 'ed'], 'to', 'Mary', '.']).
tagged('the students have too .', ['the', ['student', 'NN', 's'], 'have', ['too', 'AV', ''], '.']).
tagged('Have the students spoken to Mary ?', [['Have', 'VV', ''], 'the', ['student', 'NN', 's'], ['speak', 'VV', 'ed'], 'to', 'Mary', '?']).
tagged('the students have spoken to Mary .', ['the', ['student', 'NN', 's'], 'have', ['speak', 'VV', 'ed'], 'to', 'Mary', '.']).
tagged('John went to Paris by car, and Bill by train .', ['John', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['car,', 'NN', ''], 'and', 'Bill', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('did Bill go to Paris by train ?', ['did', 'Bill', ['go', 'VV', ''], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '?']).
tagged('Bill went to Paris by train .', ['Bill', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('John went to Paris by car, and Bill by train to Berlin .', ['John', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['car,', 'NN', ''], 'and', 'Bill', ['by', 'PRP'], ['train', 'NN', ''], 'to', 'Berlin', '.']).
tagged('did Bill go to Berlin by train ?', ['did', 'Bill', ['go', 'VV', ''], 'to', 'Berlin', ['by', 'PRP'], ['train', 'NN', ''], '?']).
tagged('Bill went to Berlin by train .', ['Bill', ['go', 'VV', 'ed'], 'to', 'Berlin', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('John went to Paris by car, and Bill to Berlin .', ['John', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['car,', 'NN', ''], 'and', 'Bill', 'to', 'Berlin', '.']).
tagged('did Bill go to Berlin by car ?', ['did', 'Bill', ['go', 'VV', ''], 'to', 'Berlin', ['by', 'PRP'], ['car', 'NN', ''], '?']).
tagged('Bill went to Berlin by car .', ['Bill', ['go', 'VV', 'ed'], 'to', 'Berlin', ['by', 'PRP'], ['car', 'NN', ''], '.']).
tagged('John is going to Paris by car, and the students by train .', ['John', 'is', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['car,', 'NN', ''], 'and', 'the', ['student', 'NN', 's'], ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('are the students going to Paris by train ?', ['are', 'the', ['student', 'NN', 's'], ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '?']).
tagged('the students are going to Paris by train .', ['the', ['student', 'NN', 's'], 'are', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('John went to Paris by car .', ['John', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['car', 'NN', ''], '.']).
tagged('Bill by train .', ['Bill', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('did Bill go to Paris by train ?', ['did', 'Bill', ['go', 'VV', ''], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '?']).
tagged('Bill went to Paris by train .', ['Bill', ['go', 'VV', 'ed'], 'to', 'Paris', ['by', 'PRP'], ['train', 'NN', ''], '.']).
tagged('John owns a car .', ['John', ['own', 'VV', 's'], 'a', ['car', 'NN', ''], '.']).
tagged('Bill owns one too .', ['Bill', ['own', 'VV', 's'], 'one', ['too', 'AV', ''], '.']).
tagged('does Bill own a car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['car', 'NN', ''], '?']).
tagged('Bill owns a car .', ['Bill', ['own', 'VV', 's'], 'a', ['car', 'NN', ''], '.']).
tagged('John owns a car .', ['John', ['own', 'VV', 's'], 'a', ['car', 'NN', ''], '.']).
tagged('Bill owns one too .', ['Bill', ['own', 'VV', 's'], 'one', ['too', 'AV', ''], '.']).
tagged('is there a car that John and Bill own ?', ['is', 'there', 'a', ['car', 'NN', ''], 'that', 'John', 'and', 'Bill', ['own', 'VV', ''], '?']).
tagged('there is a car that John and Bill own .', ['there', 'is', 'a', ['car', 'NN', ''], 'that', 'John', 'and', 'Bill', ['own', 'VV', ''], '.']).
tagged('John owns a red car .', ['John', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a blue one .', ['Bill', ['own', 'VV', 's'], 'a', ['blue', 'AJ', ''], 'one', '.']).
tagged('does Bill own a blue car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['blue', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a blue car .', ['Bill', ['own', 'VV', 's'], 'a', ['blue', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John owns a red car .', ['John', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a blue one .', ['Bill', ['own', 'VV', 's'], 'a', ['blue', 'AJ', ''], 'one', '.']).
tagged('does Bill own a red car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a red car .', ['Bill', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John owns a red car .', ['John', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a fast one .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], 'one', '.']).
tagged('does Bill own a fast car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['fast', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a fast car .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John owns a red car .', ['John', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a fast one .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], 'one', '.']).
tagged('does Bill own a fast red car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['fast', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a fast red car .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John owns a red car .', ['John', ['own', 'VV', 's'], 'a', ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a fast one .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], 'one', '.']).
tagged('does Bill own a fast red car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['fast', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a fast red car .', ['Bill', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John owns a fast red car .', ['John', ['own', 'VV', 's'], 'a', ['fast', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('Bill owns a slow one .', ['Bill', ['own', 'VV', 's'], 'a', ['slow', 'AJ', ''], 'one', '.']).
tagged('does Bill own a slow red car ?', ['does', 'Bill', ['own', 'VV', ''], 'a', ['slow', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '?']).
tagged('Bill owns a slow red car .', ['Bill', ['own', 'VV', 's'], 'a', ['slow', 'AJ', ''], ['red', 'AJ', ''], ['car', 'NN', ''], '.']).
tagged('John had his paper accepted .', ['John', 'had', 'his', ['paper', 'NN', ''], ['accept', 'VV', 'ed'], '.']).
tagged('Bill does not know why .', ['Bill', 'does', 'not', ['know', 'VV', ''], ['why', 'AV', ''], '.']).
tagged('does Bill know why John had his paper accepted ?', ['does', 'Bill', ['know', 'VV', ''], ['why', 'AV', ''], 'John', 'had', 'his', ['paper', 'NN', ''], ['accept', 'VV', 'ed'], '?']).
tagged('Bill knows why John had his paper accepted .', ['Bill', ['know', 'VV', 's'], ['why', 'AV', ''], 'John', 'had', 'his', ['paper', 'NN', ''], ['accept', 'VV', 'ed'], '.']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('and to Sue .', ['and', 'to', 'Sue', '.']).
tagged('did John speak to Sue ?', ['did', 'John', ['speak', 'VV', ''], 'to', 'Sue', '?']).
tagged('John spoke to Sue .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Sue', '.']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('On Friday .', [['On', 'PRP'], 'Friday', '.']).
tagged('did John speak to Mary on Friday ?', ['did', 'John', ['speak', 'VV', ''], 'to', 'Mary', ['on', 'PRP'], 'Friday', '?']).
tagged('John spoke to Mary on Friday .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['on', 'PRP'], 'Friday', '.']).
tagged('John spoke to Mary on Thursday .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['on', 'PRP'], 'Thursday', '.']).
tagged('and on Friday .', ['and', ['on', 'PRP'], 'Friday', '.']).
tagged('did John speak to Mary on Friday ?', ['did', 'John', ['speak', 'VV', ''], 'to', 'Mary', ['on', 'PRP'], 'Friday', '?']).
tagged('John spoke to Mary on Friday .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', ['on', 'PRP'], 'Friday', '.']).
tagged('Twenty mans work in the Sales Department .', [['Twenty', 'NN', ''], ['man', 'NN', 's'], ['work', 'NN', ''], ['in', 'PRP'], 'the', ['Sales', 'NN', ''], ['Department', 'NN', ''], '.']).
tagged('But only one woman .', ['But', ['only', 'AV', ''], 'one', ['woman', 'NN', ''], '.']).
tagged('do two women work in the Sales Department ?', ['do', ['two', 'CRD'], ['woman', 'NN', 's'], ['work', 'NN', ''], ['in', 'PRP'], 'the', ['Sales', 'NN', ''], ['Department', 'NN', ''], '?']).
tagged('two women work in the Sales Department .', [['two', 'CRD'], ['woman', 'NN', 's'], ['work', 'NN', ''], ['in', 'PRP'], 'the', ['Sales', 'NN', ''], ['Department', 'NN', ''], '.']).
tagged('Five mans work part time .', [['Five', 'AJ', ''], ['man', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '.']).
tagged('and forty five women .', ['and', ['forty', 'CRD'], ['five', 'CRD'], ['woman', 'NN', 's'], '.']).
tagged('do forty five women work part time ?', ['do', ['forty', 'CRD'], ['five', 'CRD'], ['woman', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '?']).
tagged('Forty five women work part time .', [['Forty', 'NN', ''], ['five', 'CRD'], ['woman', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '.']).
tagged('John found Mary before Bill .', ['John', ['found', 'VV', ''], 'Mary', ['before', 'PRP'], 'Bill', '.']).
tagged('did John find Mary before Bill found Mary ?', ['did', 'John', ['find', 'VV', ''], 'Mary', ['before', 'PRP'], 'Bill', ['found', 'VV', ''], 'Mary', '?']).
tagged('John found Mary before Bill found Mary .', ['John', ['found', 'VV', ''], 'Mary', ['before', 'PRP'], 'Bill', ['found', 'VV', ''], 'Mary', '.']).
tagged('John found Mary before Bill .', ['John', ['found', 'VV', ''], 'Mary', ['before', 'PRP'], 'Bill', '.']).
tagged('did John find Mary before John found Bill ?', ['did', 'John', ['find', 'VV', ''], 'Mary', ['before', 'PRP'], 'John', ['found', 'VV', ''], 'Bill', '?']).
tagged('John found Mary before John found Bill .', ['John', ['found', 'VV', ''], 'Mary', ['before', 'PRP'], 'John', ['found', 'VV', ''], 'Bill', '.']).
tagged('John wants to know how many mans work part time .', ['John', ['want', 'VV', 's'], 'to', ['know', 'VV', ''], 'how', 'many', ['man', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '.']).
tagged('and women .', ['and', ['woman', 'NN', 's'], '.']).
tagged('does John want to know how many women work part time ?', ['does', 'John', ['want', 'VV', ''], 'to', ['know', 'VV', ''], 'how', 'many', ['woman', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '?']).
tagged('John wants to know how many women work part time .', ['John', ['want', 'VV', 's'], 'to', ['know', 'VV', ''], 'how', 'many', ['woman', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '.']).
tagged('John wants to know how many mans work part time, and which .', ['John', ['want', 'VV', 's'], 'to', ['know', 'VV', ''], 'how', 'many', ['man', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time,', 'NN', ''], 'and', 'which', '.']).
tagged('does John want to know which mans work part time ?', ['does', 'John', ['want', 'VV', ''], 'to', ['know', 'VV', ''], 'which', ['man', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '?']).
tagged('John wants to know which mans work part time .', ['John', ['want', 'VV', 's'], 'to', ['know', 'VV', ''], 'which', ['man', 'NN', 's'], ['work', 'NN', ''], ['part', 'NN', ''], ['time', 'NN', ''], '.']).
tagged('Bill spoke to every one that John did .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'every', 'one', 'that', 'John', 'did', '.']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('did Bill speak to Mary ?', ['did', 'Bill', ['speak', 'VV', ''], 'to', 'Mary', '?']).
tagged('Bill spoke to Mary .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('Bill spoke to every one that John did .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'every', 'one', 'that', 'John', 'did', '.']).
tagged('Bill spoke to Mary .', ['Bill', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('did John speak to Mary ?', ['did', 'John', ['speak', 'VV', ''], 'to', 'Mary', '?']).
tagged('John spoke to Mary .', ['John', ['speak', 'VV', 'ed1'], 'to', 'Mary', '.']).
tagged('John said Mary wrote a report, and Bill did too .', ['John', ['say', 'VV', 'ed'], 'Mary', ['write', 'VV', 'ed'], 'a', ['report,', 'NN', ''], 'and', 'Bill', 'did', ['too', 'AV', ''], '.']).
tagged('did Bill say Mary wrote a report ?', ['did', 'Bill', ['say', 'VV', ''], 'Mary', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '?']).
tagged('Bill said Mary wrote a report .', ['Bill', ['say', 'VV', 'ed'], 'Mary', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('John said Mary wrote a report, and Bill did too .', ['John', ['say', 'VV', 'ed'], 'Mary', ['write', 'VV', 'ed'], 'a', ['report,', 'NN', ''], 'and', 'Bill', 'did', ['too', 'AV', ''], '.']).
tagged('did John say Bill wrote a report ?', ['did', 'John', ['say', 'VV', ''], 'Bill', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '?']).
tagged('John said Bill wrote a report .', ['John', ['say', 'VV', 'ed'], 'Bill', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('John said that Mary wrote a report, and that Bill did too .', ['John', ['say', 'VV', 'ed'], 'that', 'Mary', ['write', 'VV', 'ed'], 'a', ['report,', 'NN', ''], 'and', 'that', 'Bill', 'did', ['too', 'AV', ''], '.']).
tagged('did Bill say Mary wrote a report ?', ['did', 'Bill', ['say', 'VV', ''], 'Mary', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '?']).
tagged('Bill said Mary wrote a report .', ['Bill', ['say', 'VV', 'ed'], 'Mary', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('John wrote a report, and Bill said Peter did too .', ['John', ['write', 'VV', 'ed'], 'a', ['report,', 'NN', ''], 'and', 'Bill', ['say', 'VV', 'ed'], 'Peter', 'did', ['too', 'AV', ''], '.']).
tagged('did Bill say Peter wrote a report ?', ['did', 'Bill', ['say', 'VV', ''], 'Peter', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '?']).
tagged('Bill said Peter wrote a report .', ['Bill', ['say', 'VV', 'ed'], 'Peter', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('if John wrote a report, then Bill did too .', ['if', 'John', ['write', 'VV', 'ed'], 'a', ['report,', 'NN', ''], ['then', 'AV', ''], 'Bill', 'did', ['too', 'AV', ''], '.']).
tagged('John wrote a report .', ['John', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('did Bill write a report ?', ['did', 'Bill', ['write', 'VV', ''], 'a', ['report', 'NN', ''], '?']).
tagged('Bill wrote a report .', ['Bill', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('John wanted to buy a car, and he did .', ['John', ['want', 'VV', 'ed'], 'to', ['buy', 'VV', ''], 'a', ['car,', 'NN', ''], 'and', 'he', 'did', '.']).
tagged('did John buy a car ?', ['did', 'John', ['buy', 'VV', ''], 'a', ['car', 'NN', ''], '?']).
tagged('John bought a car .', ['John', ['buy', 'VV', 'ed1'], 'a', ['car', 'NN', ''], '.']).
tagged('John needed to buy a car, and Bill did .', ['John', ['need', 'VV', 'ed'], 'to', ['buy', 'VV', ''], 'a', ['car,', 'NN', ''], 'and', 'Bill', 'did', '.']).
tagged('did Bill buy a car ?', ['did', 'Bill', ['buy', 'VV', ''], 'a', ['car', 'NN', ''], '?']).
tagged('Bill bought a car .', ['Bill', ['buy', 'VV', 'ed1'], 'a', ['car', 'NN', ''], '.']).
tagged('Smith represents his company and so does Jones .', ['Smith', ['represent', 'VV', 's'], 'his', ['company', 'NN', ''], 'and', 'so', 'does', 'Jones', '.']).
tagged('does Jones represent Jones&apos; company ?', ['does', 'Jones', ['represent', 'VV', ''], ['Jones&apos;', 'NN', ''], ['company', 'NN', ''], '?']).
tagged('Jones represents Jones&apos; company .', ['Jones', ['represent', 'VV', 's'], ['Jones&apos;', 'NN', ''], ['company', 'NN', ''], '.']).
tagged('Smith represents his company and so does Jones .', ['Smith', ['represent', 'VV', 's'], 'his', ['company', 'NN', ''], 'and', 'so', 'does', 'Jones', '.']).
tagged('does Jones represent Smith APOS company ?', ['does', 'Jones', ['represent', 'VV', ''], 'Smith', 'APOS', ['company', 'NN', ''], '?']).
tagged('Jones represents Smith APOS company .', ['Jones', ['represent', 'VV', 's'], 'Smith', 'APOS', ['company', 'NN', ''], '.']).
tagged('Smith represents his company and so does Jones .', ['Smith', ['represent', 'VV', 's'], 'his', ['company', 'NN', ''], 'and', 'so', 'does', 'Jones', '.']).
tagged('does Smith represent Jones&apos; company ?', ['does', 'Smith', ['represent', 'VV', ''], ['Jones&apos;', 'NN', ''], ['company', 'NN', ''], '?']).
tagged('Smith represents Jones&apos; company .', ['Smith', ['represent', 'VV', 's'], ['Jones&apos;', 'NN', ''], ['company', 'NN', ''], '.']).
tagged('Smith claimed he had costed his proposal and so did Jones .', ['Smith', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'his', ['proposal', 'NN', ''], 'and', 'so', 'did', 'Jones', '.']).
tagged('did Jones claim he had costed his own proposal ?', ['did', 'Jones', ['claim', 'VV', ''], 'he', 'had', ['cost', 'VV', 'ed'], 'his', 'own', ['proposal', 'NN', ''], '?']).
tagged('Jones claimed he had costed his own proposal .', ['Jones', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'his', 'own', ['proposal', 'NN', ''], '.']).
tagged('Smith claimed he had costed his proposal and so did Jones .', ['Smith', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'his', ['proposal', 'NN', ''], 'and', 'so', 'did', 'Jones', '.']).
tagged('did Jones claim he had costed Smith APOS proposal ?', ['did', 'Jones', ['claim', 'VV', ''], 'he', 'had', ['cost', 'VV', 'ed'], 'Smith', 'APOS', ['proposal', 'NN', ''], '?']).
tagged('Jones claimed he had costed Smith APOS proposal .', ['Jones', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'Smith', 'APOS', ['proposal', 'NN', ''], '.']).
tagged('Smith claimed he had costed his proposal and so did Jones .', ['Smith', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'his', ['proposal', 'NN', ''], 'and', 'so', 'did', 'Jones', '.']).
tagged('did Jones claim Smith had costed Smith APOS proposal ?', ['did', 'Jones', ['claim', 'NN', ''], 'Smith', 'had', ['cost', 'VV', 'ed'], 'Smith', 'APOS', ['proposal', 'NN', ''], '?']).
tagged('Jones claimed Smith had costed Smith APOS proposal .', ['Jones', ['claim', 'VV', 'ed'], 'Smith', 'had', ['cost', 'VV', 'ed'], 'Smith', 'APOS', ['proposal', 'NN', ''], '.']).
tagged('Smith claimed he had costed his proposal and so did Jones .', ['Smith', ['claim', 'VV', 'ed'], 'he', 'had', ['cost', 'VV', 'ed'], 'his', ['proposal', 'NN', ''], 'and', 'so', 'did', 'Jones', '.']).
tagged('did Jones claim Smith had costed Jones&apos; proposal ?', ['did', 'Jones', ['claim', 'NN', ''], 'Smith', 'had', ['cost', 'VV', 'ed'], ['Jones&apos;', 'NN', ''], ['proposal', 'NN', ''], '?']).
tagged('Jones claimed Smith had costed Jones&apos; proposal .', ['Jones', ['claim', 'VV', 'ed'], 'Smith', 'had', ['cost', 'VV', 'ed'], ['Jones&apos;', 'NN', ''], ['proposal', 'NN', ''], '.']).
tagged('John is a man and Mary is a woman .', ['John', 'is', 'a', ['man', 'NN', ''], 'and', 'Mary', 'is', 'a', ['woman', 'NN', ''], '.']).
tagged('John represents his company and so does Mary .', ['John', ['represent', 'VV', 's'], 'his', ['company', 'NN', ''], 'and', 'so', 'does', 'Mary', '.']).
tagged('does Mary represent her own company ?', ['does', 'Mary', ['represent', 'VV', ''], 'her', 'own', ['company', 'NN', ''], '?']).
tagged('Mary represents her own company .', ['Mary', ['represent', 'VV', 's'], 'her', 'own', ['company', 'NN', ''], '.']).
tagged('John is a man and Mary is a woman .', ['John', 'is', 'a', ['man', 'NN', ''], 'and', 'Mary', 'is', 'a', ['woman', 'NN', ''], '.']).
tagged('John represents his company and so does Mary .', ['John', ['represent', 'VV', 's'], 'his', ['company', 'NN', ''], 'and', 'so', 'does', 'Mary', '.']).
tagged('does Mary represent John APOS company ?', ['does', 'Mary', ['represent', 'VV', ''], 'John', 'APOS', ['company', 'NN', ''], '?']).
tagged('Mary represents John APOS company .', ['Mary', ['represent', 'VV', 's'], 'John', 'APOS', ['company', 'NN', ''], '.']).
tagged('Bill suggested to Frank APOS boss that they should go to the meeting together, and Carl to Alan APOS wife .', ['Bill', ['suggest', 'VV', 'ed'], 'to', 'Frank', 'APOS', ['boss', 'NN', ''], 'that', 'they', 'should', ['go', 'VV', ''], 'to', 'the', ['meeting', 'NN', ''], ['together,', 'NN', ''], 'and', 'Carl', 'to', 'Alan', 'APOS', ['wife', 'NN', ''], '.']).
tagged('if it was suggested that Bill and Frank should go together, was it suggested that Carl and Alan should go together ?', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'was', 'it', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'should', ['go', 'VV', ''], ['together', 'AV', ''], '?']).
tagged('if it was suggested that Bill and Frank should go together, it was suggested that Carl and Alan should go together .', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'should', ['go', 'VV', ''], ['together', 'AV', ''], '.']).
tagged('Bill suggested to Frank APOS boss that they should go to the meeting together, and Carl to Alan APOS wife .', ['Bill', ['suggest', 'VV', 'ed'], 'to', 'Frank', 'APOS', ['boss', 'NN', ''], 'that', 'they', 'should', ['go', 'VV', ''], 'to', 'the', ['meeting', 'NN', ''], ['together,', 'NN', ''], 'and', 'Carl', 'to', 'Alan', 'APOS', ['wife', 'NN', ''], '.']).
tagged('if it was suggested that Bill and Frank should go together, was it suggested that Carl and Alan APOS wife should go together ?', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'was', 'it', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '?']).
tagged('if it was suggested that Bill and Frank should go together, it was suggested that Carl and Alan APOS wife should go together .', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '.']).
tagged('Bill suggested to Frank APOS boss that they should go to the meeting together, and Carl to Alan APOS wife .', ['Bill', ['suggest', 'VV', 'ed'], 'to', 'Frank', 'APOS', ['boss', 'NN', ''], 'that', 'they', 'should', ['go', 'VV', ''], 'to', 'the', ['meeting', 'NN', ''], ['together,', 'NN', ''], 'and', 'Carl', 'to', 'Alan', 'APOS', ['wife', 'NN', ''], '.']).
tagged('if it was suggested that Bill and Frank APOS boss should go together, was it suggested that Carl and Alan APOS wife should go together ?', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'was', 'it', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '?']).
tagged('if it was suggested that Bill and Frank APOS boss should go together, it was suggested that Carl and Alan APOS wife should go together .', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '.']).
tagged('Bill suggested to Frank APOS boss that they should go to the meeting together, and Carl to Alan APOS wife .', ['Bill', ['suggest', 'VV', 'ed'], 'to', 'Frank', 'APOS', ['boss', 'NN', ''], 'that', 'they', 'should', ['go', 'VV', ''], 'to', 'the', ['meeting', 'NN', ''], ['together,', 'NN', ''], 'and', 'Carl', 'to', 'Alan', 'APOS', ['wife', 'NN', ''], '.']).
tagged('if it was suggested that Bill and Frank APOS boss should go together, was it suggested that Carl and Alan should go together ?', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'was', 'it', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'should', ['go', 'VV', ''], ['together', 'AV', ''], '?']).
tagged('if it was suggested that Bill and Frank APOS boss should go together, it was suggested that Carl and Alan should go together .', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Bill', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'it', 'was', ['suggest', 'VV', 'ed'], 'that', 'Carl', 'and', 'Alan', 'should', ['go', 'VV', ''], ['together', 'AV', ''], '.']).
tagged('Bill suggested to Frank APOS boss that they should go to the meeting together, and Carl to Alan APOS wife .', ['Bill', ['suggest', 'VV', 'ed'], 'to', 'Frank', 'APOS', ['boss', 'NN', ''], 'that', 'they', 'should', ['go', 'VV', ''], 'to', 'the', ['meeting', 'NN', ''], ['together,', 'NN', ''], 'and', 'Carl', 'to', 'Alan', 'APOS', ['wife', 'NN', ''], '.']).
tagged('if it was suggested that Bill, Frank and Frank APOS boss should go together, was it suggested that Carl, Alan and Alan APOS wife should go together ?', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', ['Bill,', 'NN', ''], 'Frank', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'was', 'it', ['suggest', 'VV', 'ed'], 'that', ['Carl,', 'NN', ''], 'Alan', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '?']).
tagged('if it was suggested that Bill, Frank and Frank APOS boss should go together, it was suggested that Carl, Alan and Alan APOS wife should go together .', ['if', 'it', 'was', ['suggest', 'VV', 'ed'], 'that', ['Bill,', 'NN', ''], 'Frank', 'and', 'Frank', 'APOS', ['boss', 'NN', ''], 'should', ['go', 'VV', ''], ['together,', 'NN', ''], 'it', 'was', ['suggest', 'VV', 'ed'], 'that', ['Carl,', 'NN', ''], 'Alan', 'and', 'Alan', 'APOS', ['wife', 'NN', ''], 'should', ['go', 'VV', ''], ['together', 'AV', ''], '.']).
tagged('a lawyer signed every report, and so did an auditor .', ['a', ['lawyer', 'NN', ''], ['sign', 'VV', 'ed'], 'every', ['report,', 'NN', ''], 'and', 'so', 'did', 'an', ['auditor', 'NN', ''], '.']).
tagged('that is, there was one lawyer who signed all the reports .', ['that', ['is,', 'NN', ''], 'there', 'was', 'one', ['lawyer', 'NN', ''], 'who', ['sign', 'VV', 'ed'], 'all', 'the', ['report', 'NN', 's'], '.']).
tagged('was there one auditor who signed all the reports ?', ['was', 'there', 'one', ['auditor', 'NN', ''], 'who', ['sign', 'VV', 'ed'], 'all', 'the', ['report', 'NN', 's'], '?']).
tagged('there was one auditor who signed all the reports .', ['there', 'was', 'one', ['auditor', 'NN', ''], 'who', ['sign', 'VV', 'ed'], 'all', 'the', ['report', 'NN', 's'], '.']).
tagged('John has a genuine diamond .', ['John', 'has', 'a', ['genuine', 'AJ', ''], ['diamond', 'NN', ''], '.']).
tagged('does John have a diamond ?', ['does', 'John', 'have', 'a', ['diamond', 'NN', ''], '?']).
tagged('John has a diamond .', ['John', 'has', 'a', ['diamond', 'NN', ''], '.']).
tagged('John is a former university student .', ['John', 'is', 'a', 'former', ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('is John a university student ?', ['is', 'John', 'a', ['university', 'NN', ''], ['student', 'NN', ''], '?']).
tagged('John is a university student .', ['John', 'is', 'a', ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('John is a successful former university student .', ['John', 'is', 'a', ['successful', 'AJ', ''], 'former', ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('is John successful ?', ['is', 'John', ['successful', 'AJ', ''], '?']).
tagged('John is successful .', ['John', 'is', ['successful', 'AJ', ''], '.']).
tagged('John is a former successful university student .', ['John', 'is', 'a', 'former', ['successful', 'AJ', ''], ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('is John successful ?', ['is', 'John', ['successful', 'AJ', ''], '?']).
tagged('John is successful .', ['John', 'is', ['successful', 'AJ', ''], '.']).
tagged('John is a former successful university student .', ['John', 'is', 'a', 'former', ['successful', 'AJ', ''], ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('is John a university student ?', ['is', 'John', 'a', ['university', 'NN', ''], ['student', 'NN', ''], '?']).
tagged('John is a university student .', ['John', 'is', 'a', ['university', 'NN', ''], ['student', 'NN', ''], '.']).
tagged('every mammal is an animal .', ['every', ['mammal', 'NN', ''], 'is', 'an', ['animal', 'NN', ''], '.']).
tagged('is every four-legged mammal a four-legged animal ?', ['is', 'every', ['four-legged', 'AJ', ''], ['mammal', 'AJ', ''], 'a', ['four-legged', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('every four-legged mammal is a four-legged animal .', ['every', ['four-legged', 'AJ', ''], ['mammal', 'NN', ''], 'is', 'a', ['four-legged', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Dumbo is a four-legged animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['four-legged', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Dumbo four-legged ?', ['is', ['Dumbo', 'NN', ''], ['four-legged', 'VV', ''], '?']).
tagged('Dumbo is four-legged .', [['Dumbo', 'NN', ''], 'is', ['four-legged', 'VV', ''], '.']).
tagged('Mickey is a small animal .', ['Mickey', 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Mickey a large animal ?', ['is', 'Mickey', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Mickey is a large animal .', ['Mickey', 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Dumbo is a large animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Dumbo a small animal ?', ['is', ['Dumbo', 'NN', ''], 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Dumbo is a small animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Fido is not a small animal .', ['Fido', 'is', 'not', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Fido a large animal ?', ['is', ['Fido', 'NN', ''], 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Fido is a large animal .', ['Fido', 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Fido is not a large animal .', ['Fido', 'is', 'not', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Fido a small animal ?', ['is', ['Fido', 'NN', ''], 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Fido is a small animal .', ['Fido', 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Mickey is a small animal .', ['Mickey', 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Dumbo is a large animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Mickey smaller than Dumbo ?', ['is', 'Mickey', ['smaller', 'AJ', ''], 'than', ['Dumbo', 'NN', ''], '?']).
tagged('Mickey is smaller than Dumbo .', ['Mickey', 'is', ['smaller', 'AJ', ''], 'than', ['Dumbo', 'NN', ''], '.']).
tagged('Mickey is a small animal .', ['Mickey', 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('Dumbo is a large animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('is Mickey larger than Dumbo ?', ['is', 'Mickey', ['larger', 'AJ', ''], 'than', ['Dumbo', 'NN', ''], '?']).
tagged('Mickey is larger than Dumbo .', ['Mickey', 'is', ['larger', 'AJ', ''], 'than', ['Dumbo', 'NN', ''], '.']).
tagged('all mice are small animals .', ['all', ['mouse', 'NN', 's'], 'are', ['small', 'AJ', ''], ['animal', 'NN', 's'], '.']).
tagged('Mickey is a large mouse .', ['Mickey', 'is', 'a', ['large', 'AJ', ''], ['mouse', 'NN', ''], '.']).
tagged('is Mickey a large animal ?', ['is', 'Mickey', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Mickey is a large animal .', ['Mickey', 'is', 'a', ['large', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('all elephants are large animals .', ['all', ['elephant', 'NN', 's'], 'are', ['large', 'AJ', ''], ['animal', 'NN', 's'], '.']).
tagged('Dumbo is a small elephant .', [['Dumbo', 'NN', ''], 'is', 'a', ['small', 'AJ', ''], ['elephant', 'NN', ''], '.']).
tagged('is Dumbo a small animal ?', ['is', ['Dumbo', 'NN', ''], 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '?']).
tagged('Dumbo is a small animal .', [['Dumbo', 'NN', ''], 'is', 'a', ['small', 'AJ', ''], ['animal', 'NN', ''], '.']).
tagged('all mice are small animals .', ['all', ['mouse', 'NN', 's'], 'are', ['small', 'AJ', ''], ['animal', 'NN', 's'], '.']).
tagged('all elephants are large animals .', ['all', ['elephant', 'NN', 's'], 'are', ['large', 'AJ', ''], ['animal', 'NN', 's'], '.']).
tagged('Mickey is a large mouse .', ['Mickey', 'is', 'a', ['large', 'AJ', ''], ['mouse', 'NN', ''], '.']).
tagged('Dumbo is a small elephant .', [['Dumbo', 'NN', ''], 'is', 'a', ['small', 'AJ', ''], ['elephant', 'NN', ''], '.']).
tagged('is Dumbo larger than Mickey ?', ['is', ['Dumbo', 'NN', ''], ['larger', 'AJ', ''], 'than', 'Mickey', '?']).
tagged('Dumbo is larger than Mickey .', [['Dumbo', 'NN', ''], 'is', ['larger', 'AJ', ''], 'than', 'Mickey', '.']).
tagged('all mice are small animals .', ['all', ['mouse', 'NN', 's'], 'are', ['small', 'AJ', ''], ['animal', 'NN', 's'], '.']).
tagged('Mickey is a large mouse .', ['Mickey', 'is', 'a', ['large', 'AJ', ''], ['mouse', 'NN', ''], '.']).
tagged('is Mickey small ?', ['is', 'Mickey', ['small', 'AJ', ''], '?']).
tagged('Mickey is small .', ['Mickey', 'is', ['small', 'AJ', ''], '.']).
tagged('all legal authorities are law lecturers .', ['all', ['legal', 'AJ', ''], ['authorities', 'NN', ''], 'are', ['law', 'NN', ''], ['lecturer', 'NN', 's'], '.']).
tagged('all law lecturers are legal authorities .', ['all', ['law', 'NN', ''], ['lecturer', 'NN', 's'], 'are', ['legal', 'AJ', ''], ['authorities', 'NN', ''], '.']).
tagged('are all fat legal authorities fat law lecturers ?', ['are', 'all', ['fat', 'NN', ''], ['legal', 'AJ', ''], ['authorities', 'NN', ''], ['fat', 'NN', ''], ['law', 'NN', ''], ['lecturer', 'NN', 's'], '?']).
tagged('all fat legal authorities are fat law lecturers .', ['all', ['fat', 'NN', ''], ['legal', 'AJ', ''], ['authorities', 'NN', ''], 'are', ['fat', 'AJ', ''], ['law', 'NN', ''], ['lecturer', 'NN', 's'], '.']).
tagged('all legal authorities are law lecturers .', ['all', ['legal', 'AJ', ''], ['authorities', 'NN', ''], 'are', ['law', 'NN', ''], ['lecturer', 'NN', 's'], '.']).
tagged('all law lecturers are legal authorities .', ['all', ['law', 'NN', ''], ['lecturer', 'NN', 's'], 'are', ['legal', 'AJ', ''], ['authorities', 'NN', ''], '.']).
tagged('are all competent legal authorities competent law lecturers ?', ['are', 'all', ['competent', 'AJ', ''], ['legal', 'AJ', ''], ['authorities', 'NN', ''], ['competent', 'AJ', ''], ['law', 'NN', ''], ['lecturer', 'NN', 's'], '?']).
tagged('all competent legal authorities are competent law lecturers .', ['all', ['competent', 'AJ', ''], ['legal', 'AJ', ''], ['authorities', 'NN', ''], 'are', ['competent', 'AJ', ''], ['law', 'NN', ''], ['lecturer', 'NN', 's'], '.']).
tagged('John is a fatter politician than Bill .', ['John', 'is', 'a', ['fatter', 'NN', ''], ['politician', 'NN', ''], 'than', 'Bill', '.']).
tagged('is John fatter than Bill ?', ['is', 'John', ['fatter', 'NN', ''], 'than', 'Bill', '?']).
tagged('John is fatter than Bill .', ['John', 'is', ['fat', 'AJ', 'er'], 'than', 'Bill', '.']).
tagged('John is a cleverer politician than Bill .', ['John', 'is', 'a', ['cleverer', 'NN', ''], ['politician', 'NN', ''], 'than', 'Bill', '.']).
tagged('is John cleverer than Bill ?', ['is', 'John', ['cleverer', 'NN', ''], 'than', 'Bill', '?']).
tagged('John is cleverer than Bill .', ['John', 'is', ['clever', 'AJ', 'er'], 'than', 'Bill', '.']).
tagged('Kim is a clever person .', [['Kim', 'NN', ''], 'is', 'a', ['clever', 'AJ', ''], ['person', 'NN', ''], '.']).
tagged('is Kim clever ?', ['is', ['Kim', 'VV', ''], ['clever', 'AJ', ''], '?']).
tagged('Kim is clever .', [['Kim', 'NN', ''], 'is', ['clever', 'AJ', ''], '.']).
tagged('Kim is a clever politician .', [['Kim', 'NN', ''], 'is', 'a', ['clever', 'AJ', ''], ['politician', 'NN', ''], '.']).
tagged('is Kim clever ?', ['is', ['Kim', 'VV', ''], ['clever', 'AJ', ''], '?']).
tagged('Kim is clever .', [['Kim', 'NN', ''], 'is', ['clever', 'AJ', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('is the PC-6082 fast ?', ['is', 'the', ['PC-6082', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('is the PC-6082 fast ?', ['is', 'the', ['PC-6082', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('is the ITEL-XZ fast ?', ['is', 'the', ['ITEL-XZ', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the PC-6082 is slow .', ['the', ['PC-6082', 'NN', ''], 'is', ['slow', 'AJ', ''], '.']).
tagged('is the ITEL-XZ fast ?', ['is', 'the', ['ITEL-XZ', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('is the PC-6082 fast ?', ['is', 'the', ['PC-6082', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('is the PC-6082 fast ?', ['is', 'the', ['PC-6082', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the PC-6082 is fast .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('is the ITEL-XZ fast ?', ['is', 'the', ['ITEL-XZ', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the PC-6082 is slow .', ['the', ['PC-6082', 'NN', ''], 'is', ['slow', 'AJ', ''], '.']).
tagged('is the ITEL-XZ fast ?', ['is', 'the', ['ITEL-XZ', 'NN', ''], ['fast', 'AV', ''], '?']).
tagged('the ITEL-XZ is fast .', ['the', ['ITEL-XZ', 'NN', ''], 'is', ['fast', 'AJ', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-XZ ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-XZ', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('the PC-6082 is as fast as the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', 'as', ['fast', 'AJ', ''], 'as', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('is the PC-6082 slower than the ITEL-XZ ?', ['is', 'the', ['PC-6082', 'NN', ''], ['slow', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '?']).
tagged('the PC-6082 is slower than the ITEL-XZ .', ['the', ['PC-6082', 'NN', ''], 'is', ['slow', 'AJ', 'er'], 'than', 'the', ['ITEL-XZ', 'NN', ''], '.']).
tagged('ITEL won more orders than APCOM did .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', 'did', '.']).
tagged('did ITEL win some orders ?', ['did', 'ITEL', ['win', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('ITEL won some orders .', ['ITEL', ['win', 'VV', 'ed'], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM did .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', 'did', '.']).
tagged('did APCOM win some orders ?', ['did', ['APCOM', 'PRP'], ['win', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('APCOM won some orders .', [['APCOM', 'PRP'], ['win', 'VV', 'ed'], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM did .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', 'did', '.']).
tagged('APCOM won ten orders .', [['APCOM', 'PRP'], ['win', 'VV', 'ed'], ['ten', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('did ITEL win at least eleven orders ?', ['did', 'ITEL', ['win', 'VV', ''], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '?']).
tagged('ITEL won at least eleven orders .', ['ITEL', ['win', 'VV', 'ed'], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', '.']).
tagged('did ITEL win some orders ?', ['did', 'ITEL', ['win', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('ITEL won some orders .', ['ITEL', ['win', 'VV', 'ed'], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', '.']).
tagged('did APCOM win some orders ?', ['did', ['APCOM', 'PRP'], ['win', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('APCOM won some orders .', [['APCOM', 'PRP'], ['win', 'VV', 'ed'], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', '.']).
tagged('APCOM won ten orders .', [['APCOM', 'PRP'], ['win', 'VV', 'ed'], ['ten', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('did ITEL win at least eleven orders ?', ['did', 'ITEL', ['win', 'VV', ''], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '?']).
tagged('ITEL won at least eleven orders .', ['ITEL', ['win', 'VV', 'ed'], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than the APCOM contract .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'the', 'APCOM', ['contract', 'NN', ''], '.']).
tagged('did ITEL win the APCOM contract ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', 'APCOM', ['contract', 'NN', ''], '?']).
tagged('ITEL won the APCOM contract .', ['ITEL', ['win', 'VV', 'ed'], 'the', 'APCOM', ['contract', 'NN', ''], '.']).
tagged('ITEL won more orders than the APCOM contract .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'the', 'APCOM', ['contract', 'NN', ''], '.']).
tagged('did ITEL win more than one order ?', ['did', 'ITEL', ['win', 'VV', ''], ['more', 'AV', ''], 'than', 'one', ['order', 'NN', ''], '?']).
tagged('ITEL won more than one order .', ['ITEL', ['win', 'VV', 'ed'], ['more', 'AV', ''], 'than', 'one', ['order', 'NN', ''], '.']).
tagged('ITEL won twice as many orders than APCOM .', ['ITEL', ['win', 'VV', 'ed'], ['twice', 'AV', ''], 'as', 'many', ['order', 'NN', 's'], 'than', 'APCOM', '.']).
tagged('APCOM won ten orders .', [['APCOM', 'PRP'], ['win', 'VV', 'ed'], ['ten', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('did ITEL win twenty orders ?', ['did', 'ITEL', ['win', 'VV', ''], ['twenty', 'CRD'], ['order', 'NN', 's'], '?']).
tagged('ITEL won twenty orders .', ['ITEL', ['win', 'VV', 'ed'], ['twenty', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM lost .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', ['lose', 'VV', ''], '.']).
tagged('did ITEL win some orders ?', ['did', 'ITEL', ['win', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('ITEL won some orders .', ['ITEL', ['win', 'VV', 'ed'], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM lost .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', ['lose', 'VV', ''], '.']).
tagged('did APCOM lose some orders ?', ['did', ['APCOM', 'PRP'], ['lose', 'VV', ''], 'some', ['order', 'NN', 's'], '?']).
tagged('APCOM lost some orders .', [['APCOM', 'PRP'], ['lose', 'VV', ''], 'some', ['order', 'NN', 's'], '.']).
tagged('ITEL won more orders than APCOM lost .', ['ITEL', ['win', 'VV', 'ed'], 'more', ['order', 'NN', 's'], 'than', 'APCOM', ['lose', 'VV', ''], '.']).
tagged('APCOM lost ten orders .', [['APCOM', 'PRP'], ['lose', 'VV', ''], ['ten', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('did ITEL win at least eleven orders ?', ['did', 'ITEL', ['win', 'VV', ''], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '?']).
tagged('ITEL won at least eleven orders .', ['ITEL', ['win', 'VV', 'ed'], ['at', 'PRP'], 'least', ['eleven', 'CRD'], ['order', 'NN', 's'], '.']).
tagged('the PC-6082 is faster than 500 MIPS .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', ['500', 'CRD'], ['MIPS', 'NN', ''], '.']).
tagged('the ITEL-ZX is slower than 500 MIPS .', ['the', ['ITEL-ZX', 'NN', ''], 'is', ['slow', 'AJ', 'er'], 'than', ['500', 'CRD'], ['MIPS', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('ITEL sold 3000 more computers than APCOM .', ['ITEL', ['sell', 'VV', 'ed'], ['3000', 'CRD'], 'more', ['computer', 'NN', 's'], 'than', 'APCOM', '.']).
tagged('APCOM sold exactly 2500 computers .', [['APCOM', 'PRP'], ['sell', 'VV', 'ed'], ['exactly', 'AV', ''], ['2500', 'CRD'], ['computer', 'NN', 's'], '.']).
tagged('did ITEL sell 5500 computers ?', ['did', 'ITEL', ['sell', 'VV', ''], ['5500', 'CRD'], ['computer', 'NN', 's'], '?']).
tagged('ITEL sold 5500 computers .', ['ITEL', ['sell', 'VV', 'ed'], ['5500', 'CRD'], ['computer', 'NN', 's'], '.']).
tagged('APCOM has a more important customer than ITEL .', ['APCOM', 'has', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', '.']).
tagged('does APCOM have a more important customer than ITEL is ?', ['does', 'APCOM', 'have', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', 'is', '?']).
tagged('APCOM has a more important customer than ITEL is .', ['APCOM', 'has', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', 'is', '.']).
tagged('APCOM has a more important customer than ITEL .', ['APCOM', 'has', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', '.']).
tagged('does APCOM has a more important customer than ITEL has ?', ['does', 'APCOM', 'has', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', 'has', '?']).
tagged('APCOM has a more important customer than ITEL has .', ['APCOM', 'has', 'a', ['more', 'AV', ''], ['important', 'AJ', ''], ['customer', 'NN', ''], 'than', 'ITEL', 'has', '.']).
tagged('the PC-6082 is faster than every ITEL computer .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'every', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('the ITEL-ZX is an ITEL computer .', ['the', ['ITEL-ZX', 'NN', ''], 'is', 'an', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('the PC-6082 is faster than some ITEL computer .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'some', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('the ITEL-ZX is an ITEL computer .', ['the', ['ITEL-ZX', 'NN', ''], 'is', 'an', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('the PC-6082 is faster than any ITEL computer .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'any', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('the ITEL-ZX is an ITEL computer .', ['the', ['ITEL-ZX', 'NN', ''], 'is', 'an', 'ITEL', ['computer', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-ZX and the ITEL-ZY .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], 'and', 'the', ['ITEL-ZY', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('the PC-6082 is faster than the ITEL-ZX or the ITEL-ZY .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], 'or', 'the', ['ITEL-ZY', 'NN', ''], '.']).
tagged('is the PC-6082 faster than the ITEL-ZX ?', ['is', 'the', ['PC-6082', 'NN', ''], ['faster', 'AV', ''], 'than', 'the', ['ITEL-ZX', 'NN', ''], '?']).
tagged('the PC-6082 is faster than the ITEL-ZX .', ['the', ['PC-6082', 'NN', ''], 'is', ['fast', 'AJ', 'er'], 'than', 'the', ['ITEL-ZX', 'NN', ''], '.']).
tagged('ITEL has a factory in Birmingham .', ['ITEL', 'has', 'a', ['factory', 'NN', ''], ['in', 'PRP'], 'Birmingham', '.']).
tagged('does ITEL currently have a factory in Birmingham ?', ['does', 'ITEL', ['currently', 'AV', ''], 'have', 'a', ['factory', 'NN', ''], ['in', 'PRP'], 'Birmingham', '?']).
tagged('ITEL currently has a factory in Birmingham .', ['ITEL', ['currently', 'AV', ''], 'has', 'a', ['factory', 'NN', ''], ['in', 'PRP'], 'Birmingham', '.']).
tagged('since 1992 ITEL has been in Birmingham .', [['since', 'PRP'], ['1992', 'CRD'], 'ITEL', 'has', 'been', ['in', 'PRP'], 'Birmingham', '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('was ITEL in Birmingham in 1993 ?', ['was', 'ITEL', ['in', 'PRP'], 'Birmingham', ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('Itel was in Birmingham in 1993 .', [['Itel', 'NN', ''], 'was', ['in', 'PRP'], 'Birmingham', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL has developed a new editor since 1992 .', ['ITEL', 'has', ['develop', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['editor', 'NN', ''], ['since', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('did ITEL develop a new editor in 1993 ?', ['did', 'ITEL', ['develop', 'VV', ''], 'a', ['new', 'AJ', ''], ['editor', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL developed a new editor in 1993 .', ['ITEL', ['develop', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['editor', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL has expanded since 1992 .', ['ITEL', 'has', ['expand', 'VV', 'ed'], ['since', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('did ITEL expand in 1993 ?', ['did', 'ITEL', ['expand', 'VV', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL expanded in 1993 .', ['ITEL', ['expand', 'VV', 'ed'], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('since 1992 ITEL has made a loss .', [['since', 'PRP'], ['1992', 'CRD'], 'ITEL', 'has', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('did ITEL make a loss in 1993 ?', ['did', 'ITEL', ['make', 'VV', ''], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL made a loss in 1993 .', ['ITEL', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL has made a loss since 1992 .', ['ITEL', 'has', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], ['since', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('did ITEL make a loss in 1993 ?', ['did', 'ITEL', ['make', 'VV', ''], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL made a loss in 1993 .', ['ITEL', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL has made a loss since 1992 .', ['ITEL', 'has', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], ['since', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is now 1996 .', ['it', 'is', ['now', 'AV', ''], ['1996', 'CRD'], '.']).
tagged('did ITEL make a loss in 1993 ?', ['did', 'ITEL', ['make', 'VV', ''], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL made a loss in 1993 .', ['ITEL', ['make', 'VV', 'ed'], 'a', ['loss', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('in March 1993 APCOM founded ITEL .', [['in', 'PRP'], 'March', ['1993', 'CRD'], ['APCOM', 'PRP'], ['found', 'VV', 'ed'], 'ITEL', '.']).
tagged('did ITEL exist in 1992 ?', ['did', 'ITEL', ['exist', 'VV', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL existed in 1992 .', ['ITEL', ['exist', 'VV', 'ed'], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('the conference started on July 4th, 1994 .', ['the', ['conference', 'NN', ''], ['start', 'VV', 'ed'], ['on', 'PRP'], 'July', ['4th,', 'NN', ''], ['1994', 'CRD'], '.']).
tagged('it lasted 2 days .', ['it', ['last', 'VV', 'ed'], ['2', 'CRD'], ['days', 'NN', ''], '.']).
tagged('was the conference over on July 8th, 1994 ?', ['was', 'the', ['conference', 'NN', ''], ['over', 'PRP'], ['on', 'PRP'], 'July', ['8th,', 'NN', ''], ['1994', 'CRD'], '?']).
tagged('the conference was over on July 8th, 1994 .', ['the', ['conference', 'NN', ''], 'was', ['over', 'PRP'], ['on', 'PRP'], 'July', ['8th,', 'NN', ''], ['1994', 'CRD'], '.']).
tagged('yesterday APCOM signed the contract .', [['yesterday', 'AV', ''], ['APCOM', 'PRP'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('today is Saturday, July 14th .', [['today', 'AV', ''], 'is', ['Saturday,', 'NN', ''], 'July', ['14th', 'ORD'], '.']).
tagged('did APCOM sign the contract Friday, 13th . ?', ['did', ['APCOM', 'PRP'], ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], ['Friday,', 'NN', ''], ['13th', 'ORD'], '.', '?']).
tagged('APCOM signed the contract Friday, 13th .', [['APCOM', 'PRP'], ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['Friday,', 'NN', ''], ['13th', 'ORD'], '.']).
tagged('Smith left before Jones left .', ['Smith', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left before Anderson left .', ['Jones', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '.']).
tagged('did Smith leave before Anderson left ?', ['did', 'Smith', ['leave', 'VV', ''], ['before', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '?']).
tagged('Smith left before Anderson left .', ['Smith', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '.']).
tagged('Smith left after Jones left .', ['Smith', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left after Anderson left .', ['Jones', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '.']).
tagged('did Smith leave after Anderson left ?', ['did', 'Smith', ['leave', 'VV', ''], ['after', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '?']).
tagged('Smith left after Anderson left .', ['Smith', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Anderson', ['leave', 'VV', 'ed'], '.']).
tagged('Smith was present after Jones left .', ['Smith', 'was', ['present', 'VV', ''], ['after', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left after Anderson was present .', ['Jones', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Anderson', 'was', ['present', 'AJ', ''], '.']).
tagged('was Smith present after Anderson was present ?', ['was', 'Smith', ['present', 'NN', ''], ['after', 'PRP'], 'Anderson', 'was', ['present', 'AJ', ''], '?']).
tagged('Smith was present after Anderson was present .', ['Smith', 'was', ['present', 'VV', ''], ['after', 'PRP'], 'Anderson', 'was', ['present', 'AJ', ''], '.']).
tagged('Smith left .', ['Smith', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left .', ['Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Smith left before Jones left .', ['Smith', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('did Jones leave after Smith left ?', ['did', 'Jones', ['leave', 'VV', ''], ['after', 'PRP'], 'Smith', ['leave', 'VV', 'ed'], '?']).
tagged('Jones left after Smith left .', ['Jones', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Smith', ['leave', 'VV', 'ed'], '.']).
tagged('Smith left .', ['Smith', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left .', ['Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Smith left after Jones left .', ['Smith', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('did Jones leave before Smith left ?', ['did', 'Jones', ['leave', 'VV', ''], ['before', 'PRP'], 'Smith', ['leave', 'VV', 'ed'], '?']).
tagged('Jones left before Smith left .', ['Jones', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Smith', ['leave', 'VV', 'ed'], '.']).
tagged('Smith left .', ['Smith', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left .', ['Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Jones left before Smith left .', ['Jones', ['leave', 'VV', 'ed'], ['before', 'PRP'], 'Smith', ['leave', 'VV', 'ed'], '.']).
tagged('did Smith leave after Jones left ?', ['did', 'Smith', ['leave', 'VV', ''], ['after', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '?']).
tagged('Smith left after Jones left .', ['Smith', ['leave', 'VV', 'ed'], ['after', 'PRP'], 'Jones', ['leave', 'VV', 'ed'], '.']).
tagged('Jones revised the contract .', ['Jones', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Smith revised the contract .', ['Smith', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Jones revised the contract before Smith did .', ['Jones', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['before', 'PRP'], 'Smith', 'did', '.']).
tagged('did Smith revise the contract after Jones did ?', ['did', 'Smith', ['revise', 'VV', ''], 'the', ['contract', 'NN', ''], ['after', 'PRP'], 'Jones', 'did', '?']).
tagged('Smith revised the contract after Jones did .', ['Smith', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['after', 'PRP'], 'Jones', 'did', '.']).
tagged('Jones revised the contract .', ['Jones', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Smith revised the contract .', ['Smith', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Jones revised the contract after Smith did .', ['Jones', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['after', 'PRP'], 'Smith', 'did', '.']).
tagged('did Smith revise the contract before Jones did ?', ['did', 'Smith', ['revise', 'VV', ''], 'the', ['contract', 'NN', ''], ['before', 'PRP'], 'Jones', 'did', '?']).
tagged('Smith revised the contract before Jones did .', ['Smith', ['revise', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['before', 'PRP'], 'Jones', 'did', '.']).
tagged('Smith swam .', ['Smith', ['swim', 'VV', 'ed'], '.']).
tagged('Jones swam .', ['Jones', ['swim', 'VV', 'ed'], '.']).
tagged('Smith swam before Jones swam .', ['Smith', ['swim', 'VV', 'ed'], ['before', 'PRP'], 'Jones', ['swim', 'VV', 'ed'], '.']).
tagged('did Jones swim after Smith swam ?', ['did', 'Jones', ['swim', 'NN', ''], ['after', 'PRP'], 'Smith', ['swim', 'VV', 'ed'], '?']).
tagged('Jones swam after Smith swam .', ['Jones', ['swim', 'VV', 'ed'], ['after', 'PRP'], 'Smith', ['swim', 'VV', 'ed'], '.']).
tagged('Smith swam to the shore .', ['Smith', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], '.']).
tagged('Jones swam to the shore .', ['Jones', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], '.']).
tagged('Smith swam to the shore before Jones swam to the shore .', ['Smith', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], ['before', 'PRP'], 'Jones', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], '.']).
tagged('did Jones swim to the shore after Smith swam to the shore ?', ['did', 'Jones', ['swim', 'VV', ''], 'to', 'the', ['shore', 'NN', ''], ['after', 'PRP'], 'Smith', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], '?']).
tagged('Jones swam to the shore after Smith swam to the shore .', ['Jones', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], ['after', 'PRP'], 'Smith', ['swim', 'VV', 'ed'], 'to', 'the', ['shore', 'NN', ''], '.']).
tagged('Smith was present .', ['Smith', 'was', ['present', 'AJ', ''], '.']).
tagged('Jones was present .', ['Jones', 'was', ['present', 'AJ', ''], '.']).
tagged('Smith was present after Jones was present .', ['Smith', 'was', ['present', 'VV', ''], ['after', 'PRP'], 'Jones', 'was', ['present', 'AJ', ''], '.']).
tagged('was Jones present before Smith was present ?', ['was', 'Jones', ['present', 'NN', ''], ['before', 'PRP'], 'Smith', 'was', ['present', 'AJ', ''], '?']).
tagged('Jones was present before Smith was present .', ['Jones', 'was', ['present', 'VV', ''], ['before', 'PRP'], 'Smith', 'was', ['present', 'AJ', ''], '.']).
tagged('Smith was present .', ['Smith', 'was', ['present', 'AJ', ''], '.']).
tagged('Jones was present .', ['Jones', 'was', ['present', 'AJ', ''], '.']).
tagged('Smith was present before Jones was present .', ['Smith', 'was', ['present', 'VV', ''], ['before', 'PRP'], 'Jones', 'was', ['present', 'AJ', ''], '.']).
tagged('was Jones present after Smith was present ?', ['was', 'Jones', ['present', 'NN', ''], ['after', 'PRP'], 'Smith', 'was', ['present', 'AJ', ''], '?']).
tagged('Jones was present after Smith was present .', ['Jones', 'was', ['present', 'VV', ''], ['after', 'PRP'], 'Smith', 'was', ['present', 'AJ', ''], '.']).
tagged('Smith was writing a report .', ['Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Jones was writing a report .', ['Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith was writing a report before Jones was writing a report .', ['Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['before', 'PRP'], 'Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('was Jones writing a report after Smith was writing a report . ?', ['was', 'Jones', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['after', 'PRP'], 'Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.', '?']).
tagged('Jones was writing a report after Smith was writing a report .', ['Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['after', 'PRP'], 'Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith was writing a report .', ['Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Jones was writing a report .', ['Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith was writing a report after Jones was writing a report .', ['Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['after', 'PRP'], 'Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('was Jones writing a report before Smith was writing a report ?', ['was', 'Jones', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['before', 'PRP'], 'Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '?']).
tagged('Jones was writing a report before Smith was writing a report .', ['Jones', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], ['before', 'PRP'], 'Smith', 'was', ['write', 'VV', 'ing'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith left the meeting before he lost his temper .', ['Smith', ['leave', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], ['before', 'PRP'], 'he', ['lose', 'VV', ''], 'his', ['temper', 'NN', ''], '.']).
tagged('did Smith lose his temper ?', ['did', 'Smith', ['lose', 'VV', ''], 'his', ['temper', 'NN', ''], '?']).
tagged('Smith lost his temper .', ['Smith', ['lose', 'VV', ''], 'his', ['temper', 'NN', ''], '.']).
tagged('When they opened the M25, traffic increased .', [['When', 'AV', ''], 'they', ['open', 'VV', 'ed'], 'the', ['M25,', 'NN', ''], ['traffic', 'NN', ''], ['increase', 'VV', 'ed'], '.']).
tagged('Smith lived in Birmingham in 1991 .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith live in Birmingham in 1992 ?', ['did', 'Smith', ['live', 'VV', ''], ['in', 'PRP'], 'Birmingham', ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith lived in Birmingham in 1992 .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith wrote his first novel in 1991 .', ['Smith', ['write', 'VV', 'ed'], 'his', ['first', 'ORD'], ['novel', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith write his first novel in 1992 ?', ['did', 'Smith', ['write', 'VV', ''], 'his', ['first', 'ORD'], ['novel', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith wrote his first novel in 1992 .', ['Smith', ['write', 'VV', 'ed'], 'his', ['first', 'ORD'], ['novel', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith wrote a novel in 1991 .', ['Smith', ['write', 'VV', 'ed'], 'a', ['novel', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith write it in 1992 ?', ['did', 'Smith', ['write', 'VV', ''], 'it', ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith wrote it in 1992 .', ['Smith', ['write', 'VV', 'ed'], 'it', ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith wrote a novel in 1991 .', ['Smith', ['write', 'VV', 'ed'], 'a', ['novel', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith write a novel in 1992 ?', ['did', 'Smith', ['write', 'VV', ''], 'a', ['novel', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith wrote a novel in 1992 .', ['Smith', ['write', 'VV', 'ed'], 'a', ['novel', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith was running a business in 1991 .', ['Smith', 'was', ['run', 'VV', 'ed'], 'a', ['business', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('was Smith running it in 1992 ?', ['was', 'Smith', ['run', 'VV', 'ed'], 'it', ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith was running it in 1992 .', ['Smith', 'was', ['run', 'VV', 'ed'], 'it', ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith discovered a new species in 1991 .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith discover it in 1992 ?', ['did', 'Smith', ['discover', 'VV', ''], 'it', ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith discovered it in 1992 .', ['Smith', ['discover', 'VV', 'ed'], 'it', ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith discovered a new species in 1991 .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['1991', 'CRD'], '.']).
tagged('did Smith discover a new species in 1992 ?', ['did', 'Smith', ['discover', 'VV', ''], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('Smith discovered a new species in 1992 .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith wrote a report in two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('Smith started writing the report at 8 am .', ['Smith', ['start', 'VV', 'ed'], ['writing', 'NN', ''], 'the', ['report', 'NN', ''], ['at', 'PRP'], ['8', 'CRD'], 'am', '.']).
tagged('Had Smith finished writing the report by 11 am ?', ['Had', 'Smith', ['finish', 'VV', 'ed'], ['writing', 'NN', ''], 'the', ['report', 'NN', ''], ['by', 'PRP'], ['11', 'CRD'], 'am', '?']).
tagged('Smith had finished writing the report by 11 am .', ['Smith', 'had', ['finish', 'VV', 'ed'], ['writing', 'NN', ''], 'the', ['report', 'NN', ''], ['by', 'PRP'], ['11', 'CRD'], 'am', '.']).
tagged('Smith wrote a report in two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith spend two hours writing the report ?', ['did', 'Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['write', 'VV', 'ing'], 'the', ['report', 'NN', ''], '?']).
tagged('Smith spent two hours writing the report .', ['Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['write', 'VV', 'ing'], 'the', ['report', 'NN', ''], '.']).
tagged('Smith wrote a report in two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith spend more than two hours writing the report ?', ['did', 'Smith', ['spend', 'VV', ''], ['more', 'AV', ''], 'than', ['two', 'CRD'], ['hours', 'NN', ''], ['write', 'VV', 'ing'], 'the', ['report', 'NN', ''], '?']).
tagged('Smith spent more than two hours writing the report .', ['Smith', ['spend', 'VV', ''], ['more', 'AV', ''], 'than', ['two', 'CRD'], ['hours', 'NN', ''], ['write', 'VV', 'ing'], 'the', ['report', 'NN', ''], '.']).
tagged('Smith wrote a report in two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith write a report in one hour ?', ['did', 'Smith', ['write', 'VV', ''], 'a', ['report', 'NN', ''], ['in', 'PRP'], 'one', ['hour', 'NN', ''], '?']).
tagged('Smith wrote a report in one hour .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], 'one', ['hour', 'NN', ''], '.']).
tagged('Smith wrote a report in two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith write a report ?', ['did', 'Smith', ['write', 'VV', ''], 'a', ['report', 'NN', ''], '?']).
tagged('Smith wrote a report .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith discovered a new species in two hours .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith spend two hours discovering the new species ?', ['did', 'Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['discover', 'VV', 'ed'], 'the', ['new', 'AJ', ''], ['species', 'NN', ''], '?']).
tagged('Smith spent two hours discovering the new species .', ['Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['discover', 'VV', 'ed'], 'the', ['new', 'AJ', ''], ['species', 'NN', ''], '.']).
tagged('Smith discovered a new species in two hours .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith discover a new species ?', ['did', 'Smith', ['discover', 'VV', ''], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], '?']).
tagged('Smith discovered a new species .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], '.']).
tagged('Smith discovered many new species in two hours .', ['Smith', ['discover', 'VV', 'ed'], 'many', ['new', 'AJ', ''], ['species', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith spend two hours discovering new species ?', ['did', 'Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['discover', 'VV', 'ed'], ['new', 'AJ', ''], ['species', 'NN', ''], '?']).
tagged('Smith spent two hours discovering new species .', ['Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['hours', 'NN', ''], ['discover', 'VV', 'ed'], ['new', 'AJ', ''], ['species', 'NN', ''], '.']).
tagged('Smith was running his own business in two years .', ['Smith', 'was', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith spend two years running his own business ?', ['did', 'Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['years', 'NN', ''], ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '?']).
tagged('Smith spent two years running his own business .', ['Smith', ['spend', 'VV', ''], ['two', 'CRD'], ['years', 'NN', ''], ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '.']).
tagged('Smith was running his own business in two years .', ['Smith', 'was', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith spend more than two years running his own business ?', ['did', 'Smith', ['spend', 'VV', ''], ['more', 'AV', ''], 'than', ['two', 'CRD'], ['years', 'NN', ''], ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '?']).
tagged('Smith spent more than two years running his own business .', ['Smith', ['spend', 'VV', ''], ['more', 'AV', ''], 'than', ['two', 'CRD'], ['years', 'NN', ''], ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '.']).
tagged('Smith was running his own business in two years .', ['Smith', 'was', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith run his own business ?', ['did', 'Smith', ['run', 'VV', ''], 'his', 'own', ['business', 'NN', ''], '?']).
tagged('Smith ran his own business .', ['Smith', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '.']).
tagged('in two years Smith owned a chain of businesses .', [['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], 'Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', 's'], '.']).
tagged('did Smith own a chain of business for two years ?', ['did', 'Smith', ['own', 'VV', ''], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '?']).
tagged('Smith owned a chain of business for two years .', ['Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('in two years Smith owned a chain of businesses .', [['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], 'Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', 's'], '.']).
tagged('did Smith own a chain of business for more than two years ?', ['did', 'Smith', ['own', 'VV', ''], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], ['for', 'PRP'], 'more', 'than', ['two', 'CRD'], ['years', 'NN', ''], '?']).
tagged('Smith owned a chain of business for more than two years .', ['Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], ['for', 'PRP'], 'more', 'than', ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('in two years Smith owned a chain of businesses .', [['in', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], 'Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', 's'], '.']).
tagged('did Smith own a chain of business ?', ['did', 'Smith', ['own', 'VV', ''], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], '?']).
tagged('Smith owned a chain of business .', ['Smith', ['own', 'VV', 'ed'], 'a', ['chain', 'NN', ''], 'of', ['business', 'NN', ''], '.']).
tagged('Smith lived in Birmingham for two years .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith live in Birmingham for a year ?', ['did', 'Smith', ['live', 'VV', ''], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], 'a', ['year', 'NN', ''], '?']).
tagged('Smith lived in Birmingham for a year .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], 'a', ['year', 'NN', ''], '.']).
tagged('Smith lived in Birmingham for two years .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith live in Birmingham for exactly a year ?', ['did', 'Smith', ['live', 'VV', ''], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], ['exactly', 'AV', ''], 'a', ['year', 'NN', ''], '?']).
tagged('Smith lived in Birmingham for exactly a year .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], ['exactly', 'AV', ''], 'a', ['year', 'NN', ''], '.']).
tagged('Smith lived in Birmingham for two years .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith live in Birmingham ?', ['did', 'Smith', ['live', 'VV', ''], ['in', 'PRP'], 'Birmingham', '?']).
tagged('Smith lived in Birmingham .', ['Smith', ['live', 'VV', 'ed'], ['in', 'PRP'], 'Birmingham', '.']).
tagged('Smith ran his own business for two years .', ['Smith', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith run his own business for a year ?', ['did', 'Smith', ['run', 'VV', ''], 'his', 'own', ['business', 'NN', ''], ['for', 'PRP'], 'a', ['year', 'NN', ''], '?']).
tagged('Smith ran his own business for a year .', ['Smith', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['for', 'PRP'], 'a', ['year', 'NN', ''], '.']).
tagged('Smith ran his own business for two years .', ['Smith', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith run his own business ?', ['did', 'Smith', ['run', 'VV', ''], 'his', 'own', ['business', 'NN', ''], '?']).
tagged('Smith ran his own business .', ['Smith', ['run', 'VV', 'ed'], 'his', 'own', ['business', 'NN', ''], '.']).
tagged('Smith wrote a report for two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith write a report for an hour ?', ['did', 'Smith', ['write', 'VV', ''], 'a', ['report', 'NN', ''], ['for', 'PRP'], 'an', ['hour', 'NN', ''], '?']).
tagged('Smith wrote a report for an hour .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['for', 'PRP'], 'an', ['hour', 'NN', ''], '.']).
tagged('Smith wrote a report for two hours .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['hours', 'NN', ''], '.']).
tagged('did Smith write a report ?', ['did', 'Smith', ['write', 'VV', ''], 'a', ['report', 'NN', ''], '?']).
tagged('Smith wrote a report .', ['Smith', ['write', 'VV', 'ed'], 'a', ['report', 'NN', ''], '.']).
tagged('Smith discovered a new species for an hour .', ['Smith', ['discover', 'VV', 'ed'], 'a', ['new', 'AJ', ''], ['species', 'NN', ''], ['for', 'PRP'], 'an', ['hour', 'NN', ''], '.']).
tagged('Smith discovered new species for two years .', ['Smith', ['discover', 'VV', 'ed'], ['new', 'AJ', ''], ['species', 'NN', ''], ['for', 'PRP'], ['two', 'CRD'], ['years', 'NN', ''], '.']).
tagged('did Smith discover new species ?', ['did', 'Smith', ['discover', 'VV', ''], ['new', 'AJ', ''], ['species', 'NN', ''], '?']).
tagged('Smith discovered new species .', ['Smith', ['discover', 'VV', 'ed'], ['new', 'AJ', ''], ['species', 'NN', ''], '.']).
tagged('in 1994 ITEL sent a progress report every month .', [['in', 'PRP'], ['1994', 'CRD'], 'ITEL', ['send', 'VV', ''], 'a', ['progress', 'NN', ''], ['report', 'VV', ''], 'every', ['month', 'NN', ''], '.']).
tagged('did ITEL send a progress report in July 1994 ?', ['did', 'ITEL', ['send', 'VV', ''], 'a', ['progress', 'NN', ''], ['report', 'NN', ''], ['in', 'PRP'], 'July', ['1994', 'CRD'], '?']).
tagged('ITEL sent a progress report in July 1994 .', ['ITEL', ['send', 'VV', ''], 'a', ['progress', 'NN', ''], ['report', 'NN', ''], ['in', 'PRP'], 'July', ['1994', 'CRD'], '.']).
tagged('Smith wrote to a representative every week .', ['Smith', ['write', 'VV', 'ed'], 'to', 'a', ['representative', 'NN', ''], 'every', ['week', 'NN', ''], '.']).
tagged('is there a representative that Smith wrote to every week ?', ['is', 'there', 'a', ['representative', 'NN', ''], 'that', 'Smith', ['write', 'VV', 'ed'], 'to', 'every', ['week', 'NN', ''], '?']).
tagged('there is a representative that Smith wrote to every week .', ['there', 'is', 'a', ['representative', 'NN', ''], 'that', 'Smith', ['write', 'VV', 'ed'], 'to', 'every', ['week', 'NN', ''], '.']).
tagged('Smith left the house at a quarter past five .', ['Smith', ['leave', 'VV', 'ed'], 'the', ['house', 'NN', ''], ['at', 'PRP'], 'a', ['quarter', 'NN', ''], ['past', 'PRP'], ['five', 'CRD'], '.']).
tagged('she took a taxi to the station and caught the first train to Luxembourg .', ['she', ['take', 'VV', 'ed1'], 'a', ['taxi', 'NN', ''], 'to', 'the', ['station', 'NN', ''], 'and', ['catch', 'VV', 'ed1'], 'the', ['first', 'ORD'], ['train', 'NN', ''], 'to', 'Luxembourg', '.']).
tagged('Smith lost some files .', ['Smith', ['lose', 'VV', ''], 'some', ['file', 'NN', 's'], '.']).
tagged('they were destroyed when her hard disk crashed .', ['they', 'were', ['destroy', 'VV', 'ed'], ['when', 'AV', ''], 'her', ['hard', 'AJ', ''], ['disk', 'NN', ''], ['crash', 'VV', 'ed'], '.']).
tagged('Smith had left the house at a quarter past five .', ['Smith', 'had', ['leave', 'VV', 'ed'], 'the', ['house', 'NN', ''], ['at', 'PRP'], 'a', ['quarter', 'NN', ''], ['past', 'PRP'], ['five', 'CRD'], '.']).
tagged('then she took a taxi to the station .', [['then', 'AV', ''], 'she', ['take', 'VV', 'ed1'], 'a', ['taxi', 'NN', ''], 'to', 'the', ['station', 'NN', ''], '.']).
tagged('did Smith leave the house before she took a taxi to the station ?', ['did', 'Smith', ['leave', 'VV', ''], 'the', ['house', 'NN', ''], ['before', 'PRP'], 'she', ['take', 'VV', 'ed1'], 'a', ['taxi', 'NN', ''], 'to', 'the', ['station', 'NN', ''], '?']).
tagged('Smith left the house before she took a taxi to the station .', ['Smith', ['leave', 'VV', 'ed'], 'the', ['house', 'NN', ''], ['before', 'PRP'], 'she', ['take', 'VV', 'ed1'], 'a', ['taxi', 'NN', ''], 'to', 'the', ['station', 'NN', ''], '.']).
tagged('ITEL always delivers reports late .', ['ITEL', ['always', 'AV', ''], ['deliver', 'VV', 's'], ['report', 'NN', 's'], ['late', 'AJ', ''], '.']).
tagged('in 1993 ITEL delivered reports .', [['in', 'PRP'], ['1993', 'CRD'], 'ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], '.']).
tagged('did ITEL delivered reports late in 1993 ?', ['did', 'ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], ['late', 'AJ', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL delivered reports late in 1993 .', ['ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], ['late', 'AJ', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL never delivers reports late .', ['ITEL', ['never', 'AV', ''], ['deliver', 'VV', 's'], ['report', 'NN', 's'], ['late', 'AJ', ''], '.']).
tagged('in 1993 ITEL delivered reports .', [['in', 'PRP'], ['1993', 'CRD'], 'ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], '.']).
tagged('did ITEL delivered reports late in 1993 ?', ['did', 'ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], ['late', 'AJ', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL delivered reports late in 1993 .', ['ITEL', ['deliver', 'VV', 'ed'], ['report', 'NN', 's'], ['late', 'AJ', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('Smith arrived in Paris on the 5th of May, 1995 .', ['Smith', ['arrive', 'VV', 'ed'], ['in', 'PRP'], 'Paris', ['on', 'PRP'], 'the', ['5th', 'ORD'], 'of', ['May,', 'NN', ''], ['1995', 'CRD'], '.']).
tagged('Today is the 15th of May, 1995 .', [['Today', 'NN', ''], 'is', 'the', ['15th', 'ORD'], 'of', ['May,', 'NN', ''], ['1995', 'CRD'], '.']).
tagged('she is still in Paris .', ['she', 'is', ['still', 'AV', ''], ['in', 'PRP'], 'Paris', '.']).
tagged('was Smith in Paris on the 7th of May, 1995 ?', ['was', 'Smith', ['in', 'PRP'], 'Paris', ['on', 'PRP'], 'the', ['7th', 'ORD'], 'of', ['May,', 'NN', ''], ['1995', 'CRD'], '?']).
tagged('Smith was in Paris on the 7th of May, 1995 .', ['Smith', 'was', ['in', 'PRP'], 'Paris', ['on', 'PRP'], 'the', ['7th', 'ORD'], 'of', ['May,', 'NN', ''], ['1995', 'CRD'], '.']).
tagged('when Smith arrived in Katmandu she had been travelling for three days .', [['when', 'AV', ''], 'Smith', ['arrive', 'VV', 'ed'], ['in', 'PRP'], 'Katmandu', 'she', 'had', 'been', ['travel', 'VV', 'ed'], ['for', 'PRP'], ['three', 'CRD'], ['days', 'NN', ''], '.']).
tagged('had Smith been travelling the day before she arrived in Katmandu ?', ['had', 'Smith', 'been', ['travel', 'VV', 'ed'], 'the', ['day', 'NN', ''], ['before', 'PRP'], 'she', ['arrive', 'VV', 'ed'], ['in', 'PRP'], 'Katmandu', '?']).
tagged('Smith had been travelling the day before she arrived in Katmandu .', ['Smith', 'had', 'been', ['travel', 'VV', 'ed'], 'the', ['day', 'NN', ''], ['before', 'PRP'], 'she', ['arrive', 'VV', 'ed'], ['in', 'PRP'], 'Katmandu', '.']).
tagged('Jones graduated in March and has been employed ever since .', ['Jones', ['graduate', 'VV', 'ed'], ['in', 'PRP'], 'March', 'and', 'has', 'been', ['employ', 'VV', 'ed'], ['ever', 'AV', ''], ['since', 'PRP'], '.']).
tagged('Jones has been unemployed in the past .', ['Jones', 'has', 'been', ['unemployed', 'AJ', ''], ['in', 'PRP'], 'the', ['past', 'NN', ''], '.']).
tagged('was Jones unemployed at some time before he graduated ?', ['was', 'Jones', ['unemployed', 'AJ', ''], ['at', 'PRP'], 'some', ['time', 'NN', ''], ['before', 'PRP'], 'he', ['graduate', 'VV', 'ed'], '?']).
tagged('Jones was unemployed at some time before he graduated .', ['Jones', 'was', ['unemployed', 'AJ', ''], ['at', 'PRP'], 'some', ['time', 'NN', ''], ['before', 'PRP'], 'he', ['graduate', 'VV', 'ed'], '.']).
tagged('every representative has read this report .', ['every', ['representative', 'NN', ''], 'has', ['read', 'VV', ''], 'this', ['report', 'NN', ''], '.']).
tagged('no two representatives have read it at the same time .', ['no', ['two', 'CRD'], ['representative', 'NN', 's'], 'have', ['read', 'VV', ''], 'it', ['at', 'PRP'], 'the', 'same', ['time', 'NN', ''], '.']).
tagged('no representative took less than half a day to read the report .', ['no', ['representative', 'NN', ''], ['take', 'VV', 'ed1'], ['less', 'AV', ''], 'than', 'half', 'a', ['day', 'NN', ''], 'to', ['read', 'VV', ''], 'the', ['report', 'NN', ''], '.']).
tagged('there are sixteen representatives .', ['there', 'are', ['sixteen', 'CRD'], ['representative', 'NN', 's'], '.']).
tagged('did it take the representatives more than a week to read the report ?', ['did', 'it', ['take', 'VV', ''], 'the', ['representative', 'NN', 's'], ['more', 'AV', ''], 'than', 'a', ['week', 'NN', ''], 'to', ['read', 'VV', ''], 'the', ['report', 'NN', ''], '?']).
tagged('it took the representatives more than a week to read the report .', ['it', ['take', 'VV', 'ed1'], 'the', ['representative', 'NN', 's'], ['more', 'AV', ''], 'than', 'a', ['week', 'NN', ''], 'to', ['read', 'VV', ''], 'the', ['report', 'NN', ''], '.']).
tagged('while Jones was updating the program, Mary came in and told him about the board meeting .', ['while', 'Jones', 'was', ['update', 'VV', 'ing'], 'the', ['program,', 'NN', ''], 'Mary', ['come', 'VV', 'ed'], ['in', 'PRP'], 'and', ['tell', 'VV', 'ed'], 'him', ['about', 'PRP'], 'the', ['board', 'NN', ''], ['meeting', 'NN', ''], '.']).
tagged('she finished before he did .', ['she', ['finish', 'VV', 'ed'], ['before', 'PRP'], 'he', 'did', '.']).
tagged('did Mary APOS story last as long as Jones APOS updating the program ?', ['did', 'Mary', 'APOS', ['story', 'NN', ''], ['last', 'VV', ''], 'as', ['long', 'AJ', ''], 'as', 'Jones', 'APOS', ['updating', 'NN', ''], 'the', ['program', 'NN', ''], '?']).
tagged('Mary APOS story lasted as long as Jones APOS updating the program .', ['Mary', 'APOS', ['story', 'NN', ''], ['last', 'VV', 'ed'], 'as', ['long', 'AJ', ''], 'as', 'Jones', 'APOS', ['updating', 'NN', ''], 'the', ['program', 'NN', ''], '.']).
tagged('before APCOM bought its present office building, it had been paying mortgage interest on the previous one for 8 years .', ['before', 'APCOM', ['buy', 'VV', 'ed1'], 'its', ['present', 'AJ', ''], ['office', 'NN', ''], ['building,', 'NN', ''], 'it', 'had', 'been', ['pay', 'VV', 'ed'], ['mortgage', 'NN', ''], ['interest', 'NN', ''], ['on', 'PRP'], 'the', ['previous', 'AJ', ''], 'one', ['for', 'PRP'], ['8', 'CRD'], ['years', 'NN', ''], '.']).
tagged('since APCOM bought its present office building it has been paying mortgage interest on it for more than 10 years .', [['since', 'PRP'], 'APCOM', ['buy', 'VV', 'ed1'], 'its', ['present', 'AJ', ''], ['office', 'NN', ''], ['building', 'NN', ''], 'it', 'has', 'been', ['pay', 'VV', 'ed'], ['mortgage', 'NN', ''], ['interest', 'NN', ''], ['on', 'PRP'], 'it', ['for', 'PRP'], 'more', 'than', ['10', 'CRD'], ['years', 'NN', ''], '.']).
tagged('has APCOM been paying mortgage interest for a total of 15 years or more ?', ['has', ['APCOM', 'PRP'], 'been', ['pay', 'VV', 'ed'], ['mortgage', 'NN', ''], ['interest', 'NN', ''], ['for', 'PRP'], 'a', ['total', 'NN', ''], 'of', ['15', 'CRD'], ['years', 'NN', ''], 'or', ['more', 'AV', ''], '?']).
tagged('APCOM has been paying mortgage interest for a total of 15 years or more .', ['APCOM', 'has', 'been', ['pay', 'VV', 'ed'], ['mortgage', 'NN', ''], ['interest', 'NN', ''], ['for', 'PRP'], 'a', ['total', 'NN', ''], 'of', ['15', 'CRD'], ['years', 'NN', ''], 'or', ['more', 'AV', ''], '.']).
tagged('when Jones got his job at the CIA, he knew that he would never be allowed to write his memoirs .', [['when', 'AV', ''], 'Jones', ['get', 'VV', 'ed'], 'his', ['job', 'NN', ''], ['at', 'PRP'], 'the', ['CIA,', 'NN', ''], 'he', ['know', 'VV', 'ed1'], 'that', 'he', 'would', ['never', 'AV', ''], 'be', ['allow', 'VV', 'ed'], 'to', ['write', 'VV', ''], 'his', ['memoir', 'NN', 's'], '.']).
tagged('is it the case that Jones is not and will never be allowed to write his memoirs ?', ['is', 'it', 'the', ['case', 'NN', ''], 'that', 'Jones', 'is', 'not', 'and', 'will', ['never', 'AV', ''], 'be', ['allow', 'VV', 'ed'], 'to', ['write', 'VV', ''], 'his', ['memoir', 'NN', 's'], '?']).
tagged('it is the case that Jones is not and will never be allowed to write his memoirs .', ['it', 'is', 'the', ['case', 'NN', ''], 'that', 'Jones', 'is', 'not', 'and', 'will', ['never', 'AV', ''], 'be', ['allow', 'VV', 'ed'], 'to', ['write', 'VV', ''], 'his', ['memoir', 'NN', 's'], '.']).
tagged('Smith has been to Florence twice in the past .', ['Smith', 'has', 'been', 'to', 'Florence', ['twice', 'AV', ''], ['in', 'PRP'], 'the', ['past', 'NN', ''], '.']).
tagged('Smith will go to Florence twice in the coming year .', ['Smith', 'will', ['go', 'VV', ''], 'to', 'Florence', ['twice', 'AV', ''], ['in', 'PRP'], 'the', ['coming', 'NN', ''], ['year', 'NN', ''], '.']).
tagged('two years from now will Smith have been to Florence at least four times ?', [['two', 'CRD'], ['years', 'NN', ''], ['from', 'PRP'], 'now', 'will', 'Smith', 'have', 'been', 'to', 'Florence', ['at', 'PRP'], 'least', ['four', 'CRD'], ['times', 'NN', ''], '?']).
tagged('two years from now Smith will have been to Florence at least four times .', [['two', 'CRD'], ['years', 'NN', ''], ['from', 'PRP'], ['now', 'AV', ''], 'Smith', 'will', 'have', 'been', 'to', 'Florence', ['at', 'PRP'], 'least', ['four', 'CRD'], ['times', 'NN', ''], '.']).
tagged('last week I already knew that when, in a month APOS time, Smith would discover that she had been duped she would be furious .', [['last', 'ORD'], ['week', 'NN', ''], 'I', ['already', 'AV', ''], ['know', 'VV', 'ed1'], 'that', ['when,', 'NN', ''], ['in', 'PRP'], 'a', ['month', 'NN', ''], 'APOS', ['time,', 'NN', ''], 'Smith', 'would', ['discover', 'VV', ''], 'that', 'she', 'had', 'been', ['duped', 'AJ', ''], 'she', 'would', 'be', ['furious', 'AJ', ''], '.']).
tagged('will it be the case that in a few weeks Smith will discover that she has been duped; and will she be furious ?', ['will', 'it', 'be', 'the', ['case', 'NN', ''], 'that', ['in', 'PRP'], 'a', 'few', ['week', 'NN', 's'], 'Smith', 'will', ['discover', 'VV', ''], 'that', 'she', 'has', 'been', ['duped;', 'NN', ''], 'and', 'will', 'she', 'be', ['furious', 'AJ', ''], '?']).
tagged('it will be the case that in a few weeks Smith will discover that she has been duped; and she will be furious .', ['it', 'will', 'be', 'the', ['case', 'NN', ''], 'that', ['in', 'PRP'], 'a', 'few', ['week', 'NN', 's'], 'Smith', 'will', ['discover', 'VV', ''], 'that', 'she', 'has', 'been', ['duped;', 'NN', ''], 'and', 'she', 'will', 'be', ['furious', 'AJ', ''], '.']).
tagged('no one gambling seriously stops until he is broke .', ['no', 'one', ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['stop', 'VV', 's'], 'until', 'he', 'is', ['break', 'VV', 'ed1'], '.']).
tagged('no one can gamble when he is broke .', ['no', 'one', 'can', ['gamble', 'VV', ''], ['when', 'AV', ''], 'he', 'is', ['break', 'VV', 'ed1'], '.']).
tagged('does every one who starts gambling seriously stop the moment he is broke ?', ['does', 'every', 'one', 'who', ['start', 'VV', 's'], ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['stop', 'VV', ''], 'the', ['moment', 'NN', ''], 'he', 'is', ['break', 'VV', 'ed1'], '?']).
tagged('every one who starts gambling seriously stops the moment he is broke .', ['every', 'one', 'who', ['start', 'VV', 's'], ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['stop', 'VV', 's'], 'the', ['moment', 'NN', ''], 'he', 'is', ['break', 'VV', 'ed1'], '.']).
tagged('no one who starts gambling seriously stops until he is broke .', ['no', 'one', 'who', ['start', 'VV', 's'], ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['stop', 'VV', 's'], 'until', 'he', 'is', ['break', 'VV', 'ed1'], '.']).
tagged('does every one who starts gambling seriously continue until he is broke ?', ['does', 'every', 'one', 'who', ['start', 'VV', 's'], ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['continue', 'VV', ''], 'until', 'he', 'is', ['break', 'VV', 'ed1'], '?']).
tagged('every one who starts gambling seriously continues until he is broke .', ['every', 'one', 'who', ['start', 'VV', 's'], ['gambling', 'NN', ''], ['seriously', 'AV', ''], ['continue', 'VV', 's'], 'until', 'he', 'is', ['break', 'VV', 'ed1'], '.']).
tagged('no body who is asleep ever knows that he is asleep .', ['no', ['body', 'NN', ''], 'who', 'is', ['asleep', 'AJ', ''], ['ever', 'AV', ''], ['know', 'VV', 's'], 'that', 'he', 'is', ['asleep', 'AJ', ''], '.']).
tagged('but some people know that they have been asleep after they have been asleep .', ['but', 'some', ['people', 'NN', ''], ['know', 'VV', ''], 'that', 'they', 'have', 'been', ['asleep', 'AJ', ''], 'after', 'they', 'have', 'been', ['asleep', 'AJ', ''], '.']).
tagged('do some people discover that they have been asleep ?', ['do', 'some', ['people', 'NN', ''], ['discover', 'VV', ''], 'that', 'they', 'have', 'been', ['asleep', 'AJ', ''], '?']).
tagged('some people discover that they have been asleep .', ['some', ['people', 'NN', ''], ['discover', 'VV', ''], 'that', 'they', 'have', 'been', ['asleep', 'AJ', ''], '.']).
tagged('ITEL built MTALK in 1993 .', ['ITEL', ['build', 'VV', ''], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('did ITEL finish MTALK in 1993 ?', ['did', 'ITEL', ['finish', 'NN', ''], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL finished MTALK in 1993 .', ['ITEL', ['finish', 'VV', 'ed'], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL was building MTALK in 1993 .', ['ITEL', 'was', ['building', 'NN', ''], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('did ITEL finish MTALK in 1993 ?', ['did', 'ITEL', ['finish', 'NN', ''], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL finished MTALK in 1993 .', ['ITEL', ['finish', 'VV', 'ed'], 'MTALK', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL won the contract from APCOM in 1993 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['from', 'PRP'], 'APCOM', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('did ITEL win a contract in 1993 ?', ['did', 'ITEL', ['win', 'VV', ''], 'a', ['contract', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL won a contract in 1993 .', ['ITEL', ['win', 'VV', 'ed'], 'a', ['contract', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL was winning the contract from APCOM in 1993 .', ['ITEL', 'was', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['from', 'PRP'], 'APCOM', ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('did ITEL win a contract in 1993 ?', ['did', 'ITEL', ['win', 'VV', ''], 'a', ['contract', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '?']).
tagged('ITEL won a contract in 1993 .', ['ITEL', ['win', 'VV', 'ed'], 'a', ['contract', 'NN', ''], ['in', 'PRP'], ['1993', 'CRD'], '.']).
tagged('ITEL owned APCOM from 1988 to 1992 .', ['ITEL', ['own', 'VV', 'ed'], ['APCOM', 'PRP'], ['from', 'PRP'], ['1988', 'CRD'], 'to', ['1992', 'CRD'], '.']).
tagged('did ITEL own APCOM in 1990 ?', ['did', 'ITEL', ['own', 'VV', ''], ['APCOM', 'PRP'], ['in', 'PRP'], ['1990', 'CRD'], '?']).
tagged('ITEL owned APCOM in 1990 .', ['ITEL', ['own', 'VV', 'ed'], ['APCOM', 'PRP'], ['in', 'PRP'], ['1990', 'CRD'], '.']).
tagged('Smith and Jones left the meeting .', ['Smith', 'and', 'Jones', ['leave', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did Smith leave the meeting ?', ['did', 'Smith', ['leave', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('Smith left the meeting .', ['Smith', ['leave', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Smith and Jones left the meeting .', ['Smith', 'and', 'Jones', ['leave', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('did Jones leave the meeting ?', ['did', 'Jones', ['leave', 'VV', ''], 'the', ['meeting', 'NN', ''], '?']).
tagged('Jones left the meeting .', ['Jones', ['leave', 'VV', 'ed'], 'the', ['meeting', 'NN', ''], '.']).
tagged('Smith, Anderson and Jones met .', [['Smith,', 'NN', ''], 'Anderson', 'and', 'Jones', ['meet', 'VV', ''], '.']).
tagged('was there a group of people that met ?', ['was', 'there', 'a', ['group', 'NN', ''], 'of', ['people', 'NN', ''], 'that', ['meet', 'VV', ''], '?']).
tagged('there was a group of people that met .', ['there', 'was', 'a', ['group', 'NN', ''], 'of', ['people', 'NN', ''], 'that', ['meet', 'VV', ''], '.']).
tagged('Smith knew that ITEL had won the contract in 1992 .', ['Smith', ['know', 'VV', 'ed1'], 'that', 'ITEL', 'had', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith believed that ITEL had won the contract in 1992 .', ['Smith', ['believe', 'VV', 'ed'], 'that', 'ITEL', 'had', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('ITEL managed to win the contract in 1992 .', ['ITEL', ['manage', 'VV', 'ed'], 'to', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('ITEL tried to win the contract in 1992 .', ['ITEL', ['try', 'VV', 'ed'], 'to', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is true that ITEL won the contract in 1992 .', ['it', 'is', ['true', 'AJ', ''], 'that', 'ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('it is false that ITEL won the contract in 1992 .', ['it', 'is', ['false', 'AJ', ''], 'that', 'ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('did ITEL win the contract in 1992 ?', ['did', 'ITEL', ['win', 'VV', ''], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '?']).
tagged('ITEL won the contract in 1992 .', ['ITEL', ['win', 'VV', 'ed'], 'the', ['contract', 'NN', ''], ['in', 'PRP'], ['1992', 'CRD'], '.']).
tagged('Smith saw Jones sign the contract .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('if Jones signed the contract, his heart was beating .', ['if', 'Jones', ['sign', 'VV', 'ed'], 'the', ['contract,', 'NN', ''], 'his', ['heart', 'NN', ''], 'was', ['beat', 'VV', 'ed'], '.']).
tagged('did Smith see Jones&apos; heart beat ?', ['did', 'Smith', ['see', 'VV', ''], ['Jones&apos;', 'NN', ''], ['heart', 'NN', ''], ['beat', 'NN', ''], '?']).
tagged('Smith saw Jones&apos; heart beat .', ['Smith', ['saw', 'VV', ''], ['Jones&apos;', 'NN', ''], ['heart', 'NN', ''], ['beat', 'NN', ''], '.']).
tagged('Smith saw Jones sign the contract .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('when Jones signed the contract, his heart was beating .', [['when', 'AV', ''], 'Jones', ['sign', 'VV', 'ed'], 'the', ['contract,', 'NN', ''], 'his', ['heart', 'NN', ''], 'was', ['beat', 'VV', 'ed'], '.']).
tagged('did Smith see Jones&apos; heart beat ?', ['did', 'Smith', ['see', 'VV', ''], ['Jones&apos;', 'NN', ''], ['heart', 'NN', ''], ['beat', 'NN', ''], '?']).
tagged('Smith saw Jones&apos; heart beat .', ['Smith', ['saw', 'VV', ''], ['Jones&apos;', 'NN', ''], ['heart', 'NN', ''], ['beat', 'NN', ''], '.']).
tagged('Smith saw Jones sign the contract .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('did Jones sign the contract ?', ['did', 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Jones signed the contract .', ['Jones', ['sign', 'VV', 'ed'], 'the', ['contract', 'NN', ''], '.']).
tagged('Smith saw Jones sign the contract .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('Jones is the chairman of ITEL .', ['Jones', 'is', 'the', ['chairman', 'NN', ''], 'of', 'ITEL', '.']).
tagged('did Smith see the chairman of ITEL sign the contract ?', ['did', 'Smith', ['see', 'VV', ''], 'the', ['chairman', 'NN', ''], 'of', 'ITEL', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Smith saw the chairman of ITEL sign the contract .', ['Smith', ['saw', 'VV', ''], 'the', ['chairman', 'NN', ''], 'of', 'ITEL', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('Helen saw the chairman of the department answer the phone .', ['Helen', ['saw', 'VV', ''], 'the', ['chairman', 'NN', ''], 'of', 'the', ['department', 'NN', ''], ['answer', 'VV', ''], 'the', ['phone', 'NN', ''], '.']).
tagged('the chairman of the department is a person .', ['the', ['chairman', 'NN', ''], 'of', 'the', ['department', 'NN', ''], 'is', 'a', ['person', 'NN', ''], '.']).
tagged('is there any one whom Helen saw answer the phone ?', ['is', 'there', 'any', 'one', 'whom', 'Helen', ['saw', 'VV', ''], ['answer', 'NN', ''], 'the', ['phone', 'NN', ''], '?']).
tagged('there is some one whom Helen saw answer the phone .', ['there', 'is', 'some', 'one', 'whom', 'Helen', ['saw', 'VV', ''], ['answer', 'NN', ''], 'the', ['phone', 'NN', ''], '.']).
tagged('Smith saw Jones sign the contract and his secretary make a copy .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], 'and', 'his', ['secretary', 'NN', ''], ['make', 'VV', ''], 'a', ['copy', 'NN', ''], '.']).
tagged('did Smith see Jones sign the contract ?', ['did', 'Smith', ['see', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '?']).
tagged('Smith saw Jones sign the contract .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], '.']).
tagged('Smith saw Jones sign the contract or cross out the crucial clause .', ['Smith', ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], 'or', ['cross', 'NN', ''], ['out', 'PRP'], 'the', ['crucial', 'AJ', ''], ['clause', 'NN', ''], '.']).
tagged('did Smith either see Jones sign the contract or see Jones cross out the crucial clause ?', ['did', 'Smith', ['either', 'AV', ''], ['see', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], 'or', ['see', 'VV', ''], 'Jones', ['cross', 'VV', ''], ['out', 'PRP'], 'the', ['crucial', 'AJ', ''], ['clause', 'NN', ''], '?']).
tagged('Smith either saw Jones sign the contract or saw Jones cross out the crucial clause .', ['Smith', ['either', 'AV', ''], ['saw', 'VV', ''], 'Jones', ['sign', 'VV', ''], 'the', ['contract', 'NN', ''], 'or', ['saw', 'VV', ''], 'Jones', ['cross', 'VV', ''], ['out', 'PRP'], 'the', ['crucial', 'AJ', ''], ['clause', 'NN', ''], '.']).
