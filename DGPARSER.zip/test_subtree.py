import COMP34411
from COMP34411 import *
import conll

sentences, pretagged = conll.readconll()
tagger = load('tagger.pck')
parser = load('parserwithlabels.pck')

import subtree
trainingdata = subtree.getTrainingdata(sentences, parser, tagger, TAG=False)

rules = subtree.getRepairRules(sentences, parser=parser, tagger=tagger, N=1000, K=1000, threshold=4, TAG=False, trainingdata=trainingdata)
