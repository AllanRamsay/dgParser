import re, sys
from useful import *
from classes import showDTree

pattern = re.compile("<(p |q|h).*?>(?P<text>.*?)</", re.DOTALL)
punc = re.compile("(\?|\.)")

def fixpunc(s):
    return replaceAll(s, [(".", " ."), ("?", " ?"), ("&apos;s", " s"), ("&", "and"), ("#", "NUM")])

def readFracas(ifile="fracas.xml", outsink=sys.stdout):
   return [fixpunc(i.group("text").strip()) for i in pattern.finditer(open(ifile).read().strip())]

def patchdict(parser):
    patches = {"tenors": {"NN":1},
               "tenor": {"NN":1},
               "no": {"DT":1},
               "many": {"DT":1},
               "Italian":{"JJ":0.9, "NN":0.1},
               "Swedish":{"JJ":0.9, "NN":0.1},
               "sing":{"VB":1.0},
               }
    d = parser.tagger.basetagger.dict
    for word in patches:
        d[word] = patches[word]
        
def parseAll(examples, parser, outsink=sys.stdout):
    patchdict(parser)
    seen = {}
    with safeout(outsink) as write:
        for example in examples:
            if not example in seen and not example == "":
                seen[example] = True
                write("\n\n%s\n"%(box(example)))
                if outsink == sys.stdout:
                    print 'parser.parse("%s").showDTree()'%(example)
                t = parser.parse(example)
                write(showDTree(t.dtree))
                write("\nCONLL*\n%s\n"%(t.parsed2conll()))

def corrected(s):
    if not "\n" in s:
        s = open(s).read()
    cpattern = re.compile("""
CONLL
(\d+	\S+	\S+	\S+	\S+	\S+	\S+	\S+\n)+""", re.DOTALL)
    for i in cpattern.finditer(s):
        print i.group(0)
        
