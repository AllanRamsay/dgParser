import sys, re, shutil
from useful import *

P0 = re.compile("""train\(maxrules=\S*, howmuchtrainingdata=(?P<HMDT>\S*)\) \*\*\*\*
\S*
Accuracy of parser on the training data \(size (?P<TD>\d*)\): \S*
Accuracy of parser on reserved data \(size \d*\):.*?Before repairing (?P<score>\S*) \(test size = \d*\)
After repairing \S* \(test size = \d*\)
\*\*\*\* """, re.DOTALL)
def scoremixtures(s="mixeddata.txt"):
    if not "\n" in s:
        s = open(s).read()
    for i in P0.finditer(s):
        print "%s\t%s"%(int(int(i.group("TD"))*float(i.group("HMDT"))), i.group("score"))

def scorevrulecount(s):
    if not "\n" in s:
        s = open(s).read()
    p1 = re.compile("""Score=\S* \S* len\(rules\)=(?P<rules>\d*)
Before repairing (?P<initial1>\S*) \((?P<initial2>\S*)\) \(test size = \d*\)
After repairing (?P<score1>\S*) \((?P<score2>\S*)\) \(test size = \d*\)""", re.DOTALL)
    print p1.pattern
    initial = True
    for i in p1.finditer(s):
        if initial:
            print "%s\t%s\t%s"%(i.group("rules"), i.group("initial1"), i.group("initial2"))
            initial = False
        print "%s\t%s\t%s"%(i.group("rules"), i.group("score1"), i.group("score2"))

def tables4languages(s="alllanguages.txt", header=["language", "tagging before TBL", "tagging after TBL", "parsing before TBL", "parsing after TBL", "training time for parsing", "training size for parsing", "parsing speed (words/sec)"]):
    if not "\n" in s:
        s = open(s).read()
    p = re.compile("""wholething\(udt=\S*, parser=\S*, tagger=\S*, language='(?P<language>.*?)'\).*?(UD|
Before retagging (?P<tagging1>\S*) \(training size = (?P<wcount>\d+)\)
After retagging (?P<tagging2>\S*) \(training size = \d+\)
Confusion matrix
(\*)*
training the tagger took (?P<taggingsecs>\d+) seconds
.*?
making the classifier took (?P<parsingsecs>\d+) \((?P<parsingdatapoints>\d*) datapoints\)
.*?@ (?P<parsingspeed>\d+) words/sec.*?
.*?
Before repairing (?P<parsing1>\S+) \(\S+\) \(test size = (?P<testsize>\d+)\)
After repairing (?P<parsing2>\S+) \(\S+\) \(test size = \d+\)
Application of TBL rules @ \d+ words/sec
Finding initial instances
(\*)*
Found--reorganising them
Top \d+ candidate rules
(\*)*(\n*Candidate rule [^\n]*\n*)*\n*Sorted--scoring them\n*(Top \d+ net scoring rules
(\*)*(\n*rule: [^\n]*)*\n*
Score=[^\n]*
Before [^\n]*
After [^\n]*)?
Application of TBL rules @ \d+ words/sec
finding rules took (?P<parsingtime>\d+) seconds)""", re.DOTALL)
    header=["language", "training size", "raw tagging", "tagging+TBL", "raw parsing", "parsing+TBL", "parsing speed (words/sec)"]
    print r"""
\begin{tabular}{%s}"""%("l"+("c"*(len(header)-1)))
    print " & ".join(header)+r"\\"
    for i in p.finditer(s):
        try:
            print r"%s&%s&%.3f&%.3f&%.3f&%.3f&%.5f\\"%(i.group("language"), i.group("wcount"), float(i.group("tagging1")), float(i.group("tagging2")), float(i.group("parsing1")), float(i.group("parsing2")), 1.0/float(i.group("parsingspeed")))
        except:
            pass
    print r"""\end{tabular}"""

def deprelscores(s="v4.txt"):
    p = re.compile(""".*Before repairing (?P<before>\S*) \S* \(test size = \S*\)
After repairing (?P<after>\S*) \S* \(test size = \S*\)
Application of TBL rules @ (?P<speed>\d+) words/sec
.*?
END (?P<language>\S*)""", re.DOTALL)
    if not "\n" in s:
        s = open(s).read()
    print r"""\begin{tabular}{lccc}"""
    for l in s.split("Using deprel rules: "):
        m = p.match(l)
        if m:
            print "%s&%.3f&%.3f&%.6f\\\\"%(m.group("language"), float(m.group("before")), float(m.group("after")), 1.0/float(m.group("speed")))
    print r"\end{tabular}"

def trainingtime(s):
    if not "\n" in s:
        s = open(s).read()
    pattern = re.compile("""Accuracy of parser on reserved data \(size (?P<size>\d+)\).*?finding rules took (?P<time>\d+) seconds""", re.DOTALL)
    for i in pattern.finditer(s):
        print int(i.group("size")), int(i.group("time")), float(i.group("time"))/float(i.group("size"))
        
def mergedirs(d0, d1):
    l0 = os.listdir(d0)
    l1 = {f:True for f in os.listdir(d1)}
    for f in l0:
        if "UD_" in f and not f in l1:
            shutil.copytree("%s/%s"%(d0, f), "%s/%s"%(d1, f))

            
