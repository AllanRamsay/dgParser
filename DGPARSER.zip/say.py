#!/usr/bin/python

import sys
import htk

htk.PRINTLEVEL = 1
def say(argv):
    n = 500
    d = "."
    words2phones = "dict.txt"
    phonelengths = "phonedict.txt"
    out = "praat"
    text = ""
    for i in range(1, len(argv), 2):
        flag = argv[i]
        value = argv[i+1]
        out = "praat"
        if flag == "-t" or "--text".startswith(flag):
            text = value
        elif flag == "-w" or "--words2phones".startswith(flag):
            words2phones = value
        elif flag == "-p" or "--phonelengths".startswith(flag):
            phonelengths = value
        elif flag == "-d" or "--directory".startswith(flag):
            d = value
        elif flag == "-o" or "--out".startswith(flag):
            out = value
        else:
            raise htk.ArgException("Unrecognised flag: %s"%(flag))
    htk.say(text, words2phones, phonelengths, out=out, d=d)
        
if "say" in sys.argv[0]:
    try:
        print sys.argv
        say(sys.argv)
    except htk.ArgException as e:
        print e
        print """say.py --text "<text>" (--directory <dir>) (--words2phones <dict>) (--phonelengths <pldict>) (--out <wavfile>)
        
directory defaults to ".", words2phones to "words2phones.txt",
phonelengths to "phonedict.txt"; if you specify that out should be
"praat", or omit it entirely, then the utterance is spoken aloud.

(any of the flag names may be abbreviated to e.g. --t, --d, ...)
"""
