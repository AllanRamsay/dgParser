import sounds, signals, pylab, re
reload(sounds)

def setpitch(sound0, pitchchange=1.0):
    signal0 = sound0.signal
    k = -10000000
    l = int(len(signal0)*pitchchange)
    signal1 = pylab.ones(l)*k
    for i in range(len(signal0)):
        signal1[int(i*pitchchange)] = signal0[i]
    if pitchchange > 1:
        for i in range(len(signal1)):
            if signal1[i] == k:
                signal1[i] = signal1[i-1]
    return sounds.SOUND(signal1)

def sample(sound0, g=10):
    signal0 = sound0.signal
    l = int(len(signal0)/g)
    signal1 = pylab.zeros(l)
    for i in range(l):
        signal1[i] = average(signal0[g*i:g*(i+1)])
    return sounds.SOUND(signal1)

def select(sound0, start, end):
    return sounds.SOUND(sound0.signal[start:end])

def align(a0, a1):
    best = False
    a0 = pylab.array(a0)
    a1 = pylab.array(a1)
    bestscore = sum(a1)
    for i in range(len(a1)-len(a0)):
        s = sum(abs(a0-a1[i:i+len(a0)]))
        if s < bestscore:
            bestscore = s
            best = i
            print i
    return i

def stretch(s0, stretchby=1.1, g=0.01):
    signal0 = s0.signal
    g = int(44100*g)
    print g
    signal1 = pylab.array([])
    signal2 = pylab.array([])
    signal3 = pylab.array([])
    stretchby = stretchby-1
    k = 0
    for i in range(0, len(signal0)-g, g):
        signal3 = pylab.append(signal3, signal0[i:i+g])
        if k >= 1:
            signal2 = pylab.append(signal2, pylab.zeros(g))
            signal1 = pylab.append(signal1, signal0[i:i+g])
            signal3 = pylab.append(signal3, signal0[i:i+g])
            k = 0
        else:
            k += stretchby
            signal1 = pylab.append(signal1, pylab.zeros(g))
            signal2 = pylab.append(signal2, signal0[i:i+g])
    return sounds.SOUND(signal1), sounds.SOUND(signal2), sounds.SOUND(signal3)

