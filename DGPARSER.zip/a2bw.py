#!/usr/bin/env python
# -*- coding: utf-8 -*-
import codecs

a2bwtable = {u"ا" : "A",
             u"أ" : ">",
             u"ب" : "b",
             u"ت" : "t",
             u"ث" : "v",
             u"ج" : "j",
             u"ح" : "H",
             u"خ" : "x",
             u"د" : "d",
             u"ذ" : "*",
             u"ر" : "r",
             u"ز" : "z",
             u"س" : "s",
             u"ش" : "$",
             u"ص" : "S",
             u"ض" : "D",
             u"ط" : "T",
             u"ظ" : "Z",
             u"ع" : "E",
             u"غ" : "g",
             u"ف" : "f",
             u"ق" : "q",
             u"ك" : "k",
             u"ل" : "l",
             u"م" : "m",
             u"ن" : "n",
             u"و" : "w",
             u"ى" : "Y",
             u"ه" : "h",
             u"ي" : "y",
             u"آ" : "|",
             u"ء" : "G",
             u"ؤ" : "&",
             u"ئ" : "}",
             u"ة" : "p",
             u"ـ" : "" ,
             u"ً" : "F",
             u"ٌ" : "N",
             u"ٍ" : "K",
             u"َ" : "a",
             u"ُ" : "u",
             u"ِ" : "i",
             u"ّ" : "~",
             u"ْ" : "o",
             u"إ" : "<",
             u"٠" : "0",
             u"١" : "1",
             u"٢" : "2",
             u"٣" : "3",
             u"٤" : "4",
             u"٥" : "5",
             u"٦" : "6",
             u"٧" : "7",
             u"٨" : "8",
             u"٩" : "9",
             u";" : ";",
             u"£" : "P",
             u"؟" : "?" ,
             u"،" : "," ,
             u"؛" : ";" ,
             u"-" : "-",
             u"--" : "--",
             u"/" : "/",
             u"“" : '"',
             u"”" : '"',
             u"!" : "!",
             u":" : ":",
             u".." : "..",
             u"..." : "...",
             u"^" : "^",
             u" " : " ",
         }

"""
s = 'بتوقيت'
teststring = 'بتوقيت'
print teststring
"""

def invtable(t0):
     t1 = {}
     for x in t0:
          t1[t0[x]] = x
     return t1

bw2atable = invtable(a2bwtable)

def convert(s0, table=a2bwtable):
    s1 = u''
    for c in s0:
        try:
            s1 += table[c]
        except:
            try:
                s1 += c
            except:
                s1 += '?'
    return s1
