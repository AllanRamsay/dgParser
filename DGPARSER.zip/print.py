
import subprocess 
subprocess.call('sicstus -r dg.sav --goal (dgParse("a cat",P))', shell=True)

