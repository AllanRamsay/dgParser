import matplotlib
matplotlib.use('TkAgg')
import pylab
from useful import *

def placetext(word, x, y):
    c = pylab.figure().canvas
    t = pylab.text(x, y, word)
    pylab.plot([0, 20],[0, 20])
    c.draw()
    bb = t.get_window_extent(c.renderer)
    print bb.width, bb.height
    rec = matplotlib.patches.Rectangle(
    (bb.x0, bb.y0), bb.width/0.9, bb.height/0.9, transform=None)
    gc = pylab.gca()
    gc.add_artist(rec)
    """
    line = matplotlib.patches.Arrow((0, 0), (40, 50))
    gc.add_artist(line)
    """
    pylab.show()
    
