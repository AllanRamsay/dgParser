import re
from useful import *
import dtw
reload(dtw)

def aligncomments(l1, l2, bandwidth=10):
    l1 = open(l1).read().split("\n")
    l2 = open(l2).read().split("\n")
    a = dtw.array(l1, l2)
    a.findPath(bandwidth=bandwidth)
    return a.getAlignment()
